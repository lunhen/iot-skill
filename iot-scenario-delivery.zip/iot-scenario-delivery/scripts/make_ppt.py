"""Generate the 14-slide contest deck from config/deck.json + config/domain.json.

Usage: python make_ppt.py <project-root>
All copy comes from the brief; all numbers come from the live domain config.
"""
from __future__ import annotations

import sys
from pathlib import Path

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.oxml.ns import qn
from pptx.util import Inches, Pt

from _common import project_paths, read_json

SW, SH = 13.333, 7.5
BG, PANEL, PANEL2 = "07111F", "0E2033", "10263A"
LINE, TEXT, TEXT2, MUTED = "1D3B54", "E9F3FF", "C3D5E8", "9FB4C8"
TEAL, BLUE, PURPLE, AMBER, ORANGE, RED, GOLD = "35E0C0", "4F8DFF", "B38CFF", "FFB547", "FF7A59", "FF5F6D", "E9B85C"
ACCENTS = [TEAL, BLUE, PURPLE, AMBER]
CN, EN = "Microsoft YaHei", "Arial"


def C(h):
    return RGBColor.from_string(h.replace("#", "").upper())


def set_font(run, size, color, bold=False, font=CN):
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = C(color)
    run.font.name = font
    rPr = run._r.get_or_add_rPr()
    for tag in ("a:ea", "a:cs"):
        el = rPr.find(qn(tag))
        if el is None:
            el = rPr.makeelement(qn(tag), {})
            rPr.append(el)
        el.set("typeface", font)


def box(slide, x, y, w, h, fill=PANEL, line=None, radius=True):
    shp = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if radius else MSO_SHAPE.RECTANGLE,
                                 Inches(x), Inches(y), Inches(w), Inches(h))
    shp.fill.solid()
    shp.fill.fore_color.rgb = C(fill)
    if line:
        shp.line.color.rgb = C(line)
        shp.line.width = Pt(0.8)
    else:
        shp.line.fill.background()
    if radius:
        try:
            shp.adjustments[0] = 0.06
        except Exception:
            pass
    return shp


def text(slide, x, y, w, h, value, size=14, color=TEXT, bold=False, align="left", font=CN, spacing=1.15):
    tb = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = Inches(0.02)
    tf.margin_top = tf.margin_bottom = 0
    lines = str(value).split("\n")
    for i, line in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = {"left": PP_ALIGN.LEFT, "center": PP_ALIGN.CENTER, "right": PP_ALIGN.RIGHT}[align]
        p.line_spacing = spacing
        r = p.add_run()
        r.text = line
        set_font(r, size, color, bold, font)
    return tb


def base(prs, idx, title, sub=""):
    s = prs.slides.add_slide(prs.slide_layouts[6])
    box(s, 0, 0, SW, SH, BG, radius=False)
    box(s, 0, 0, SW, 0.045, TEAL, radius=False)
    text(s, 0.62, 0.34, 10.8, 0.5, title, 25, TEXT, True)
    if sub:
        text(s, 0.64, 0.92, 11.6, 0.32, sub, 11, MUTED)
    text(s, 11.9, 0.42, 0.8, 0.3, f"{idx:02d} / 14", 10, MUTED, align="right", font=EN)
    box(s, 0.62, 7.06, 12.1, 0.012, LINE, radius=False)
    return s


def footer(s, label):
    text(s, 0.64, 7.12, 11.0, 0.24, label, 9, MUTED)


def card(s, x, y, w, h, head, body, color=TEAL, metric=""):
    box(s, x, y, w, h, PANEL, LINE)
    box(s, x, y, 0.055, h, color, radius=False)
    text(s, x + 0.24, y + 0.18, w - 0.45, 0.34, head, 14, TEXT, True)
    text(s, x + 0.24, y + 0.62, w - 0.45, h - 1.0, body[:110], 10.5, TEXT2, spacing=1.25)
    if metric:
        text(s, x + 0.24, y + h - 0.48, w - 0.45, 0.3, metric, 11, color, True)


def image(s, path, x, y, w, h, fallback=PANEL2):
    if Path(path).exists():
        try:
            s.shapes.add_picture(str(path), Inches(x), Inches(y), width=Inches(w), height=Inches(h))
            return True
        except Exception:
            pass
    box(s, x, y, w, h, fallback, LINE)
    text(s, x, y + h / 2 - 0.2, w, 0.4, "系统界面截图", 11, MUTED, align="center")
    return False


def clip(v, n=90):
    return str(v)[:n]


def build(root: Path):
    p = project_paths(root)
    domain = read_json(p["domain"])
    deck = read_json(p["config"] / "deck.json")
    c = deck.get("content", {})
    proj = domain.get("project", {})
    name = proj.get("name", "智安")
    full = proj.get("fullName", "安全物联网监测平台")
    topic = proj.get("contestTopic", "安全物联网监测系统")
    module = proj.get("module", "模块 C：场景创新与设计")
    sites, sensors = domain.get("sites", []), domain.get("sensorTypes", {})
    layout = domain.get("sensorLayout", [])
    areas = [(s, f) for s in sites for f in s.get("faces", [])]
    scenarios = [(k, v) for k, v in domain.get("scenarios", {}).items() if k != "normal"]
    devices = [it for g in domain.get("devices", []) for it in g.get("items", [])]
    points = len(areas) * len(layout)
    assets = p["assets"]
    A = lambda n: assets / n

    prs = Presentation()
    prs.slide_width, prs.slide_height = Inches(SW), Inches(SH)

    # 1 cover
    s = prs.slides.add_slide(prs.slide_layouts[6])
    box(s, 0, 0, SW, SH, BG, radius=False)
    if A("cover-hero.png").exists():
        image(s, A("cover-hero.png"), 8.0, 0, 5.333, 7.5)
    box(s, 0, 0, SW, 0.05, TEAL, radius=False)
    text(s, 0.8, 1.3, 7.0, 0.4, module, 13, TEAL, True)
    text(s, 0.8, 2.0, 7.2, 1.0, name, 46, TEXT, True)
    text(s, 0.8, 3.05, 7.2, 0.5, full, 22, TEXT2)
    box(s, 0.8, 3.85, 1.1, 0.04, TEAL, radius=False)
    text(s, 0.8, 4.15, 6.9, 0.7, clip(c.get("background", ""), 100), 11.5, MUTED, spacing=1.35)
    for i, (v, lab) in enumerate([(len(sites), proj.get("siteLabel", "站点")), (len(areas), proj.get("areaLabel", "区域")), (points, "在线测点")]):
        x = 0.8 + i * 2.25
        text(s, x, 5.35, 2.0, 0.5, str(v), 28, ACCENTS[i], True, font=EN)
        text(s, x, 5.9, 2.0, 0.3, lab, 11, MUTED)
    text(s, 0.8, 6.85, 7.0, 0.3, proj.get("tagline", ""), 11, TEAL)

    # 2 pain
    pain = c.get("pain", [])[:4]
    s = base(prs, 2, "业务痛点与风险画像", "为什么需要一套可闭环的在线监测系统")
    for i, item in enumerate(pain):
        card(s, 0.62 + (i % 2) * 3.15, 1.45 + (i // 2) * 2.25, 3.0, 2.05,
             item.get("title", ""), item.get("desc", ""), ACCENTS[i], item.get("metric", ""))
    box(s, 7.15, 1.45, 5.55, 4.3, PANEL, LINE)
    text(s, 7.45, 1.7, 4.9, 0.35, "风险—能力映射", 16, TEXT, True)
    for i, (k, v) in enumerate(list(sensors.items())[:6]):
        y = 2.25 + i * 0.55
        box(s, 7.45, y + 0.08, 0.14, 0.14, ACCENTS[i % 4], radius=False)
        text(s, 7.72, y, 2.6, 0.3, v.get("name", k), 11.5, TEXT2)
        text(s, 10.2, y, 2.2, 0.3, f"{v.get('warning', '—')} / {v.get('alarm', '—')}", 10.5, MUTED, align="right", font=EN)
    text(s, 7.45, 5.35, 4.9, 0.3, "监测对象与系统阈值一一对应", 10.5, TEAL)
    footer(s, f"{name} · {module}")

    # 3 goals
    s = base(prs, 3, "建设目标与功能边界", "可验收、可复现、可离线演示")
    for i, g in enumerate(c.get("goals", [])[:4]):
        card(s, 0.62 + (i % 2) * 6.15, 1.45 + (i // 2) * 2.2, 5.95, 2.0,
             f"0{i+1}  {g.get('title','')}", g.get("desc", ""), ACCENTS[i])
    box(s, 0.62, 6.0, 12.1, 0.85, PANEL2, LINE)
    text(s, 0.9, 6.2, 11.6, 0.45,
         "非功能口径：2s 采样 · SSE 实时推送 · 零第三方运行时依赖 · 固定随机种子可复现 · 单机离线可运行",
         12, TEXT2, align="center")
    footer(s, f"{name} · {module}")

    # 4 architecture
    arch = c.get("architecture", [])[:5]
    s = base(prs, 4, "总体架构：五层闭环", "端 — 边 — 网 — 云 — 用")
    for i, layer in enumerate(arch):
        y = 1.4 + i * 1.06
        box(s, 0.62, y, 12.1, 0.94, PANEL if i % 2 == 0 else PANEL2, LINE)
        box(s, 0.62, y, 0.07, 0.94, ACCENTS[i % 4], radius=False)
        text(s, 0.9, y + 0.16, 1.7, 0.35, layer.get("layer", ""), 14, ACCENTS[i % 4], True)
        text(s, 2.6, y + 0.18, 6.4, 0.4, "  ·  ".join(layer.get("items", [])[:5]), 12, TEXT)
        text(s, 9.2, y + 0.2, 3.2, 0.35, clip(layer.get("note", ""), 26), 10.5, MUTED, align="right")
        if i < len(arch) - 1:
            text(s, 12.2, y + 0.86, 0.5, 0.25, "↓", 12, TEAL, align="center")
    footer(s, "数据上行 · 指令下行 · 每层均有可验证的状态与指标")

    # 5 deployment
    s = base(prs, 5, "硬件部署思路", f"{len(sites)} 个{proj.get('siteLabel','站点')} · {len(areas)} 个{proj.get('areaLabel','区域')} · {points} 个测点")
    cw = 3.95
    for i, site in enumerate(sites[:3]):
        x = 0.62 + i * 4.1
        box(s, x, 1.45, cw, 4.5, PANEL, LINE)
        box(s, x, 1.45, cw, 0.06, ACCENTS[i], radius=False)
        text(s, x + 0.25, 1.7, cw - 0.5, 0.4, site.get("name", ""), 17, TEXT, True)
        text(s, x + 0.25, 2.15, cw - 0.5, 0.3, f"{site.get('location','')} · 风险基线 {site.get('riskBase','—')}", 10.5, MUTED)
        for j, f in enumerate(site.get("faces", [])[:4]):
            y = 2.75 + j * 0.72
            box(s, x + 0.25, y, cw - 0.5, 0.58, PANEL2, LINE)
            text(s, x + 0.4, y + 0.13, cw - 0.8, 0.3, clip(f.get("name", ""), 18), 11.5, TEXT2)
        text(s, x + 0.25, 5.55, cw - 0.5, 0.3, f"{len(site.get('faces',[]))} 区域 × {len(layout)} 测点", 11, ACCENTS[i], True)
    footer(s, "环网冗余 · 边缘缓存 · 分级值守")

    # 6 device selection
    s = base(prs, 6, "设备选型与依据", f"{len(devices)} 类设备，参数、数量与系统台账同源")
    for i, it in enumerate(devices[:6]):
        x, y = 0.62 + (i % 3) * 4.1, 1.45 + (i // 3) * 2.65
        box(s, x, y, 3.9, 2.45, PANEL, LINE)
        text(s, x + 0.22, y + 0.18, 3.5, 0.32, clip(it.get("name", ""), 18), 13, ACCENTS[i % 4], True)
        text(s, x + 0.22, y + 0.56, 3.5, 0.26, it.get("model", ""), 10.5, MUTED, font=EN)
        text(s, x + 0.22, y + 0.92, 3.5, 0.85, clip(it.get("params", ""), 68), 9.5, TEXT2, spacing=1.2)
        text(s, x + 0.22, y + 1.85, 3.5, 0.42, clip(it.get("reason", ""), 44), 9.5, MUTED, spacing=1.15)
    footer(s, "选型原则：风险适配 · 合规可靠 · 冗余可续 · 低耗易维")

    # 7 software
    s = base(prs, 7, "软件功能实现", "六个一级页面 · 2 秒增量刷新 · 全链路可验证")
    for i, (fn, cap) in enumerate([("overview-169.png", "综合态势"), ("face-169.png", f"{proj.get('areaLabel','区域')}监控"),
                                   ("alarms-169.png", "告警中心")]):
        x = 0.62 + i * 4.1
        image(s, A(fn), x, 1.5, 3.9, 2.2)
        text(s, x, 3.82, 3.9, 0.3, cap, 12, TEAL, True, align="center")
    for i, (fn, cap) in enumerate([("topology-169.png", "链路拓扑"), ("devices-169.png", "设备台账"),
                                   ("scenario-1610.png", "风险演练")]):
        x = 0.62 + i * 4.1
        image(s, A(fn), x, 4.25, 3.9, 2.2)
        text(s, x, 6.55, 3.9, 0.3, cap, 12, TEAL, True, align="center")
    footer(s, "截图由无头浏览器自动采集，与交付源码版本一致")

    # 8 data chain
    s = base(prs, 8, "数据链路与告警闭环", "采集 → 传输 → 研判 → 联动 → 处置 → 归档")
    steps = ["感知采集", "边缘汇聚", "环网传输", "规则研判", "联动处置", "闭环归档"]
    notes = ["2s 采样 / 8 类测点", "RS485 / 本地缓存", "双环冗余 / <50ms", "三级阈值 + 去抖", "声光 / 断电 / 通风", "确认 / 复核 / 留痕"]
    for i, (st, nt) in enumerate(zip(steps, notes)):
        x = 0.62 + i * 2.03
        box(s, x, 2.0, 1.88, 2.2, PANEL, LINE)
        box(s, x, 2.0, 1.88, 0.06, ACCENTS[i % 4], radius=False)
        text(s, x + 0.12, 2.35, 1.64, 0.35, f"0{i+1}", 20, ACCENTS[i % 4], True, align="center", font=EN)
        text(s, x + 0.1, 2.95, 1.68, 0.35, st, 12, TEXT, True, align="center")
        text(s, x + 0.12, 3.45, 1.64, 0.6, nt, 9.5, MUTED, align="center", spacing=1.2)
        if i < 5:
            text(s, x + 1.86, 2.9, 0.2, 0.3, "›", 16, TEAL, align="center")
    box(s, 0.62, 4.7, 12.1, 1.6, PANEL2, LINE)
    text(s, 0.9, 4.95, 11.5, 0.4, "状态机：open → acknowledged → resolved", 15, TEXT, True, align="center")
    text(s, 0.9, 5.5, 11.5, 0.5,
         "每次等级升级生成新事件并保留原时间线；联动执行记录、处置人、耗时与 CSV 导出构成完整证据链",
         11, MUTED, align="center")
    footer(s, "固定随机种子驱动，演示过程可复现")

    # 9 scenarios
    s = base(prs, 9, "风险场景演练", f"{len(scenarios)} 类场景一键注入 · 验证采集到处置的完整链路")
    for i, (key, v) in enumerate(scenarios[:4]):
        x, y = 0.62 + (i % 2) * 6.15, 1.45 + (i // 2) * 2.35
        box(s, x, y, 5.95, 2.15, PANEL, LINE)
        box(s, x, y, 0.06, 2.15, ACCENTS[i], radius=False)
        text(s, x + 0.25, y + 0.18, 4.0, 0.35, f"{v.get('code','')}  {v.get('name','')}", 15, ACCENTS[i], True)
        text(s, x + 4.4, y + 0.2, 1.3, 0.3, f"{v.get('duration','')} s", 11, MUTED, align="right", font=EN)
        text(s, x + 0.25, y + 0.68, 5.4, 0.9, clip(v.get("description", ""), 88), 10.5, TEXT2, spacing=1.25)
        text(s, x + 0.25, y + 1.7, 5.4, 0.3, f"目标槽位：{', '.join(v.get('targetTypes', []))}  ｜  预期等级：{v.get('level','')}", 10, MUTED)
    image(s, A("scenario-1610.png"), 0.62, 6.2, 3.2, 0.75)
    footer(s, "注入 → 数值越限 → 自动联动 → 告警生成 → 人工闭环，全程约 2 分钟")

    # 10 innovations
    s = base(prs, 10, "创新亮点", "可讲清、可演示、可验收")
    for i, it in enumerate(c.get("innovations", [])[:4]):
        x, y = 0.62 + (i % 2) * 6.15, 1.45 + (i // 2) * 2.35
        box(s, x, y, 5.95, 2.15, PANEL, LINE)
        text(s, x + 0.28, y + 0.22, 0.8, 0.4, f"0{i+1}", 22, ACCENTS[i], True, font=EN)
        text(s, x + 1.15, y + 0.24, 4.5, 0.35, it.get("title", ""), 14, TEXT, True)
        text(s, x + 0.28, y + 0.85, 5.4, 0.85, clip(it.get("desc", ""), 96), 10.5, TEXT2, spacing=1.25)
        text(s, x + 0.28, y + 1.75, 5.4, 0.3, "落点：" + it.get("anchor", ""), 10.5, ACCENTS[i], True)
    footer(s, "创新点均可在本机现场复现，不依赖外部服务")

    # 11 AI engineering
    s = base(prs, 11, "AI 辅助开发的工程化使用", "提示词有版本 · 输出有评审 · 缺陷有闭环")
    box(s, 0.62, 1.45, 5.95, 4.9, PANEL, LINE)
    text(s, 0.9, 1.7, 5.4, 0.35, "提示词版本链路", 15, TEAL, True)
    for i, t in enumerate(["P01 任务拆解与交付物清单", "P02 数据契约与状态机", "P03 告警引擎与去抖",
                           "P04 可视化风格与信息架构", "P05 场景演练沙盘", "P06 文档 / PPT 生成",
                           "P07 接口冒烟与视觉验收", "P08 交付包一致性核验"]):
        y = 2.25 + i * 0.48
        box(s, 0.95, y + 0.09, 0.1, 0.1, TEAL, radius=False)
        text(s, 1.2, y, 5.0, 0.3, t, 11, TEXT2)
    box(s, 6.77, 1.45, 5.95, 4.9, PANEL, LINE)
    text(s, 7.05, 1.7, 5.4, 0.35, "AI / 人工职责边界", 15, BLUE, True)
    text(s, 7.05, 2.3, 5.4, 1.4,
         "AI：代码骨架、样式、文档排版、同源数据生成、截图与打包\n人工：赛题解读、阈值合规、设备参数、创新取舍、最终验收",
         11.5, TEXT2, spacing=1.5)
    box(s, 7.05, 4.0, 5.4, 1.9, PANEL2, LINE)
    text(s, 7.3, 4.2, 4.9, 1.4,
         "工程化要点\n· 主数据单点定义，材料同源生成\n· 单元测试 + 接口冒烟 + 截图目检\n· 缺陷记录到提示词版本，可追溯",
         10.5, MUTED, spacing=1.4)
    footer(s, "完整记录见《AI提示词全过程记录.docx》")

    # 12 value
    s = base(prs, 12, "场景落地价值", "安全、管理、落地三个维度可量化")
    for i, v in enumerate(c.get("values", [])[:3]):
        x = 0.62 + i * 4.1
        box(s, x, 1.5, 3.9, 3.6, PANEL, LINE)
        box(s, x, 1.5, 3.9, 0.06, ACCENTS[i], radius=False)
        text(s, x + 0.25, 1.85, 3.4, 0.4, v.get("title", ""), 16, ACCENTS[i], True)
        text(s, x + 0.25, 2.5, 3.4, 1.6, clip(v.get("desc", ""), 100), 11.5, TEXT2, spacing=1.4)
        text(s, x + 0.25, 4.4, 3.4, 0.4, v.get("kpi", ""), 18, TEXT, True, font=EN)
    box(s, 0.62, 5.5, 12.1, 1.1, PANEL2, LINE)
    text(s, 0.9, 5.75, 11.6, 0.6,
         f"覆盖 {len(sites)} {proj.get('siteLabel','站点')} / {len(areas)} {proj.get('areaLabel','区域')} / {points} 测点，"
         f"异常发现从小时级压缩到秒级，形成可追溯的处置闭环",
         12.5, TEXT2, align="center")
    footer(s, f"{name} · {module}")

    # 13 limits
    s = base(prs, 13, "局限性与演进路线", "主动说明边界，比回避更可信")
    for i, l in enumerate(c.get("limits", [])[:4]):
        y = 1.45 + i * 1.12
        box(s, 0.62, y, 6.0, 0.98, PANEL, LINE)
        text(s, 0.88, y + 0.14, 5.5, 0.3, l.get("title", ""), 12.5, AMBER, True)
        text(s, 0.88, y + 0.5, 5.5, 0.35, clip(l.get("desc", ""), 38), 10, MUTED)
        box(s, 6.82, y, 5.9, 0.98, PANEL2, LINE)
        text(s, 7.08, y + 0.14, 5.4, 0.3, "后续：" + clip(l.get("plan", ""), 30), 11, TEAL)
    box(s, 0.62, 6.05, 12.1, 0.75, PANEL, LINE)
    text(s, 0.9, 6.25, 11.6, 0.35,
         "  →  ".join(f"{r.get('phase','')}：{clip(r.get('items',''), 20)}" for r in c.get("roadmap", [])[:3]),
         10.5, TEXT2, align="center")
    footer(s, "仿真边界已在 README 与答辩口径中明确说明")

    # 14 delivery
    s = base(prs, 14, "交付清单与演示路径", "一键启动 · 8 分钟走完完整链路")
    files = ["项目演示.pptx", "application-topology.drawio / .json", "项目完整源码.zip",
             "设备选型说明.docx / .xlsx", "AI提示词全过程记录.docx", "演示脚本与答辩要点.docx",
             "screenshots/（9 张）", "启动系统.bat / server/index.js"]
    for i, f in enumerate(files):
        x, y = 0.62 + (i % 2) * 6.15, 1.45 + (i // 2) * 0.72
        box(s, x, y, 0.1, 0.1, TEAL, radius=False)
        text(s, x + 0.25, y - 0.06, 5.6, 0.32, f, 11.5, TEXT2, font=EN)
    box(s, 0.62, 4.55, 12.1, 1.9, PANEL2, LINE)
    text(s, 0.9, 4.78, 11.5, 0.35, "现场启动", 14, TEAL, True)
    text(s, 0.9, 5.2, 11.5, 0.35, "npm start    →    http://127.0.0.1:" + str(proj.get("port", 4173)), 13, TEXT, font=EN)
    text(s, 0.9, 5.72, 11.5, 0.45,
         "  →  ".join(d.get("title", "") for d in c.get("demo", [])[:5]),
         10.5, MUTED)
    text(s, 0.62, 6.7, 12.1, 0.4, proj.get("tagline", ""), 15, TEAL, True, align="center")

    p["deliverables"].mkdir(parents=True, exist_ok=True)
    out = p["deliverables"] / "项目演示.pptx"
    prs.save(out)
    print(f"[OK] pptx: 14 slides -> {out.name}")
    return out


if __name__ == "__main__":
    build(Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve())
