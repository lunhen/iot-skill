"""Generate the draw.io topology project file + machine-readable JSON.

Usage: python make_topology.py <project-root>
"""
from __future__ import annotations

import sys
from pathlib import Path
from xml.sax.saxutils import escape

from _common import project_paths, read_json, write_json, write_text

W, H = 1840, 1120
LANE_X, LANE_W, LANE_GAP = 40, 320, 40
TITLE = "rounded=0;whiteSpace=wrap;html=1;fillColor=#07111f;strokeColor=none;fontColor=#e9f3ff;fontSize=22;align=left;spacingLeft=18;fontStyle=1;"
LABEL = "rounded=0;whiteSpace=wrap;html=1;fillColor=none;strokeColor=none;fontColor=#7e95ad;fontSize=11;align=left;spacingLeft=2;"
LANE = "rounded=1;whiteSpace=wrap;html=1;fillColor=#0b1929;strokeColor=#1f4260;fontColor=#cfe6f8;fontSize=13;align=center;verticalAlign=top;spacingTop=10;fontStyle=1;"
NODE = "rounded=1;whiteSpace=wrap;html=1;fillColor=#0e2a31;strokeColor=#2c7a72;fontColor=#9fe9db;fontSize=11;align=left;spacingLeft=10;"
EDGE = "edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;strokeColor=#35e0c0;strokeWidth=2;endArrow=block;endFill=1;fontColor=#7fe8d6;fontSize=10;"


def build(root: Path):
    p = project_paths(root)
    domain = read_json(p["domain"])
    project = domain.get("project", {})
    sites = domain.get("sites", [])
    links = domain.get("linkNodes", []) or [
        {"id": f"l{i}", "name": n, "sub": "", "count": 0, "color": "#35e0c0"}
        for i, n in enumerate(["感知层", "边缘层", "网络层", "平台层", "应用层"])
    ]
    devices = [it for g in domain.get("devices", []) for it in g.get("items", [])]
    sensors = list(domain.get("sensorTypes", {}).values())

    nodes, edges = [], []

    def node(nid, label, x, y, w, h, style):
        nodes.append({"id": nid, "label": label, "x": x, "y": y, "w": w, "h": h, "style": style, "parent": "1"})

    def edge(eid, source, target, label=""):
        edges.append({"id": eid, "source": source, "target": target, "label": label, "style": EDGE, "parent": "1"})

    node("title", f"{project.get('name', '智安')} · {project.get('fullName', '安全物联网监测平台')} 应用拓扑",
         0, 0, W, 54, TITLE)
    node("subtitle", "端 — 边 — 网 — 云 — 用 五层架构 ｜ 感知采集 · 边缘汇聚 · 冗余传输 · 规则研判 · 联动处置 · 闭环归档",
         0, 54, W, 30, LABEL)

    lane_y, lane_h = 110, 880
    lane_ids = []
    for i, link in enumerate(links):
        x = LANE_X + i * (LANE_W + LANE_GAP)
        lid = f"lane_{link.get('id', i)}"
        lane_ids.append(lid)
        node(lid, f"{link.get('name', '')}\n{link.get('sub', '')}", x, lane_y, LANE_W, lane_h, LANE)
        color = link.get("color", "#35e0c0")
        style = NODE.replace("#2c7a72", color).replace("#9fe9db", color)
        if i == 0:
            children = [s.get("name", "") for s in sensors[:6]] + [f"{s.get('shortName', s.get('name',''))} · {len(s.get('faces',[]))} 区域" for s in sites]
        elif i == 1:
            children = [f"{s.get('shortName', s.get('name',''))} 边缘分站 ×{len(s.get('faces', []))}" for s in sites] + ["RS485 多路汇聚", "断网本地缓存 ≥4h", "本地阈值预处理"]
        elif i == 2:
            children = [f"{s.get('shortName', s.get('name',''))} 冗余环网" for s in sites] + ["光纤双环 · 自愈 <50 ms", "MQTT / OPC UA 网关"]
        elif i == 3:
            children = ["采集接入服务", "分级告警引擎", "时序数据库", "设备 / 工单服务", "双机热备"]
        else:
            children = ["集团调度中心", "现场值班终端", "移动巡检端", "告警闭环与 CSV 导出", "监管开放接口"]
        for j, label in enumerate(children[:9]):
            node(f"{lid}_n{j}", label, x + 16, lane_y + 56 + j * 78, LANE_W - 32, 60, style)
        for j in range(len(children[:9]) - 1):
            edge(f"{lid}_e{j}", f"{lid}_n{j}", f"{lid}_n{j + 1}")
    for i in range(len(lane_ids) - 1):
        edge(f"cross_{i}", f"{lane_ids[i]}_n0", f"{lane_ids[i + 1]}_n0", "数据上行 / 指令下行")

    node("footer", f"设备 {len(devices)} 类 ｜ 测点 {sum(len(s.get('faces', [])) for s in sites) * len(sensors)} 个 ｜ "
                   f"演练场景 {max(0, len(domain.get('scenarios', {})) - 1)} 类 ｜ 数据源：config/domain.json",
         0, H - 60, W, 30, LABEL)

    # ---- draw.io XML ----
    cells = ['<mxCell id="0" />', '<mxCell id="1" parent="0" />']
    for n in nodes:
        val = escape(str(n["label"])).replace("\n", "&#10;")
        cells.append(
            f'<mxCell id="{escape(n["id"])}" value="{val}" style="{escape(n["style"], {chr(34): "&quot;"})}'
            f'" vertex="1" parent="{n["parent"]}"><mxGeometry x="{n["x"]}" y="{n["y"]}" '
            f'width="{n["w"]}" height="{n["h"]}" as="geometry" /></mxCell>'
        )
    for e in edges:
        val = escape(str(e["label"]))
        cells.append(
            f'<mxCell id="{escape(e["id"])}" value="{val}" style="{escape(e["style"], {chr(34): "&quot;"})}'
            f'" edge="1" parent="{e["parent"]}" source="{escape(e["source"])}" target="{escape(e["target"])}">'
            f'<mxGeometry relative="1" as="geometry" /></mxCell>'
        )
    xml = (
        '<mxfile host="app.diagrams.net" modified="2026-01-01T00:00:00.000Z" agent="iot-scenario-delivery" version="21.0.0">'
        '<diagram id="application-topology" name="应用拓扑"><mxGraphModel dx="1840" dy="1120" grid="1" '
        'gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" '
        'pageWidth="1840" pageHeight="1120" background="#07111f" math="0" shadow="0"><root>'
        + "".join(cells) + "</root></mxGraphModel></diagram></mxfile>"
    )
    drawio = p["topology"] / "application-topology.drawio"
    write_text(drawio, xml)
    write_json(p["topology"] / "application-topology.json", {
        "project": project, "canvas": {"width": W, "height": H},
        "layers": [{"id": l.get("id"), "name": l.get("name"), "sub": l.get("sub")} for l in links],
        "nodes": nodes, "edges": edges,
    })
    p["downloads"].mkdir(parents=True, exist_ok=True)
    write_text(p["downloads"] / "application-topology.drawio", xml)
    print(f"[OK] topology: {len(nodes)} nodes / {len(edges)} edges -> {drawio.name}")
    return drawio


if __name__ == "__main__":
    build(Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve())
