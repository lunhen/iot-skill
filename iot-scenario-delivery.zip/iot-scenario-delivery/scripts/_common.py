"""Shared helpers for iot-scenario-delivery.

All file IO is explicit UTF-8. Never let Windows PowerShell touch UTF-8 text:
PowerShell 5.1 reads ANSI by default and silently corrupts Chinese characters.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

SKILL_DIR = Path(__file__).resolve().parent.parent
STARTER = SKILL_DIR / "assets" / "starter"
EXAMPLES = SKILL_DIR / "assets" / "examples"
TEXT_SUFFIXES = {".js", ".mjs", ".css", ".html", ".md", ".bat", ".json", ".py", ".txt", ".gitignore"}
SKIP_DIRS = {"node_modules", ".git", ".tmp-edge", "ppt-assets", "screenshots"}

DSH_PYTHON = Path.home() / ".dsh" / "dsh-runtimes" / "dsh-primary-runtime" / "dependencies" / "python" / "python.exe"
EDGE_CANDIDATES = [
    Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"),
    Path(r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"),
]


def read_text(path: Path) -> str:
    return Path(path).read_text(encoding="utf-8")


def write_text(path: Path, content: str) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8", newline="\n")


def read_json(path: Path):
    return json.loads(read_text(Path(path)))


def write_json(path: Path, data) -> None:
    write_text(path, json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def apply_glossary(text: str, glossary: dict) -> str:
    """Replace domain terms. Longest keys first so '青龙煤矿' beats '煤矿'."""
    if not glossary:
        return text
    for key in sorted(glossary, key=len, reverse=True):
        if key:
            text = text.replace(key, str(glossary[key]))
    return text


def apply_glossary_obj(obj, glossary):
    if isinstance(obj, str):
        return apply_glossary(obj, glossary)
    if isinstance(obj, list):
        return [apply_glossary_obj(v, glossary) for v in obj]
    if isinstance(obj, dict):
        return {k: apply_glossary_obj(v, glossary) for k, v in obj.items()}
    return obj


def deep_merge(base, override):
    """Dicts merge recursively; lists/scalars replace wholesale."""
    if isinstance(base, dict) and isinstance(override, dict):
        out = dict(base)
        for k, v in override.items():
            out[k] = deep_merge(out[k], v) if k in out else v
        return out
    return override


def find_python() -> str:
    """Prefer the DSH bundled interpreter: it already has docx/pptx/openpyxl/PIL."""
    candidates = [DSH_PYTHON, Path(sys.executable)]
    for exe in candidates:
        if not exe or not Path(exe).exists():
            continue
        try:
            r = subprocess.run(
                [str(exe), "-c", "import docx,pptx,openpyxl,PIL"],
                capture_output=True, timeout=20,
            )
            if r.returncode == 0:
                return str(exe)
        except Exception:
            continue
    raise RuntimeError(
        "No Python with python-docx / python-pptx / openpyxl / Pillow found. "
        "Install them with: python -m pip install python-docx python-pptx openpyxl Pillow"
    )


def find_edge() -> Path | None:
    for p in EDGE_CANDIDATES:
        if p.exists():
            return p
    return None


def project_paths(root: Path) -> dict:
    root = Path(root)
    return {
        "root": root,
        "config": root / "config",
        "domain": root / "config" / "domain.json",
        "brief": root / "config" / "brief.json",
        "docs": root / "docs",
        "scripts": root / "scripts",
        "deliverables": root / "deliverables",
        "shots": root / "deliverables" / "screenshots",
        "assets": root / "deliverables" / "ppt-assets",
        "topology": root / "topology",
        "downloads": root / "public" / "downloads",
    }


def safe_rmtree(path: Path) -> None:
    """Best-effort cleanup; never fail the build on locked temp files."""
    try:
        shutil.rmtree(path, ignore_errors=True)
    except Exception:
        pass
