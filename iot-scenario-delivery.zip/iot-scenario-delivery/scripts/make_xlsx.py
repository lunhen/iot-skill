"""Generate the multi-sheet device-selection workbook from config/domain.json.

Usage: python make_xlsx.py <project-root>
"""
from __future__ import annotations

import sys
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from _common import project_paths, read_json

NAVY, NAVY2, TEAL, WHITE, MUTED, LIGHT = "0B1929", "132B42", "35E0C0", "FFFFFF", "7E95AD", "EAF2F8"
LINE = Side(style="thin", color="B9CBD9")
THIN = Border(left=LINE, right=LINE, top=LINE, bottom=LINE)
CN = "微软雅黑"


def sheet(wb, title, headers, rows, widths, note=None):
    ws = wb.create_sheet(title)
    ws.sheet_view.showGridLines = False
    r = 1
    if note:
        ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(headers))
        c = ws.cell(1, 1, note)
        c.font = Font(name=CN, size=11, color=TEAL)
        c.fill = PatternFill("solid", fgColor=NAVY2)
        c.alignment = Alignment(vertical="center", indent=1)
        ws.row_dimensions[1].height = 26
        r = 2
    for j, h in enumerate(headers, 1):
        c = ws.cell(r, j, h)
        c.font = Font(name=CN, size=10, bold=True, color=WHITE)
        c.fill = PatternFill("solid", fgColor=NAVY)
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border = THIN
    ws.row_dimensions[r].height = 28
    for i, row in enumerate(rows, r + 1):
        for j, val in enumerate(row, 1):
            c = ws.cell(i, j, val)
            c.font = Font(name=CN, size=9, color="1B3348")
            c.fill = PatternFill("solid", fgColor=WHITE if i % 2 else "F4F8FC")
            c.alignment = Alignment(vertical="center", wrap_text=True)
            c.border = THIN
        ws.row_dimensions[i].height = 30
    for j, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(j)].width = w
    ws.freeze_panes = ws.cell(r + 1, 1)
    if rows:
        ws.auto_filter.ref = f"A{r}:{get_column_letter(len(headers))}{r + len(rows)}"
    return ws


def build(root: Path):
    p = project_paths(root)
    domain = read_json(p["domain"])
    project = domain.get("project", {})
    sites, sensors = domain.get("sites", []), domain.get("sensorTypes", {})
    layout = domain.get("sensorLayout", [])
    groups, scenarios = domain.get("devices", []), domain.get("scenarios", {})
    items = [it for g in groups for it in g.get("items", [])]
    areas = [(s, f) for s in sites for f in s.get("faces", [])]
    name = project.get("name", "智安")
    topic = project.get("contestTopic", "安全物联网监测系统")

    wb = Workbook()
    ws = wb.active
    ws.title = "封面与说明"
    ws.sheet_view.showGridLines = False
    ws.merge_cells("A1:H2")
    c = ws["A1"]
    c.value = f"{name} · {topic}  设备选型说明"
    c.font = Font(name=CN, size=22, bold=True, color=WHITE)
    c.fill = PatternFill("solid", fgColor=NAVY)
    c.alignment = Alignment(vertical="center", indent=1)
    ws.row_dimensions[1].height = 34
    ws.row_dimensions[2].height = 22
    ws.merge_cells("A3:H3")
    c = ws["A3"]
    c.value = "Device Selection Specification · V1.0 · 与 config/domain.json 同源生成"
    c.font = Font(name=CN, size=11, color=TEAL)
    c.fill = PatternFill("solid", fgColor=NAVY2)
    c.alignment = Alignment(vertical="center", indent=1)
    ws.row_dimensions[3].height = 24
    info = [
        ("项目名称", topic),
        ("建设范围", f"{len(sites)} 个{project.get('siteLabel','站点')}、{len(areas)} 个{project.get('areaLabel','区域')}"),
        ("监测对象", "、".join(v.get("name", "") for v in sensors.values())),
        ("测点规模", f"{len(areas) * len(layout)} 个在线测点，{len(layout)} 类/区域"),
        ("演练场景", "、".join(v.get("name", "") for k, v in scenarios.items() if k != "normal")),
        ("设计原则", "风险适配、合规可靠、冗余可续、低耗易维"),
        ("数据来源", "config/domain.json（唯一主数据源）"),
        ("生成方式", "由交付 skill 的 make_xlsx.py 自动生成；修改主数据后请全量重跑 build_all.py"),
    ]
    for i, (k, v) in enumerate(info, 5):
        ws.cell(i, 1, k).font = Font(name=CN, size=10, bold=True, color=NAVY)
        ws.cell(i, 1).fill = PatternFill("solid", fgColor=LIGHT)
        ws.merge_cells(start_row=i, start_column=2, end_row=i, end_column=8)
        ws.cell(i, 2, v).font = Font(name=CN, size=10, color="1B3348")
        ws.cell(i, 2).alignment = Alignment(vertical="center", wrap_text=True)
        ws.row_dimensions[i].height = 26
    for col, w in zip("ABCDEFGH", [16, 20, 20, 20, 20, 20, 20, 20]):
        ws.column_dimensions[col].width = w

    sheet(wb, "设备清单",
          ["层级", "名称", "型号", "数量", "单位", "关键技术参数", "选型理由", "关联测点/用途"],
          [[g.get("category", ""), it.get("name", ""), it.get("model", ""), it.get("qty", ""),
            it.get("unit", ""), it.get("params", ""), it.get("reason", ""), it.get("key", "")]
           for g in groups for it in g.get("items", [])],
          [14, 26, 20, 9, 8, 46, 46, 18],
          note="设备清单 · 数量与参数与运行系统主数据一致")

    rows = []
    for key, v in sensors.items():
        d = v.get("direction", "up")
        rows.append([
            key, v.get("name", ""), v.get("unit", ""), d,
            f"{v.get('normal', ['', ''])[0]} ~ {v.get('normal', ['', ''])[1]}",
            v.get("warning", v.get("warningLow", "—")),
            v.get("alarm", v.get("alarmLow", "—")),
            v.get("critical", v.get("criticalHigh", "—")),
            v.get("warningHigh", "—"), v.get("criticalHigh", "—"),
            v.get("model", ""), v.get("description", ""),
        ])
    sheet(wb, "阈值与量程",
          ["槽位", "监测对象", "单位", "方向", "正常基线", "预警", "告警", "严重", "上限预警", "上限严重", "型号", "监测说明"],
          rows, [10, 18, 10, 10, 16, 10, 10, 10, 12, 12, 18, 52],
          note="阈值口径 · up 越高越危险 / low 越低越危险 / range 有上下限")

    point_rows = []
    for site, face in areas:
        for l in layout:
            key = l.get("type", "")
            v = sensors.get(key, {})
            point_rows.append([
                f"{face.get('id','')}-{l.get('suffix','')}", site.get("name", ""), face.get("name", ""),
                l.get("label", ""), key, v.get("unit", ""), l.get("role", ""),
                v.get("model", ""), v.get("range", ""), "在线",
            ])
    sheet(wb, "点位部署",
          ["测点编号", project.get("siteLabel", "站点"), project.get("areaLabel", "区域"), "测点名称", "槽位", "单位", "布点角色", "设备型号", "量程", "状态"],
          point_rows, [22, 18, 24, 18, 10, 10, 20, 18, 22, 10],
          note=f"点位部署 · 共 {len(point_rows)} 个测点")

    sheet(wb, "选型矩阵",
          ["层级", "设备类别", "代表型号", "关键依据", "场景适配", "校核项"],
          [[g.get("category", ""), it.get("name", ""), it.get("model", ""),
            it.get("reason", ""), g.get("category", ""), "防护等级 / 协议 / 供电 / 反馈"]
           for g in groups for it in g.get("items", [])],
          [14, 26, 20, 48, 14, 32],
          note="选型矩阵 · 依据与适配性逐项可核验")

    by_unit = {}
    for it in items:
        u = it.get("unit", "")
        by_unit.setdefault(u, []).append(it)
    sheet(wb, "数量校核",
          ["单位", "设备类数", "数量合计", "明细"],
          [[u, len(group), round(sum(float(x.get("qty", 0) or 0) for x in group), 2),
            "、".join(x.get("name", "") for x in group[:6])] for u, group in by_unit.items()],
          [10, 12, 14, 90],
          note="数量按单位分组统计，禁止把 km 与 台 直接相加")

    p["deliverables"].mkdir(parents=True, exist_ok=True)
    out = p["deliverables"] / "设备选型说明.xlsx"
    wb.save(out)
    p["downloads"].mkdir(parents=True, exist_ok=True)
    wb.save(p["downloads"] / "device-selection.xlsx")
    print(f"[OK] xlsx: {len(items)} devices / {len(point_rows)} points -> {out.name}")


if __name__ == "__main__":
    build(Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve())
