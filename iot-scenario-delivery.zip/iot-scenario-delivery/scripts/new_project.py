"""Create a fresh, runnable contest project from a short brief.json.

Usage:
  python new_project.py --brief brief.json --out <target-dir> [--force]

What it does (deterministic, no model tokens required):
  1. Copy the proven, dependency-free starter application.
  2. Apply the brief's glossary to every text file (UI labels, CSV headers, scripts).
  3. Write config/domain.json (sites / sensors / scenarios / devices / topology).
  4. Generate README, delivery manifest, launcher and all Markdown documents.
"""
from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from _common import (
    SKILL_DIR, STARTER, TEXT_SUFFIXES, SKIP_DIRS,
    apply_glossary, apply_glossary_obj, deep_merge,
    read_json, read_text, write_json, write_text, project_paths,
)
from _gen_docs import generate_all_docs


def _copy_starter(out: Path, force: bool) -> None:
    if out.exists():
        if not force:
            raise SystemExit(f"Target already exists: {out} (use --force to overwrite)")
        shutil.rmtree(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(STARTER, out)
    for p in project_paths(out).values():
        if p.suffix == "":
            p.mkdir(parents=True, exist_ok=True)


def _retheme_files(root: Path, glossary: dict) -> int:
    count = 0
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix not in TEXT_SUFFIXES and path.name != ".gitignore":
            continue
        if any(part in SKIP_DIRS for part in path.parts):
            continue
        try:
            original = read_text(path)
        except UnicodeDecodeError:
            continue
        changed = apply_glossary(original, glossary)
        if changed != original:
            write_text(path, changed)
            count += 1
    return count


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--brief", required=True, help="Path to brief.json")
    ap.add_argument("--out", required=True, help="Target project directory")
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    brief = read_json(Path(args.brief))
    out = Path(args.out).resolve()
    glossary = brief.get("glossary", {}) or {}

    _copy_starter(out, args.force)
    n = _retheme_files(out, glossary)

    paths = project_paths(out)
    # domain.json already went through the glossary pass; now apply explicit overrides.
    domain = read_json(paths["domain"])
    if brief.get("domain"):
        domain = deep_merge(domain, apply_glossary_obj(brief["domain"], glossary))
    project = brief.get("project", {}) or {}
    domain["project"] = {**domain.get("project", {}), **project}
    write_json(paths["domain"], domain)
    write_json(paths["brief"], brief)

    generate_all_docs(paths, brief, domain)

    print("")
    print("[OK] project created:", out)
    print("     retmed files:", n)
    print("     sites:", len(domain.get("sites", [])),
          "| sensor slots:", len(domain.get("sensorTypes", {})),
          "| scenarios:", len(domain.get("scenarios", {})) - 1)
    print("")
    print("NEXT (two commands):")
    print(f'  python "{SKILL_DIR / "scripts" / "build_all.py"}" --project "{out}"')
    print(f'  cd "{out}" && npm start')
    print("")
    print("Deliberate workflow: fill brief.json -> build_all.py -> spot-check screenshots.")


if __name__ == "__main__":
    main()
