"""One command to produce the entire contest delivery package.

Usage:
  python build_all.py --project <dir> [--skip-screenshots] [--quick]

Pipeline (all deterministic, ~2 min):
  start server -> CDP screenshots -> PPT assets -> xlsx / pptx / drawio / docx
  -> API smoke -> zip packages -> integrity check -> cleanup

Only standard-library imports here; document libraries live in the interpreter
returned by find_python() (the DSH bundled Python on this machine).
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

from _common import (
    SKILL_DIR, find_edge, find_python, project_paths, read_json,
    safe_rmtree, write_json,
)

SCRIPTS = SKILL_DIR / "scripts"
NODE = "node"


def url_ok(url: str, timeout=1.5) -> bool:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            return r.status == 200
    except Exception:
        return False


def wait_url(url: str, seconds: float, label: str) -> bool:
    end = time.time() + seconds
    while time.time() < end:
        if url_ok(url):
            return True
        time.sleep(0.4)
    print(f"[WARN] {label} not ready at {url} within {seconds}s")
    return False


def run(cmd, cwd: Path, label: str, timeout=180, env=None, check=True):
    e = dict(os.environ)
    if env:
        e.update(env)
    print(f"\n>>> {label}")
    r = subprocess.run(
        [str(x) for x in cmd], cwd=str(cwd), env=e, capture_output=True,
        text=True, encoding="utf-8", errors="replace", timeout=timeout,
    )
    out = (r.stdout or "").strip()
    err = (r.stderr or "").strip()
    if out:
        print(out[-2500:])
    if r.returncode != 0:
        print(f"[{'ERROR' if check else 'WARN'}] {label} exit={r.returncode}")
        if err:
            print(err[-1200:])
        if check:
            raise RuntimeError(f"{label} failed")
    return r


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", required=True)
    ap.add_argument("--skip-screenshots", action="store_true")
    ap.add_argument("--quick", action="store_true", help="skip DOCX conversion (useful while iterating)")
    args = ap.parse_args()

    started = time.time()
    root = Path(args.project).resolve()
    p = project_paths(root)
    if not p["domain"].exists():
        raise SystemExit(f"Missing {p['domain']}; run new_project.py first")
    domain = read_json(p["domain"])
    port = int(domain.get("project", {}).get("port", 4173))
    py = find_python()
    print(f"[INFO] project : {root}")
    print(f"[INFO] python  : {py}")
    print(f"[INFO] port    : {port}")

    server = None
    edge = None
    tmpdir = None
    capture_report = None
    smoke_ok = False
    base = f"http://127.0.0.1:{port}"

    try:
        # ---- 1. server ----
        reused = url_ok(base + "/api/health")
        if reused:
            print("[INFO] reusing running server")
        else:
            server = subprocess.Popen(
                [NODE, "server/index.js"], cwd=str(root),
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
            )
            if not wait_url(base + "/api/health", 20, "server"):
                raise RuntimeError("server did not become healthy")
        print("[OK] server healthy")

        # ---- 2. screenshots ----
        shots_ok = False
        edge_path = find_edge()
        if args.skip_screenshots or not edge_path:
            print("[WARN] screenshots skipped" + (" (Edge not found)" if not edge_path else ""))
        else:
            tmpdir = Path(tempfile.mkdtemp(prefix="iot-capture-"))
            cdp_port = 9222
            while url_ok(f"http://127.0.0.1:{cdp_port}/json/version", 0.4) and cdp_port < 9240:
                cdp_port += 1
            edge = subprocess.Popen(
                [str(edge_path), "--headless=new", "--disable-gpu", "--no-sandbox",
                 "--disable-crashpad", "--no-first-run", "--no-default-browser-check",
                 "--remote-allow-origins=*", f"--remote-debugging-port={cdp_port}",
                 f"--user-data-dir={tmpdir}", "about:blank"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
            )
            if wait_url(f"http://127.0.0.1:{cdp_port}/json/version", 20, "Edge CDP"):
                try:
                    r = run(
                        [NODE, str(SCRIPTS / "capture.mjs")], root, "CDP screenshots",
                        timeout=210,
                        env={"CDP_PORT": str(cdp_port), "SHOT_DIR": str(p["shots"])},
                        check=False,
                    )
                    for line in (r.stdout or "").splitlines():
                        if line.startswith("CAPTURE_REPORT "):
                            capture_report = json.loads(line[15:])
                    shots_ok = bool(capture_report and capture_report.get("ok"))
                except subprocess.TimeoutExpired:
                    print("[WARN] screenshot step timed out; continuing with placeholders")
            else:
                print("[WARN] Edge CDP unavailable (sandbox may block named pipes); using placeholders")

        # ---- 3. PPT image assets ----
        required_shots = ["01-overview.png", "02-face.png", "03-alarms.png",
                          "06-topology.png", "07-devices.png", "09-scenario-live.png"]
        have_all = all((p["shots"] / f).exists() for f in required_shots)
        if have_all and shots_ok:
            run([py, str(root / "scripts" / "prepare_ppt_assets.py")], root,
                "PPT image assets", timeout=120, check=False)
        else:
            run([py, str(SCRIPTS / "_placeholder_assets.py"), str(root)], root,
                "placeholder PPT assets", timeout=60)
            print("[WARN] PPT uses placeholder images; rerun without --skip-screenshots for real captures")

        # ---- 4. documents / artifacts ----
        run([py, str(SCRIPTS / "make_xlsx.py"), str(root)], root, "device workbook", timeout=120)
        run([py, str(SCRIPTS / "make_ppt.py"), str(root)], root, "14-slide deck", timeout=120)
        run([py, str(SCRIPTS / "make_topology.py"), str(root)], root, "topology project file", timeout=60)
        if not args.quick:
            run([py, str(SCRIPTS / "make_docx.py"), str(root)], root, "Word documents", timeout=180)

        # ---- 5. smoke ----
        try:
            r = run([NODE, str(SCRIPTS / "smoke.mjs")], root, "API smoke", timeout=90, check=False)
            smoke_ok = "SMOKE OK" in (r.stdout or "")
        except subprocess.TimeoutExpired:
            print("[WARN] smoke timed out")

        # ---- 6. package + check ----
        run([py, str(SCRIPTS / "package.py"), str(root)], root, "zip packages", timeout=120)
        rc = run([py, str(SCRIPTS / "check.py"), str(root)], root, "integrity check",
                 timeout=120, check=False)
        check_ok = rc.returncode == 0

        elapsed = round(time.time() - started, 1)
        summary = {
            "ok": check_ok, "elapsed_seconds": elapsed, "screenshots": shots_ok,
            "smoke": smoke_ok,
            "console_errors": (capture_report or {}).get("errors", [])[:10],
            "overflow": (capture_report or {}).get("overflow", [])[:10],
            "deliverables": str(p["deliverables"]),
        }
        write_json(p["config"] / "build-report.json", summary)
        print("\n" + "=" * 62)
        print(f"BUILD {'OK' if check_ok else 'INCOMPLETE'}  in {elapsed}s")
        print(f"  screenshots : {'real' if shots_ok else 'placeholder'}")
        print(f"  api smoke   : {'pass' if smoke_ok else 'check output'}")
        print(f"  deliverables: {p['deliverables']}")
        if summary["console_errors"]:
            print("  console errors:", summary["console_errors"][:3])
        if summary["overflow"]:
            print("  overflow candidates:", summary["overflow"][:5])
        print("=" * 62)
        return 0 if check_ok else 2

    finally:
        if server and server.poll() is None:
            server.terminate()
            try:
                server.wait(timeout=5)
            except Exception:
                server.kill()
        if edge and edge.poll() is None:
            try:
                subprocess.run(["taskkill", "/PID", str(edge.pid), "/T", "/F"],
                               capture_output=True, timeout=15)
            except Exception:
                edge.terminate()
        if tmpdir:
            safe_rmtree(tmpdir)


if __name__ == "__main__":
    sys.exit(main())
