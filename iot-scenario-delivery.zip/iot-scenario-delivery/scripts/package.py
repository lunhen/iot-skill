"""Build the source zip and the all-in-one contest delivery zip.

Usage: python package.py <project-root>
"""
from __future__ import annotations

import json
import sys
import zipfile
from pathlib import Path

from _common import project_paths, read_json, write_text

SOURCE_DIRS = ["server", "public", "config", "docs", "topology", "scripts"]
SOURCE_FILES = ["README.md", "package.json", ".gitignore", "启动系统.bat"]
EXCLUDE_NAMES = {".tmp-edge", "node_modules", "__pycache__", "ppt-assets"}
DELIVERABLE_FILES = [
    "项目演示.pptx", "设备选型说明.docx", "设备选型说明.xlsx",
    "AI提示词全过程记录.docx", "演示脚本与答辩要点.docx",
    "项目完整源码.zip", "交付清单.md",
]


def _add_tree(zf: zipfile.ZipFile, base: Path, arc_prefix: str):
    """arc_prefix is relative to base itself, e.g. ('server/', 'index.js') -> 'server/index.js'."""
    for path in sorted(base.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(base)
        if any(part in EXCLUDE_NAMES for part in rel.parts):
            continue
        arc = (arc_prefix.rstrip("/") + "/" if arc_prefix else "") + str(rel).replace("\\", "/")
        zf.write(path, arc)


def build(root: Path):
    p = project_paths(root)
    domain = read_json(p["domain"])
    name = domain.get("project", {}).get("name", "智安")
    p["deliverables"].mkdir(parents=True, exist_ok=True)

    src_zip = p["deliverables"] / "项目完整源码.zip"
    with zipfile.ZipFile(src_zip, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for d in SOURCE_DIRS:
            if (root / d).exists():
                _add_tree(zf, root / d, d)
        for f in SOURCE_FILES:
            if (root / f).exists():
                zf.write(root / f, f)
    print(f"[OK] source zip -> {src_zip.name} ({src_zip.stat().st_size // 1024} KB)")

    all_zip = p["deliverables"] / f"{name}-参赛交付包.zip"
    with zipfile.ZipFile(all_zip, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for f in DELIVERABLE_FILES:
            path = p["deliverables"] / f
            if path.exists():
                zf.write(path, f)
        if p["shots"].exists():
            _add_tree(zf, p["shots"], "screenshots")
        if (p["topology"] / "application-topology.drawio").exists():
            zf.write(p["topology"] / "application-topology.drawio", "topology/application-topology.drawio")
        if (p["topology"] / "application-topology.json").exists():
            zf.write(p["topology"] / "application-topology.json", "topology/application-topology.json")
        for d in p["docs"].glob("*.md"):
            zf.write(d, "docs/" + d.name)
    print(f"[OK] delivery zip -> {all_zip.name} ({all_zip.stat().st_size // 1024} KB)")

    manifest = [str(x.relative_to(root)).replace("\\", "/") for x in sorted(all_zip.parent.rglob("*")) if x.is_file()]
    write_text(p["config"] / "build-manifest.json", json.dumps({
        "project": name, "source_zip": src_zip.name, "delivery_zip": all_zip.name,
        "files": manifest,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    build(Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve())
