"""Generate README, delivery manifest, launcher and the three contest documents.

All prose is assembled from config/domain.json + brief.json so numbers, device
models and thresholds always agree with the running system.
"""
from __future__ import annotations

from _common import write_text, write_json

SLOT_ORDER = ["ch4", "ch4b", "co", "o2", "temp", "humidity", "dust", "wind"]


def _c(brief, key, default):
    v = (brief.get("content") or {}).get(key)
    return v if v else default


def _p(domain, key, default=""):
    return (domain.get("project") or {}).get(key, default)


def _sites(domain):
    return domain.get("sites", [])


def _areas(domain):
    return [f for s in _sites(domain) for f in s.get("faces", [])]


def _slots(domain):
    st = domain.get("sensorTypes", {})
    return [(k, st[k]) for k in SLOT_ORDER if k in st]


def _scenarios(domain):
    sc = domain.get("scenarios", {})
    return [(k, v) for k, v in sc.items() if k != "normal"]


def _devices(domain):
    return domain.get("devices", [])


def _all_items(domain):
    return [it for g in _devices(domain) for it in g.get("items", [])]


def _defaults(brief, domain):
    """Fallback prose, derived from the live configuration so it is never stale."""
    site_label = _p(domain, "siteLabel", "站点")
    area_label = _p(domain, "areaLabel", "区域")
    point_label = _p(domain, "pointLabel", "测点")
    topic = _p(domain, "contestTopic", "安全物联网监测系统")
    slots = _slots(domain)
    primary = slots[0][1] if slots else {"name": "风险因子", "unit": ""}
    return {
        "background": (
            f"本方案面向{topic}场景，覆盖 {len(_sites(domain))} 个{site_label}、"
            f"{len(_areas(domain))} 个{area_label}、{len(_areas(domain)) * len(slots)} 个{point_label}，"
            f"围绕 {primary.get('name')} 等核心风险，构建「感知采集—边缘汇聚—网络传输—规则研判—"
            "联动处置—闭环归档」的完整链路。系统采用零第三方运行时依赖的 Node.js 服务端与原生 Web "
            "可视化前端，内置可复现的实时仿真、分级告警引擎、风险演练与历史时序查询，适合现场离线演示。"
        ),
        "pain": [
            {"title": "风险发现滞后", "desc": "依赖人工巡检与事后报表，异常从发生到被发现存在明显时间窗，缺少连续在线感知。", "metric": "人工巡检 · 小时级"},
            {"title": "测点分散难统管", "desc": f"多{site_label}、多{area_label}数据分散在各本地系统，缺少统一口径与分级视图。", "metric": f"{len(_sites(domain))} {site_label} · {len(_areas(domain))} {area_label}"},
            {"title": "告警与处置脱节", "desc": "阈值告警仅停留在提示层，未联动执行设备，也未形成确认—复核—闭环的证据链。", "metric": "闭环率不可见"},
            {"title": "演练不可复现", "desc": "现场演示依赖临时造数，风险链路无法稳定复现，难以验证采集到处置的完整闭环。", "metric": "演示口径不一致"},
        ],
        "goals": [
            {"title": "全域在线感知", "desc": f"{len(_areas(domain)) * len(slots)} 个{point_label}按 2 秒周期采样，SSE 实时推送，断线自动重连。"},
            {"title": "分级研判与联动", "desc": "预警 / 告警 / 严重告警三级阈值，叠加连续采样去抖与自动联动编排。"},
            {"title": "异常闭环归档", "desc": "确认、复核、闭环、处置时间线与联动执行记录全程留痕，支持 CSV 导出。"},
            {"title": "可复现风险演练", "desc": f"{len(_scenarios(domain))} 类演练场景一键注入，固定随机种子保证演示可复现。"},
        ],
        "principles": ["风险适配：按监测对象的危险等级与工况差异配置点位密度", "合规可靠：选用符合场景防护与防爆等级要求的工业设备", "冗余可续：边缘缓存与环网自愈保障断网不断测", "低耗易维：统一协议与台账，减少现场标校与运维成本"],
        "architecture": [
            {"layer": "感知层", "items": [k[1].get("name", "") for k in slots[:4]], "note": "多类环境测点 + 视频复核"},
            {"layer": "边缘层", "items": ["边缘分站", "本地预处理", "断网缓存"], "note": f"每{area_label} 1 台，多路汇聚"},
            {"layer": "网络层", "items": ["环网交换机", "冗余光纤", "自愈 <50 ms"], "note": "单点断纤不影响回传"},
            {"layer": "平台层", "items": ["采集接入", "告警引擎", "时序库", "工单服务"], "note": "双机热备，规则集中配置"},
            {"layer": "应用层", "items": ["集团调度", "现场值班", "移动巡检", "监管接口"], "note": "多端分级查看与闭环"},
        ],
        "innovations": [
            {"title": "端—边—网—云—用五层闭环", "desc": "从物理感知到调度应用形成完整链路，每层都有可验证的状态与指标。", "anchor": "架构可验收"},
            {"title": "可注入的风险演练沙盘", "desc": "四类场景按时间轴推进，实时改写测点值并触发真实告警与联动。", "anchor": "演示可复现"},
            {"title": "阈值去抖 + 分级升级", "desc": "连续采样去抖抑制误报，等级升级自动生成新事件并保留原处置时间线。", "anchor": "研判可信"},
            {"title": "交付物同源生成", "desc": "设备台账、阈值表、点位表、拓扑图与系统主数据来自同一份配置，口径一致。", "anchor": "工程化一致"},
        ],
        "values": [
            {"title": "安全价值", "desc": "把异常发现从小时级压缩到秒级，超限自动联动执行设备并留痕。", "kpi": "2 s 采样"},
            {"title": "管理价值", "desc": "多层级态势与闭环率、在线率、链路健康分，为考核提供量化口径。", "kpi": "闭环可追溯"},
            {"title": "落地价值", "desc": "零运行时依赖、单机即可离线演示，接口层预留可平滑对接真实设备。", "kpi": "离线可运行"},
        ],
        "limits": [
            {"title": "数据源为仿真", "desc": "未接入真实 PLC 与现场仪表。", "plan": "按 OPC UA / MQTT / Modbus 适配接口层"},
            {"title": "视频仅占位", "desc": "告警抓拍为复核证据占位，未实现行为识别。", "plan": "接入边缘 AI 推理盒"},
            {"title": "规则较简单", "desc": "以阈值 + 去抖为主，未引入时序预测模型。", "plan": "引入孤立森林 / LSTM 趋势预警"},
            {"title": "单机内存存储", "desc": "演示版未做持久化与双机热备。", "plan": "迁移 TimescaleDB + Redis + 主备"},
        ],
        "roadmap": [
            {"phase": "一期 · 打通", "items": "真实设备接入、协议适配、数据落库"},
            {"phase": "二期 · 智能", "items": "趋势预测、多因子融合研判、误报自学习"},
            {"phase": "三期 · 规模", "items": "多站点横向扩展、权限分级、监管接口开放"},
        ],
        "qa": [
            {"q": "为什么不用现成物联网平台，而要自己写？", "a": "赛题要求自主完成需求分析与功能设计；自研可完整掌控数据契约、告警状态机与演示可复现性，也避免第三方平台授权与离线不可用。"},
            {"q": "三级阈值是怎么定的？", "a": "依据场景风险分级与行业规程口径，结合正常基线分布设置预警、告警、严重告警三档，并在系统中集中配置、可按需调整。"},
            {"q": "单阈值误报怎么处理？", "a": "采用连续采样去抖 + 等级升级机制，只有连续多次越限才生成事件，并为每个事件保留完整时间线。"},
            {"q": "断网了数据会不会丢？", "a": "边缘分站具备本地预处理与断网缓存，环网支持单点断纤自愈；恢复后补传缓存数据。"},
            {"q": "历史数据能长期保存吗？", "a": "演示版用内存模拟时序库；生产建议原始高频数据在线保留 90 天、分钟级聚合保留 5 年。"},
            {"q": "AI 生成的内容可靠吗？", "a": "所有关键口径由同一份配置驱动并经过单元测试、接口冒烟与截图目检；AI 负责初稿与重复劳动，人工负责阈值、合规与结论把关。"},
            {"q": "为什么没有接入真实传感器？", "a": "现场演示环境不具备真实设备，接口层已按标准协议预留；仿真数据由固定随机种子驱动，保证链路验证可复现。"},
            {"q": f"多个{site_label}的配置有什么差异？", "a": "按风险等级设置不同的基线风险值、点位密度与联动策略，界面可逐级下钻查看。"},
            {"q": "网络较差时页面会卡吗？", "a": "前端仅订阅增量状态，SSE 断线自动重连；图表为轻量 Canvas 绘制，无第三方运行时依赖。"},
            {"q": "如何保证交付材料与系统一致？", "a": "设备台账、阈值、点位、拓扑与文档均由 config/domain.json 同源生成，构建脚本一键全量重跑。"},
        ],
        "demo": [
            {"time": "00:00—01:00", "title": "综合态势", "steps": ["打开首页，说明站点/区域/测点规模", "查看在线率、活动告警、24h 告警分布与链路健康"]},
            {"time": "01:00—02:30", "title": "区域监控", "steps": ["下钻到首个区域，点击主风险测点", "查看实时值、阈值、趋势曲线与设备联动状态"]},
            {"time": "02:30—04:30", "title": "情景演练", "steps": ["点击右上角「情景演练」选择场景并注入", "观察 8—12 秒内数值越限、自动联动与告警生成"]},
            {"time": "04:30—06:00", "title": "告警闭环", "steps": ["进入告警中心，打开新告警查看研判原因与时间线", "执行确认并复核 → 确认闭环，导出 CSV"]},
            {"time": "06:00—07:00", "title": "历史与拓扑", "steps": ["回溯历史曲线与阈值线", "查看五层拓扑、链路指标与设备台账"]},
            {"time": "07:00—08:00", "title": "价值与局限", "steps": ["用 PPT 收束创新亮点与落地价值", "主动说明仿真边界与后续路线图"]},
        ],
        "compliance": ["设备防护等级与场景环境适配", "信号制式与工业总线协议一致", "执行机构具备反馈校验", "边缘节点具备断电续航与数据缓存"],
    }


def generate_all_docs(paths, brief, domain):
    d = _defaults(brief, domain)
    c = lambda k: _c(brief, k, d.get(k, []))
    name = _p(domain, "name", "智安")
    full = _p(domain, "fullName", "安全物联网监测平台")
    topic = _p(domain, "contestTopic", "安全物联网监测系统")
    module = _p(domain, "module", "模块 C：场景创新与设计")
    tagline = _p(domain, "tagline", "让每一次异常，都被看见、被研判、被闭环")
    site_label = _p(domain, "siteLabel", "站点")
    area_label = _p(domain, "areaLabel", "区域")
    point_label = _p(domain, "pointLabel", "测点")
    sites, areas, slots = _sites(domain), _areas(domain), _slots(domain)
    scenarios, devices = _scenarios(domain), _devices(domain)
    items = _all_items(domain)
    points = len(areas) * len(slots)

    # ---------------- README ----------------
    readme = f"""# {name} · {full}

> {module} ｜ {topic}
>
> {len(sites)} 个{site_label} · {len(areas)} 个{area_label} · {points} 个{point_label} · 端—边—网—云—用五层架构

## 一、项目简介

{c('background')}

系统采用无第三方运行时依赖的 Node.js 服务端 + 原生 Web 可视化前端，内置实时数据仿真、告警规则引擎、{len(scenarios)} 类风险演练场景、历史时序查询、告警闭环、链路拓扑与设备台账，适合竞赛现场离线演示。

## 二、核心能力

| 能力 | 实现 |
| --- | --- |
| 多{site_label} / 多{area_label}切换 | 三级导航，{len(sites)} 个{site_label}、{len(areas)} 个{area_label}自由切换 |
| 环境感知 | {len(slots)} 类测点 / {area_label}，共 {points} 个在线{point_label} |
| 实时数据链路 | 服务端 2s 采样，SSE 推送，断线自动重连 |
| 告警分级研判 | 预警 / 告警 / 严重告警三级，阈值集中配置 |
| 自动联动与闭环 | 声光、断电、降尘、通风、抓拍、工单；确认—复核—闭环留痕 |
| 风险演练 | {len(scenarios)} 类场景一键注入，支持一键恢复 |
| 历史与拓扑 | 24h / 8h / 1h 查询、阈值线、统计、CSV 导出；五层拓扑与链路指标 |
| 工程化交付 | 设备选型说明、AI 提示词全过程记录、PPT、拓扑工程文件、完整源码 |

## 三、快速运行

环境要求：**Node.js ≥ 20**，无需安装任何 npm 依赖。

```bash
npm start        # 或 node server/index.js
npm test         # 告警引擎、演练场景、历史查询
```

浏览器打开：<http://127.0.0.1:{_p(domain, 'port', 4173)}>

## 四、8 分钟演示路径

""" + "\n".join(
        f"{i}. **{s['title']}**（{s['time']}）：" + "；".join(s["steps"])
        for i, s in enumerate(c("demo"), 1)
    ) + f"""

## 五、目录结构

```text
├─ config/domain.json         # 业务主数据（站点/测点/阈值/设备/场景）—— 唯一数据源
├─ config/brief.json          # 本次赛题的主题与文案配置
├─ server/                    # 无依赖 Node.js 服务端（HTTP / SSE / 告警引擎 / 仿真）
├─ public/                    # 单页可视化前端（原生 JS + Canvas 图表）
├─ docs/                      # 设备选型、AI 提示词记录、演示脚本（Markdown 源）
├─ deliverables/              # PPT、DOCX、XLSX、截图、源码包
├─ topology/                  # draw.io 工程文件 + 机器可读 JSON
└─ scripts/                   # 文档、表格、拓扑、截图生成脚本
```

## 六、数据说明

- 演示数据由固定随机种子驱动，**可复现**；场景注入会覆盖指定{area_label}测点目标值。
- 2s 实时数据内存滚动；历史库启动时生成 24h 基线数据，运行期按 30s 追加。
- 阈值、联动策略与设备参数集中在 `config/domain.json`，便于按现场制度调整。

## 七、已知边界

""" + "\n".join(f"- **{x['title']}**：{x['desc']} 后续：{x['plan']}。" for x in c("limits")) + f"""

## 八、交付材料

| 材料 | 文件 |
| --- | --- |
| 项目演示 PPT | `deliverables/项目演示.pptx` |
| 应用拓扑工程文件 | `topology/application-topology.drawio`、`.json` |
| 项目完整源码 | `deliverables/项目完整源码.zip` |
| 设备选型说明 | `deliverables/设备选型说明.docx` / `.xlsx` |
| AI 提示词全过程记录 | `deliverables/AI提示词全过程记录.docx` |
| 演示脚本与答辩要点 | `deliverables/演示脚本与答辩要点.docx` |
| 系统截图 | `deliverables/screenshots/` |

---

**{name}** · {tagline}
"""
    write_text(paths["root"] / "README.md", readme)

    # ---------------- Device selection ----------------
    dev = f"""# {topic} 设备选型说明

> {name} · {module} · V1.0
>
> 本文档由 `config/domain.json` 同源生成，设备数量、参数、阈值与运行系统完全一致。

## 1 项目背景与建设目标

{c('background')}

建设目标：实现环境安全感知、状态监控、异常研判、自动联动与处置闭环，形成可演示、可复现、可验收的完整链路。

## 2 风险分析与监测需求

| 风险类别 | 监测对象 | 关键指标 | 处置诉求 |
| --- | --- | --- | --- |
""" + "\n".join(
        f"| {x['title']} | {slots[i % len(slots)][1]['name'] if slots else '—'} | {x['metric']} | 实时告警 + 联动处置 |"
        for i, x in enumerate(c("pain"))
    ) + f"""

共部署 {points} 个{point_label}（{len(areas)} 个{area_label} × {len(slots)} 类），另配视频复核与执行机构。

## 3 选型原则与合规依据

""" + "\n".join(f"{i}. {x}" for i, x in enumerate(c("principles"), 1)) + """

合规底线：

""" + "\n".join(f"- {x}" for x in c("compliance")) + f"""

## 4 总体设备架构

| 层级 | 职责 | 代表设备 |
| --- | --- | --- |
""" + "\n".join(
        f"| {g.get('category','—')} | {['感知采集','汇聚与回传','告警联动执行','平台承载与服务'][i % 4]} | " +
        "、".join(it.get("name", "") for it in g.get("items", [])[:3]) + " |"
        for i, g in enumerate(devices)
    ) + """

## 5 设备清单

""" + "\n".join(
        f"### 5.{i} {g.get('category','—')}\n\n"
        "| 名称 | 型号 | 数量 | 单位 | 关键技术参数 | 选型理由 |\n"
        "| --- | --- | ---: | --- | --- | --- |\n" +
        "\n".join(
            f"| {it.get('name','')} | {it.get('model','')} | {it.get('qty','')} | {it.get('unit','')} | "
            f"{it.get('params','')} | {it.get('reason','')} |"
            for it in g.get("items", [])
        ) + "\n"
        for i, g in enumerate(devices, 1)
    ) + f"""

合计 {len(items)} 类设备；数量与 `config/domain.json` 中 `devices` 保持一致。

## 6 关键设备选型论证

""" + "\n".join(
        f"### 6.{i} {it.get('name','')} {it.get('model','')}\n\n"
        f"- **参数**：{it.get('params','')}\n"
        f"- **选型理由**：{it.get('reason','')}\n"
        f"- **适配性**：满足{area_label}长期在线监测与联动执行要求。\n"
        for i, it in enumerate(items[:6], 1)
    ) + f"""

## 7 各{site_label}差异化配置

| {site_label} | 位置 | 风险基线 | {area_label}数 | 配置重点 |
| --- | --- | ---: | ---: | --- |
""" + "\n".join(
        f"| {s.get('name','')} | {s.get('location','')} | {s.get('riskBase','')} | {len(s.get('faces',[]))} | {s.get('gasLevel', s.get('level',''))} |"
        for s in sites
    ) + f"""

## 8 {area_label}部署方案

每个{area_label}部署 {len(slots)} 类{point_label}，位置按风险源分布：

| 测点 | 类型 | 布点角色 | 正常基线 | 预警 | 告警 | 严重 |
| --- | --- | --- | --- | ---: | ---: | ---: |
""" + "\n".join(
        f"| {key} | {v.get('name','')} ({v.get('unit','')}) | " +
        (next((l.get("role", "") for l in domain.get("sensorLayout", []) if l.get("type") == key), "—")) +
        f" | {v.get('normal',['—','—'])[0]}~{v.get('normal',['—','—'])[1]} | "
        f"{v.get('warning', v.get('warningLow','—'))} | {v.get('alarm', v.get('alarmLow','—'))} | {v.get('critical', v.get('criticalHigh','—'))} |"
        for key, v in slots
    ) + """

## 9 网络与供电设计

- **网络**：边缘分站汇聚多路 RS485，环网交换机组成冗余环，单点断纤自愈 <50 ms。
- **供电与防护**：现场设备按场景防护等级选型，边缘节点具备断电续航与本地缓存。
- **平台**：双机热备承载采集、时序库、告警引擎与可视化服务。

## 10 阈值与联动策略

### 10.1 监测阈值

阈值统一在 `config/domain.json` 中维护，`server/alarm.js` 按方向（`up` / `low` / `range`）统一研判，避免前后端口径漂移。

### 10.2 联动策略

""" + "\n".join(
        f"- **{v.get('name','')}（{v.get('code','')}）**：{v.get('description','')} 预期等级 {v.get('level','')}，时长 {v.get('duration','')} s。"
        for _, v in scenarios
    ) + """

## 11 安装、标校与运维

1. 按点位表安装并核对地址编码，接入分站并完成通路测试。
2. 投运前逐点标校零点与量程，记录标校日期与有效期。
3. 每月做一次告警链路演练，校验联动执行与反馈信号。
4. 台账、阈值与系统主数据同步更新，变更后回归 `npm test`。

## 12 选型结论

本方案在风险覆盖、合规性、可靠性与可演示性之间取得平衡；所有参数与运行系统同源，可现场逐项核验。正式采购以现场会审与设备证书为准。
"""
    write_text(paths["docs"] / "设备选型说明.md", dev)

    # ---------------- Prompt engineering log ----------------
    versions = _c(brief, "promptVersions", [
        {"id": f"P{i:02d}", "goal": g, "change": "在上一版基础上补充约束", "result": "输出更贴合验收口径"}
        for i, g in enumerate([
            "赛题拆解与交付物清单", "数据契约与状态机", "告警引擎与去抖", "可视化风格与信息架构",
            "场景演练沙盘", "文档与 PPT 生成", "服务接口与冒烟测试", "截图与视觉验收",
            "设备台账与阈值表", "拓扑工程文件", "交付包一致性核验",
        ], 1)
    ])
    defects = _c(brief, "defects", [
        {"id": f"D{i:02d}", "symptom": s, "cause": c1, "fix": f1}
        for i, (s, c1, f1) in enumerate([
            ("页面显示英文原始状态码", "状态字段与中文分类字段同名被覆盖", "拆分 level 与 gasLevel 两个字段"),
            ("中文出现乱码", "Windows PowerShell 5.1 以 ANSI 读取 UTF-8", "统一用 Python 显式 UTF-8 读写"),
            ("截图脚本挂起", "SSE 长连接使 --virtual-time-budget 不结束", "改用 CDP Page.captureScreenshot"),
            ("改了代码但截图不变", "浏览器缓存旧的 js/css", "资源加版本号 + 服务端 no-store"),
            ("新告警面板不渲染", "渲染函数抛异常但被事件回调吞掉", "CDP 监听 Runtime.exceptionThrown"),
            ("PPT 文件名几乎看不见", "深色背景上用了低对比色", "统一改用高对比文本色"),
            ("截图在 PPT 里偏暗", "深色 UI 截图直接使用", "生成素材时统一提亮 1.08 倍"),
            ("Excel 防爆等级列错误", "设备参数字符串缺少 Ex 标识", "补全参数并修正自动分类逻辑"),
            ("设备总量单位混算", "把 km 与台相加", "按单位分组统计"),
            ("文案数值与截图对不上", "PPT 写死了瞬时采样值", "改用区间表述，避免硬编码瞬时值"),
        ], 1)
    ])
    prompt_log = f"""# AI 提示词撰写、迭代优化与调试全过程记录

> {name} · {module}
>
> 本记录由交付 skill 按工程化模板生成，版本号 / 输出效果 / 缺陷与修复均已结构化。
> **现场提交前请在第 3 节补入本次真实提示词原文与截图编号**；把实际提示词写入
> `config/brief.json` 的 `content.promptVersions` / `content.defects` 后重新构建即可自动更新本文档。

## 0 记录说明

- 记录范围：从赛题解析、方案设计、功能开发到交付材料生成的全过程。
- 记录口径：每个版本记录「目标 / 关键约束 / 修改原因 / 输出效果」，每个缺陷记录「现象 / 根因 / 修复」。
- 工具链：AI 辅助生成 + 本地单元测试 + 接口冒烟 + 无头浏览器视觉验收 + 一键构建核验。

## 1 AI 辅助开发工作流

```text
赛题解析 → 交付物清单 → 数据契约 → 后端状态机 → 可视化实现 → 联调截图
        → 文档 / 表格 / PPT / 拓扑 → 打包核验 → 现场演示脚本
```

关键做法：把「确定性工作」交给脚本（同源数据、文档排版、打包、截图），把「判断性工作」留给人（阈值口径、合规依据、创新点、局限说明）。

## 2 提示词版本总览

| 版本 | 目标 | 修改原因 | 输出效果 |
| --- | --- | --- | --- |
""" + "\n".join(
        f"| {v.get('id','')} | {v.get('goal','')} | {v.get('change','')} | {v.get('result','')} |"
        for v in versions
    ) + """

## 3 关键提示词与输出评审

### 3.1 P1：任务拆解与交付物清单

> 提示词要点：先列全交付物与验收口径，再动手写代码；明确「可运行系统 + 5 类材料 + 现场演示」。

输出评审：避免只做一个页面而遗漏拓扑工程文件与提示词记录。

### 3.2 P2：数据契约与状态机

> 提示词要点：站点—区域—测点三级模型；告警状态 `open → acknowledged → resolved`；所有主数据单点定义。

输出评审：前后端共用 `config/domain.json`，杜绝口径漂移。

### 3.3 P3：告警引擎与去抖

> 提示词要点：三级阈值 + 连续采样去抖 + 等级升级生成新事件 + 保留处置时间线。

输出评审：`npm test` 覆盖阈值边界、升级、闭环与历史查询。

### 3.4 P4：可视化风格与信息架构

> 提示词要点：深色工业控制台、6 个一级页面、2s 增量刷新、关键指标首屏可见。

输出评审：截图逐页目检，检查溢出、对比度与空面板。

### 3.5 P5：场景演练沙盘

> 提示词要点：按时间轴注入目标值，触发真实告警与联动，支持一键恢复且可复现。

输出评审：接口冒烟校验非法场景返回 400，合法场景生成事件。

### 3.6 P6：文档与 PPT 生成

> 提示词要点：所有材料从同一份配置生成，数值与系统一致；禁止手写死值。

输出评审：构建脚本一键全量重跑，避免「改了数据忘改文档」。

## 4 迭代与调试记录

| 编号 | 现象 | 根因 | 修复 |
| --- | --- | --- | --- |
""" + "\n".join(
        f"| {x.get('id','')} | {x.get('symptom','')} | {x.get('cause','')} | {x.get('fix','')} |"
        for x in defects
    ) + """

## 5 提示词工程方法总结

### 5.1 一个高效提示词的六要素

1. 角色与场景；2. 交付物清单；3. 数据契约；4. 验收标准；5. 环境与约束；6. 反例与禁止项。

### 5.2 三个反模式

- 只说「做一个系统」而不列交付物，导致反复补材料。
- 让模型手写数值，导致文档与系统对不上。
- 不要求可运行验证，导致演示现场才发现白屏。

### 5.3 人工必须把关的 5 件事

阈值合规性、设备参数真实性、创新点可验证性、局限说明的诚实度、现场演示路径的连贯性。

## 6 AI 贡献与责任边界

AI 承担代码骨架、样式、文档排版与重复劳动；人负责赛题解读、方案取舍、阈值与合规口径、最终验收。所有结论以现场可运行系统与同源数据为准。

## 7 可复用提示词模板

```text
请按以下约束完成【赛题名称】的完整交付：
1. 交付物：可运行系统 + 演示 PPT + 应用拓扑工程文件 + 完整源码 + 设备选型说明 + AI 提示词全过程记录；
2. 数据契约：站点—区域—测点三级，主数据单点定义，告警状态机 open/acknowledged/resolved；
3. 验收标准：npm test 通过、关键接口冒烟通过、6 张以上页面截图无溢出、材料数值与系统一致；
4. 环境约束：零第三方运行时依赖、离线可运行、Node.js 20+；
5. 禁止项：不要在文档里写死瞬时采样值，不要用 PowerShell 改写 UTF-8 中文文件。
```
"""
    write_text(paths["docs"] / "AI提示词全过程记录.md", prompt_log)

    # ---------------- Demo script ----------------
    demo_doc = f"""# 演示脚本与答辩要点

> {name} · {topic} · 建议演示时长 8 分钟

## 1 演示前检查（30 秒）

1. `npm start` 正常，浏览器打开 <http://127.0.0.1:{_p(domain, 'port', 4173)}> 首屏有数据。
2. `npm test` 通过；右上角时间与系统时间一致。
3. 关闭无关标签，浏览器全屏，分辨率 ≥1600×1000。
4. PPT、拓扑工程文件、源码包、文档均已生成且可打开。

## 2 8 分钟演示路径

""" + "\n".join(
        f"### {s['time']} {s['title']}\n\n" + "\n".join(f"- {x}" for x in s["steps"]) + "\n"
        for s in c("demo")
    ) + """

## 3 答辩 Q&A（建议回答）

""" + "\n".join(
        f"### Q{i}：{x['q']}\n\n{x['a']}\n"
        for i, x in enumerate(c("qa"), 1)
    ) + """

## 4 演示「不要做」清单

- 不要在演练过程中刷新页面，会重置倒计时与注入状态。
- 不要临时修改阈值，会导致 PPT 与文档口径不一致。
- 不要现场联网安装依赖，系统零依赖即可运行。
- 不要把仿真数据说成现场真实数据，主动说明边界更可信。

## 5 现场故障回退

| 故障 | 回退动作 |
| --- | --- |
| 页面白屏 | 检查服务是否存活；用 `node server/index.js` 重启并刷新 |
| 演练无告警 | 点击「恢复正常工况」后重新注入，等待 8—12 秒 |
| PPT 打不开 | 使用 `deliverables/` 下的 PDF 或截图目录做兜底讲解 |
| 端口被占用 | 修改 `config/domain.json` 的 `project.port`，重启服务 |
| 浏览器缓存旧版 | 强制刷新（Ctrl+F5），或在地址后加 `?v=<新值>` |
"""
    write_text(paths["docs"] / "演示脚本与答辩要点.md", demo_doc)

    # ---------------- Delivery manifest + launcher ----------------
    manifest = f"""# 交付清单 · {name}

> {module} ｜ {topic}

| 序号 | 交付物 | 文件 / 目录 | 说明 |
| --- | --- | --- | --- |
| 01 | 项目演示 PPT | `项目演示.pptx` | 14 页：痛点、方案、硬件、软件、链路、演练、创新、AI、价值、局限、演示路径 |
| 02 | 应用拓扑工程文件 | `../topology/application-topology.drawio` | draw.io 可直接打开；同名 `.json` 为机器可读版本 |
| 03 | 项目完整源码 | `项目完整源码.zip` | server + public + config + docs + topology + scripts，零第三方运行时依赖 |
| 04 | 设备选型说明 | `设备选型说明.docx` / `设备选型说明.xlsx` | Word 说明 + 多工作表 Excel（清单、阈值、点位、选型矩阵、校核） |
| 05 | AI 提示词全过程记录 | `AI提示词全过程记录.docx` | 提示词版本、关键提示词、缺陷与修复、工程化方法 |
| 06 | 演示脚本与答辩要点 | `演示脚本与答辩要点.docx` | 8 分钟路径、答辩 Q&A、故障回退 |
| 07 | 系统截图 | `screenshots/` | 综合态势、区域监控、告警、告警详情、历史、拓扑、设备、演练弹窗、演练实况 |
| 08 | 本地运行入口 | `../启动系统.bat` / `../server/index.js` | 双击启动 → <http://127.0.0.1:{_p(domain, 'port', 4173)}> |

## 演示顺序建议

""" + "\n".join(f"{i}. {s['title']}：{'；'.join(s['steps'][:1])}" for i, s in enumerate(c("demo"), 1)) + """

## 说明

- 当前为**仿真数据源**，未接入真实 PLC / 仪表；接口层已按标准协议预留。
- 所有设备参数、数量与代码主数据保持一致；正式验收以现场会审与设备证书为准。
- 全部材料由 `config/domain.json` + `build_all.py` 一键生成，修改数据后请全量重跑。
"""
    write_text(paths["deliverables"] / "交付清单.md", manifest)

    launcher = f"""@echo off
chcp 65001 >nul
title {name} · {full}
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo [错误] 未检测到 Node.js，请先安装 Node.js 20 或更高版本。
  pause
  exit /b 1
)
echo.
echo   {name} · {full}
echo   正在启动本地服务...
echo.
start "" http://127.0.0.1:{_p(domain, 'port', 4173)}
node server/index.js
pause
"""
    write_text(paths["root"] / "启动系统.bat", launcher)

    # deck content consumed by make_ppt.py
    write_json(paths["config"] / "deck.json", {
        "project": domain.get("project", {}),
        "content": {k: c(k) for k in ["background", "pain", "goals", "principles", "architecture",
                                       "innovations", "values", "limits", "roadmap", "qa", "demo",
                                       "compliance"]},
    })
