"""Generate neutral PPT image assets when browser screenshots are unavailable.

Usage: python _placeholder_assets.py <project-root>
"""
from __future__ import annotations

import sys
from pathlib import Path

from PIL import Image, ImageDraw

from _common import project_paths, read_json

FILES = ["bg.png", "cover-hero.png", "overview-169.png", "face-169.png", "alarms-169.png",
         "topology-169.png", "devices-169.png", "scenario-1610.png"]


def build(root: Path):
    p = project_paths(root)
    domain = read_json(p["domain"])
    name = domain.get("project", {}).get("name", "智安")
    out = p["assets"]
    out.mkdir(parents=True, exist_ok=True)
    for fn in FILES:
        w, h = (1920, 1080) if fn != "cover-hero.png" else (860, 1200)
        im = Image.new("RGB", (w, h), (7, 17, 31))
        d = ImageDraw.Draw(im)
        for x in range(0, w, 120):
            d.line([(x, 0), (x, h)], fill=(16, 38, 58), width=1)
        for y in range(0, h, 120):
            d.line([(0, y), (w, y)], fill=(16, 38, 58), width=1)
        d.rectangle((0, 0, w, 6), fill=(53, 224, 192))
        d.text((60, h // 2 - 20), f"{name}  |  {fn}", fill=(159, 180, 200))
        im.save(out / fn)
    print(f"[OK] placeholder assets: {len(FILES)} files -> {out}")


if __name__ == "__main__":
    build(Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve())
