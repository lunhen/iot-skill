"""Verify every required deliverable exists, is non-empty and opens correctly.

Usage: python check.py <project-root>
"""
from __future__ import annotations

import json
import sys
import zipfile
from pathlib import Path

from _common import project_paths, read_json, write_json

MIN_KB = {"pptx": 30, "docx": 12, "xlsx": 8, "zip": 5, "drawio": 1, "png": 10}


def check(root: Path):
    p = project_paths(root)
    domain = read_json(p["domain"])
    name = domain.get("project", {}).get("name", "智安")
    results = []

    def add(label, path: Path, kind, required=True):
        ok = path.exists() and path.stat().st_size >= MIN_KB.get(kind, 1) * 1024
        detail = f"{path.stat().st_size // 1024} KB" if path.exists() else "MISSING"
        results.append({"item": label, "ok": ok, "required": required, "detail": detail, "path": str(path)})
        return ok

    d = p["deliverables"]
    add("项目演示 PPT", d / "项目演示.pptx", "pptx")
    add("设备选型说明 DOCX", d / "设备选型说明.docx", "docx")
    add("设备选型说明 XLSX", d / "设备选型说明.xlsx", "xlsx")
    add("AI 提示词全过程记录", d / "AI提示词全过程记录.docx", "docx")
    add("演示脚本与答辩要点", d / "演示脚本与答辩要点.docx", "docx")
    add("项目完整源码", d / "项目完整源码.zip", "zip")
    add("参赛交付包", d / f"{name}-参赛交付包.zip", "zip")
    add("应用拓扑工程文件", p["topology"] / "application-topology.drawio", "drawio")
    add("拓扑机器可读版本", p["topology"] / "application-topology.json", "drawio")
    add("README", root / "README.md", "drawio")
    add("交付清单", d / "交付清单.md", "drawio")

    shots = sorted(p["shots"].glob("*.png")) if p["shots"].exists() else []
    for s in shots:
        add("截图 " + s.name, s, "png", required=False)
    results.append({"item": "截图数量 >= 7", "ok": len(shots) >= 7,
                    "required": False, "detail": f"{len(shots)} 张", "path": str(p["shots"])})

    # Deep validation: files really open, not just exist.
    py_checks = []
    try:
        from pptx import Presentation
        n_slides = len(Presentation(str(d / "项目演示.pptx")).slides)
        py_checks.append((f"pptx 可解析 / {n_slides} 页", n_slides >= 14))
    except Exception:
        py_checks.append(("pptx 可解析", False))
    try:
        from docx import Document
        for f in ("设备选型说明.docx", "AI提示词全过程记录.docx", "演示脚本与答辩要点.docx"):
            Document(str(d / f))
        py_checks.append(("3 份 docx 可解析", True))
    except Exception:
        py_checks.append(("3 份 docx 可解析", False))
    try:
        from openpyxl import load_workbook
        load_workbook(str(d / "设备选型说明.xlsx"), read_only=True)
        py_checks.append(("xlsx 可解析", True))
    except Exception:
        py_checks.append(("xlsx 可解析", False))
    try:
        with zipfile.ZipFile(d / "项目完整源码.zip") as z:
            py_checks.append(("源码包内含 server/index.js", "server/index.js" in z.namelist()))
    except Exception:
        py_checks.append(("源码包可解压", False))
    for label, ok in py_checks:
        results.append({"item": label, "ok": bool(ok), "required": True, "detail": "ok" if ok else "FAILED", "path": ""})

    # Consistency: project name must appear in README and docs.
    readme = (root / "README.md").read_text(encoding="utf-8") if (root / "README.md").exists() else ""
    results.append({"item": "README 项目名一致", "ok": name in readme, "required": False,
                    "detail": name, "path": "README.md"})

    failed = [r for r in results if r["required"] and not r["ok"]]
    warn = [r for r in results if not r["required"] and not r["ok"]]
    for r in results:
        mark = "OK  " if r["ok"] else ("FAIL" if r["required"] else "WARN")
        print(f"  {mark}  {r['item']:<34} {r['detail']}")
    print(f"CHECK {'PASS' if not failed else 'FAILED'}  ({len(results) - len(failed) - len(warn)} ok / {len(warn)} warn / {len(failed)} fail)")
    write_json(p["config"] / "check-report.json", {"ok": not failed, "results": results})
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(check(Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()))
