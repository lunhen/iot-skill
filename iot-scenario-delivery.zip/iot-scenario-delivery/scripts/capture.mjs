/**
 * CDP screenshot capture (the proven path for this stack).
 *
 * DO NOT use `msedge --headless --screenshot --virtual-time-budget`: the app keeps
 * an SSE connection open, virtual time never settles and the process hangs.
 * Launch Edge separately with --remote-debugging-port and drive it over CDP.
 *
 * Env: CDP_PORT (9222), SHOT_DIR, BASE_URL (optional override)
 * Reads config/domain.json for port / first area / first scenario.
 * Prints a JSON report as its last line.
 */
import fs from 'node:fs';
import path from 'node:path';

const CDP = process.env.CDP_PORT || '9222';
const OUT = path.resolve(process.env.SHOT_DIR || 'deliverables/screenshots');
const domain = JSON.parse(fs.readFileSync('config/domain.json', 'utf8'));
const port = domain.project?.port || 4173;
const firstFace = domain.sites?.[0]?.faces?.[0]?.id;
const firstScenario = Object.keys(domain.scenarios || {}).find((k) => k !== 'normal');
const BASE = process.env.BASE_URL || `http://127.0.0.1:${port}/?v=${Date.now()}`;
const API = `http://127.0.0.1:${port}`;

fs.mkdirSync(OUT, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const report = { shots: [], errors: [], overflow: [], ok: false };

async function openPage() {
  const res = await fetch(`http://127.0.0.1:${CDP}/json/new?${encodeURIComponent('about:blank')}`, { method: 'PUT' });
  const target = await res.json();
  const ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve, { once: true });
    ws.addEventListener('error', reject, { once: true });
  });
  let id = 0;
  const pending = new Map();
  ws.addEventListener('message', (ev) => {
    const msg = JSON.parse(ev.data);
    if (msg.id && pending.has(msg.id)) {
      const { resolve, reject } = pending.get(msg.id);
      pending.delete(msg.id);
      msg.error ? reject(new Error(msg.error.message)) : resolve(msg.result);
    }
    if (msg.method === 'Runtime.exceptionThrown') {
      report.errors.push('EXCEPTION ' + (msg.params.exceptionDetails?.exception?.description || msg.params.exceptionDetails?.text || 'unknown'));
    }
    if (msg.method === 'Log.entryAdded' && msg.params.entry.level === 'error') {
      report.errors.push('CONSOLE ' + msg.params.entry.text);
    }
  });
  const send = (method, params = {}) => new Promise((resolve, reject) => {
    const mid = ++id;
    pending.set(mid, { resolve, reject });
    ws.send(JSON.stringify({ id: mid, method, params }));
  });
  await send('Page.enable');
  await send('Runtime.enable');
  await send('Log.enable');
  await send('Network.enable');
  await send('Network.setCacheDisabled', { cacheDisabled: true });
  await send('Emulation.setDeviceMetricsOverride', { width: 1600, height: 1100, deviceScaleFactor: 1, mobile: false });
  return { ws, send, targetId: target.id };
}

async function goto(page, hash, wait = 2400) {
  await page.send('Page.navigate', { url: `${BASE}${hash}` });
  await sleep(wait);
}

async function evalJs(page, expression) {
  const r = await page.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  if (r.exceptionDetails) throw new Error(r.exceptionDetails.text);
  return r.result?.value;
}

async function shot(page, name) {
  const r = await page.send('Page.captureScreenshot', { format: 'png', fromSurface: true, captureBeyondViewport: false });
  const file = path.join(OUT, name);
  fs.writeFileSync(file, Buffer.from(r.data, 'base64'));
  const kb = Math.round(fs.statSync(file).size / 1024);
  report.shots.push({ name, kb });
  console.log(`saved ${name} (${kb} KB)`);
}

const page = await openPage();
try {
  await goto(page, '#/overview', 4200);
  report.title = await evalJs(page, 'document.title');
  report.h1 = await evalJs(page, "document.querySelector('.page-title')?.innerText");
  await shot(page, '01-overview.png');

  if (firstFace) {
    await goto(page, `#/face/${firstFace}`, 2600);
    await shot(page, '02-face.png');
  }
  await goto(page, '#/alarms', 2200);
  report.alarmRows = await evalJs(page, "document.querySelectorAll('#alarm-table-body tr').length");
  await shot(page, '03-alarms.png');
  await evalJs(page, "document.querySelector('#alarm-table-body tr[data-alarm-open]')?.click()");
  await sleep(800);
  await shot(page, '04-alarm-detail.png');
  await evalJs(page, "document.querySelector('[data-close-drawer]')?.click()");
  await sleep(400);

  await goto(page, '#/history', 3000);
  await shot(page, '05-history.png');
  await goto(page, '#/topology', 2200);
  await shot(page, '06-topology.png');
  await goto(page, '#/devices', 2200);
  await shot(page, '07-devices.png');

  await goto(page, '#/overview', 1800);
  await evalJs(page, "document.querySelector('#drill-btn')?.click()");
  await sleep(700);
  await shot(page, '08-drill-modal.png');
  await evalJs(page, "document.querySelector('[data-close-modal]')?.click()");
  await sleep(400);

  if (firstFace && firstScenario) {
    await goto(page, `#/face/${firstFace}`, 1800);
    await fetch(`${API}/api/scenario`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: firstScenario, faceId: firstFace })
    });
    await sleep(11000);
    await shot(page, '09-scenario-live.png');
    await fetch(`${API}/api/scenario`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: 'normal' })
    });
    await sleep(800);
  }

  report.overflow = await evalJs(page, `(() => [...document.querySelectorAll('.page *')]
    .filter(el => el.scrollWidth > el.clientWidth + 2 && getComputedStyle(el).overflowX === 'visible'
      && !String(el.className || '').includes('sensor-dot'))
    .slice(0, 10).map(el => String(el.className || el.tagName)))()`) || [];
  report.ok = report.shots.length >= 7;
} catch (e) {
  report.errors.push('FATAL ' + (e?.stack || String(e)));
  console.error('CAPTURE FAILED', e);
  process.exitCode = 1;
} finally {
  try {
    await fetch(`http://127.0.0.1:${CDP}/json/close/${page.targetId}`);
  } catch { /* best effort */ }
  page.ws.close();
  console.log('CAPTURE_REPORT ' + JSON.stringify(report));
}
