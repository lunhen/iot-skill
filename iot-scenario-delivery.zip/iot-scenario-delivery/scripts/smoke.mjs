/** API smoke test. Run with cwd = project root, server already up. */
import fs from 'node:fs';

const domain = JSON.parse(fs.readFileSync('config/domain.json', 'utf8'));
const port = domain.project?.port || 4173;
const BASE = `http://127.0.0.1:${port}`;
const checks = [];

async function check(name, url, validate, options, expectedStatus) {
  try {
    const res = await fetch(BASE + url, options);
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch { /* html or csv */ }
    const statusOk = expectedStatus ? res.status === expectedStatus : res.ok;
    const ok = statusOk && (!validate || validate(data, text, res));
    checks.push({ name, ok, status: res.status, detail: ok ? 'ok' : text.slice(0, 120) });
  } catch (e) {
    checks.push({ name, ok: false, detail: String(e) });
  }
}

await check('health', '/api/health', (d) => !!d);
await check('bootstrap', '/api/bootstrap', (d) => !!d && Array.isArray(d.mines));
await check('state', '/api/state', (d) => !!d && Array.isArray(d.mines) && d.mines.length > 0);
await check('history', '/api/history', (d) => !!d);
await check('alarms', '/api/alarms', (d) => !!d);
await check('devices', '/api/devices', (d) => !!d);
await check('csv export', '/api/export/alarms.csv', (d, t) => t.includes(','));
await check('bad scenario -> 400', '/api/scenario', () => true, {
  method: 'POST', headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ type: '__not_a_scenario__' })
}, 400);
await check('index html', '/', (d, t) => t.includes('<html') || t.includes('<!DOCTYPE'));

const failed = checks.filter((c) => !c.ok);
for (const c of checks) console.log(`${c.ok ? 'PASS' : 'FAIL'}  ${c.name}  ${c.ok ? '' : c.detail}`);
console.log(`SMOKE ${failed.length === 0 ? 'OK' : 'FAILED'} (${checks.length - failed.length}/${checks.length})`);
if (failed.length) process.exitCode = 1;
