"""Convert the three Markdown documents to polished DOCX via the bundled converter.

Usage: python make_docx.py <project-root>
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

from _common import find_python, project_paths, read_json

DOCS = [
    ("设备选型说明.md", "设备选型说明.docx", "设备选型说明文档", "DEV-001"),
    ("AI提示词全过程记录.md", "AI提示词全过程记录.docx", "AI 提示词全过程记录", "AI-001"),
    ("演示脚本与答辩要点.md", "演示脚本与答辩要点.docx", "演示脚本与答辩要点", "DEMO-001"),
]


def build(root: Path):
    p = project_paths(root)
    domain = read_json(p["domain"])
    code = (domain.get("project", {}).get("key", "IOT") or "IOT").upper()[:10]
    converter = p["scripts"] / "md_to_docx.py"
    py = find_python()
    for src, dst, subtitle, suffix in DOCS:
        infile, outfile = p["docs"] / src, p["deliverables"] / dst
        if not infile.exists():
            print(f"[SKIP] missing {src}")
            continue
        r = subprocess.run(
            [py, str(converter), str(infile), str(outfile),
             "--subtitle", subtitle, "--doc-code", f"{code}-{suffix}"],
            cwd=root, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120,
        )
        if r.returncode != 0:
            raise RuntimeError(f"docx conversion failed for {src}: {r.stderr[-600:]}")
        print(f"[OK] docx -> {dst} ({outfile.stat().st_size // 1024} KB)")


if __name__ == "__main__":
    build(Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve())
