/**
 * 数据字典与业务主数据 —— 配置驱动版
 *
 * 所有业务主数据来自 config/domain.json。该文件由 skill 的 new_project.py 生成，
 * 修改主题时只需改 JSON，不需要改本文件，也不需要改 simulator/alarm/index。
 *
 * 稳定契约（后端告警与仿真逻辑依赖，key 与 direction 不可改）：
 *   ch4 / ch4b / co / o2 / temp / humidity / dust / wind
 *   其中 o2 = low（越低越危险），wind = range（上下限），其余 = up。
 * 可自由修改：name / short / unit / decimals / model / method / range /
 *             precision / 各级阈值 / normal 基线 / position / description。
 */
import { readFileSync } from 'node:fs';

const DOMAIN = JSON.parse(
  readFileSync(new URL('../config/domain.json', import.meta.url), 'utf8')
);

export const PROJECT = DOMAIN.project || {};
export const MINE_META = DOMAIN.sites || [];
export const SENSOR_TYPES = DOMAIN.sensorTypes || {};
export const SCENARIOS = DOMAIN.scenarios || {};
export const DEVICE_CATALOG = DOMAIN.devices || [];
export const LINK_NODES = DOMAIN.linkNodes || [];
export const API_PORTS = { http: Number(PROJECT.port) || 4173 };

/**
 * 仿真参数：换主题时若修改了阈值 / 量程，必须同步修改 scenarioTargets 与 clamps，
 * 否则演练注入的目标值可能永远越不过阈值。
 */
const DEFAULT_SIMULATION = {
  scenarioTargets: {
    gas: { ch4: 1.72, ch4b: 1.48, temp: 28.4, co: 18 },
    co: { co: 62, temp: 29.2, o2: 20.1 },
    vent: { wind: 0.12, ch4: 1.34, ch4b: 1.58, temp: 32.4, o2: 18.7 },
    dust: { dust: 26, humidity: 82 }
  },
  clamps: {
    ch4: [0.15, 3.2], ch4b: [0.15, 3.2], wind: [0.05, 7.2], o2: [15.5, 21.3],
    co: [0, 120], temp: [18, 42], humidity: [35, 99], dust: [0.5, 80]
  },
  historyClamps: {
    low: [18.6, 21.2], ch4: [0.18, 1.18], ch4b: [0.18, 1.18],
    wind: [0.5, 3.8], o2: [18.8, 21.2]
  }
};
const SIM = DOMAIN.simulation || {};
export const SIMULATION = {
  scenarioTargets: SIM.scenarioTargets || DEFAULT_SIMULATION.scenarioTargets,
  clamps: { ...DEFAULT_SIMULATION.clamps, ...(SIM.clamps || {}) },
  historyClamps: { ...DEFAULT_SIMULATION.historyClamps, ...(SIM.historyClamps || {}) }
};

const SENSOR_LAYOUT = DOMAIN.sensorLayout && DOMAIN.sensorLayout.length
  ? DOMAIN.sensorLayout
  : Object.values(SENSOR_TYPES).map((def, i) => ({
      type: def.key,
      suffix: `${def.key.toUpperCase()}-01`,
      label: def.name,
      role: `测点 ${i + 1}`
    }));

function buildSensors(face) {
  return SENSOR_LAYOUT.map((item, index) => {
    const def = SENSOR_TYPES[item.type];
    if (!def) throw new Error(`config/domain.json: 找不到测点类型 ${item.type}`);
    return {
      id: `${face.id}-${item.suffix}`,
      faceId: face.id,
      type: item.type,
      name: item.label,
      role: item.role,
      unit: def.unit,
      decimals: def.decimals,
      model: def.model,
      position: def.position,
      order: index + 1
    };
  });
}

export const FACES = MINE_META.flatMap((mine) =>
  mine.faces.map((face) => ({
    ...face,
    mineId: mine.id,
    mineName: mine.name,
    mineColor: mine.color,
    sensors: buildSensors(face)
  }))
);

export const SENSOR_INDEX = new Map();
for (const face of FACES) {
  for (const sensor of face.sensors) {
    SENSOR_INDEX.set(sensor.id, {
      ...sensor,
      face,
      mine: MINE_META.find((m) => m.id === face.mineId)
    });
  }
}

export function getSensorType(type) {
  return SENSOR_TYPES[type];
}

export function thresholdOf(type) {
  const def = SENSOR_TYPES[type];
  if (def.direction === 'low') {
    return { warning: def.warning, alarm: def.alarm, critical: def.critical, direction: 'low' };
  }
  if (def.direction === 'range') {
    return {
      warningLow: def.warningLow,
      alarmLow: def.alarmLow,
      warningHigh: def.warningHigh,
      criticalHigh: def.criticalHigh,
      direction: 'range'
    };
  }
  return { warning: def.warning, alarm: def.alarm, critical: def.critical, direction: 'up' };
}
