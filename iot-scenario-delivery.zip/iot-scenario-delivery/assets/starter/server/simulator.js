import {
  SENSOR_TYPES,
  SENSOR_INDEX,
  FACES,
  MINE_META,
  DEVICE_CATALOG,
  LINK_NODES,
  SCENARIOS,
  thresholdOf,
  SIMULATION
} from './data.js';
import { AlarmEngine, evaluateValue, LEVEL_LABEL } from './alarm.js';

const TICK_MS = 2000;
const LIVE_HISTORY_EVERY = 15; // 30s
const HISTORY_WINDOW_MS = 24 * 60 * 60 * 1000;

function mulberry32(seed) {
  return function rand() {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function average(nums) {
  return nums.length ? nums.reduce((a, b) => a + b, 0) / nums.length : 0;
}

function rank(level) {
  return { normal: 0, warning: 1, alarm: 2, critical: 3 }[level] || 0;
}

function isoAt(ms) {
  return new Date(ms).toISOString();
}

function buildSeedEvents() {
  const getFace = (id) => FACES.find((f) => f.id === id);
  const getSensor = (faceId, suffix) => getFace(faceId).sensors.find((s) => s.id.endsWith(suffix));
  const defs = [
    ['YL-2205', 'CO-01', 27.4, 'alarm', 11, true, false, '采空区遗煤氧化，CO 缓慢上升'],
    ['HSG-4102', 'CH4-01', 1.52, 'critical', 26, false, false, '掘进迎头瓦斯局部积聚'],
    ['QL-1302', 'DUST-01', 12.6, 'alarm', 122, true, true, '转载点喷雾电磁阀堵塞'],
    ['HSG-4203', 'CO-01', 31.2, 'critical', 245, true, true, '采空区自燃征兆，已注浆处置'],
    ['YL-2203', 'CH4-02', 1.18, 'alarm', 368, true, true, '周期来压瓦斯释放'],
    ['QL-1301', 'WIND-01', 0.19, 'critical', 486, true, true, '局部通风机失电停转'],
    ['HSG-4101', 'TEMP-01', 31.6, 'alarm', 610, true, true, '设备散热聚集，已开启洒水降温'],
    ['QL-2101', 'CH4-01', 0.92, 'warning', 733, true, true, '瓦斯浓度短时波动'],
    ['YL-3101', 'O2-01', 18.6, 'alarm', 910, true, true, '采空区漏风导致氧浓度下降'],
    ['HSG-4102', 'DUST-01', 9.4, 'warning', 1120, true, true, '割煤速度过快，产尘增加'],
    ['QL-1301', 'CO-01', 25.2, 'alarm', 44, true, true, '设备油脂高温，已现场处置'],
    ['YL-2203', 'TEMP-01', 30.4, 'alarm', 65, true, true, '制冷机组短时停机'],
    ['HSG-4101', 'CH4-02', 1.12, 'alarm', 84, true, true, '回风隅角瓦斯积聚'],
    ['QL-1302', 'WIND-01', 0.42, 'warning', 96, true, true, '风筒局部漏风，已修补']
  ];
  return defs.map(([faceId, suffix, value, level, minutesAgo, acknowledged, resolved, cause]) => {
    const face = getFace(faceId);
    const sensor = getSensor(faceId, suffix);
    const time = new Date(Date.now() - minutesAgo * 60_000).toISOString();
    return {
      time,
      mineId: face.mineId,
      mineName: face.mineName,
      faceId: face.id,
      faceName: face.name,
      sensorId: sensor.id,
      sensorName: sensor.name,
      type: sensor.type,
      value,
      level,
      acknowledged,
      resolvedAt: resolved ? new Date(Date.now() - (minutesAgo - 8) * 60_000).toISOString() : null,
      manualHold: !resolved,
      cause
    };
  });
}

export class Simulator {
  constructor() {
    this.rand = mulberry32(20261109);
    this.startedAt = Date.now();
    this.tickCount = 0;
    this.alarmEngine = new AlarmEngine({ seed: buildSeedEvents() });
    this.scenario = null;
    this.current = new Map();
    this.recent = new Map();
    this.history = new Map();
    this.packets = 1_284_306;
    this.linkStartedAt = Date.now();
    this.lastTickAt = Date.now();
    this.lastHistoryAt = Date.now();
    this.logs = [];
    this.seedLogs();
    this.initReadings();
    this.seedHistory();
  }

  seedLogs() {
    const now = Date.now();
    const entries = [
      { ago: 8, text: '三矿井双环链路自检完成，9 台 KJJ127 交换机响应正常', level: 'info' },
      { ago: 32, text: '72 个环境测点完成分钟级数据补传，完整率 99.8%', level: 'info' },
      { ago: 74, text: '青龙煤矿 1302 掘进工作面局扇切换试验完成，风速恢复 1.8 m/s', level: 'info' },
      { ago: 148, text: '云岭煤矿 2205 掘进工作面 CO 测点完成零点标校，偏差 +0.4 ppm', level: 'info' },
      { ago: 236, text: '平台与集团调度中心完成时钟同步，偏差 12 ms', level: 'info' }
    ];
    this.logs = entries.map((e, i) => ({
      id: `SYS-${i + 1}`,
      t: new Date(now - e.ago * 60_000).toISOString(),
      level: e.level,
      text: e.text
    }));
  }

  initReadings() {
    for (const sensor of SENSOR_INDEX.values()) {
      const def = SENSOR_TYPES[sensor.type];
      const center = (def.normal[0] + def.normal[1]) / 2;
      const value = Number((center + (this.rand() - 0.5) * (def.normal[1] - def.normal[0])).toFixed(def.decimals));
      this.current.set(sensor.id, value);
      this.recent.set(sensor.id, [{ t: Date.now(), v: value }]);
    }
  }

  seedHistory() {
    const now = Date.now();
    const start = now - HISTORY_WINDOW_MS;
    const sampleMs = 5 * 60_000;
    for (const sensor of SENSOR_INDEX.values()) {
      const def = SENSOR_TYPES[sensor.type];
      const center = (def.normal[0] + def.normal[1]) / 2;
      const span = def.normal[1] - def.normal[0];
      const points = [];
      for (let t = start; t <= now; t += sampleMs) {
        const hour = new Date(t).getHours();
        const shift = hour >= 8 && hour < 20 ? 0.12 : -0.04;
        const wave = Math.sin((t / 3_600_000) * 1.15 + sensor.order) * 0.22;
        let v = center + span * (wave + shift) + (this.rand() - 0.5) * span * 0.55;
        // 每天保留少量真实波动峰值，保证历史曲线具有业务形态。
        if (this.rand() > 0.985) v += span * (1.2 + this.rand());
        const hRange = def.direction === 'low'
          ? SIMULATION.historyClamps.low
          : SIMULATION.historyClamps[sensor.type];
        if (hRange) v = clamp(v, hRange[0], hRange[1]);
        else v = clamp(v, def.normal[0] * 0.65, def.normal[1] * 1.45);
        points.push({ t, v: Number(v.toFixed(def.decimals)) });
      }
      this.history.set(sensor.id, points);
    }
  }

  scenarioTargets(sensor) {
    if (!this.scenario || this.scenario.faceId !== sensor.faceId) return null;
    const map = SIMULATION.scenarioTargets[this.scenario.type];
    if (!map) return null;
    const value = map[sensor.type];
    return value === undefined ? null : value;
  }

  tick() {
    const now = Date.now();
    this.tickCount += 1;
    if (this.scenario && now >= this.scenario.endsAt) {
      this.stopScenario('演练计时结束，系统自动回归安全工况');
    }

    for (const sensor of SENSOR_INDEX.values()) {
      const def = SENSOR_TYPES[sensor.type];
      const old = this.current.get(sensor.id);
      const base = (def.normal[0] + def.normal[1]) / 2;
      const span = def.normal[1] - def.normal[0];
      const target = this.scenarioTargets(sensor) ?? base;
      const response = this.scenarioTargets(sensor) !== null ? 0.11 : 0.16;
      const noise = (this.rand() - 0.5) * span * 0.16;
      let value = old + (target - old) * response + noise;
      const range = SIMULATION.clamps[sensor.type];
      if (range) value = clamp(value, range[0], range[1]);
      value = Number(value.toFixed(def.decimals));
      this.current.set(sensor.id, value);

      const recent = this.recent.get(sensor.id) || [];
      recent.push({ t: now, v: value });
      if (recent.length > 60) recent.shift();
      this.recent.set(sensor.id, recent);

      const event = this.alarmEngine.update({
        ...sensor,
        mineId: sensor.mine.id,
        mineName: sensor.mine.name,
        faceId: sensor.face.id,
        faceName: sensor.face.name
      }, value);
      if (event) this.pushLog(event);

      if (now - this.lastHistoryAt >= LIVE_HISTORY_EVERY * TICK_MS) {
        const history = this.history.get(sensor.id) || [];
        history.push({ t: now, v: value });
        const cutoff = now - HISTORY_WINDOW_MS;
        while (history.length && history[0].t < cutoff) history.shift();
        this.history.set(sensor.id, history);
      }
    }
    if (now - this.lastHistoryAt >= LIVE_HISTORY_EVERY * TICK_MS) this.lastHistoryAt = now;

    this.packets += 72 * 2 + Math.floor(this.rand() * 8);
    this.lastTickAt = now;
    if (this.scenario) {
      this.scenario.elapsed = Math.min(this.scenario.duration, Math.round((now - this.scenario.startedAt) / 1000));
      this.scenario.remaining = Math.max(0, Math.round((this.scenario.endsAt - now) / 1000));
    }
  }

  pushLog(event) {
    this.logs.unshift({
      id: event.id,
      t: new Date().toISOString(),
      level: event.level,
      text: `${event.faceName} ${event.sensorName} ${Number(event.value).toFixed(2)} ${event.unit} · ${LEVEL_LABEL[event.level]}`
    });
    if (this.logs.length > 50) this.logs.pop();
  }

  startScenario(type, faceId) {
    if (type === 'normal') {
      this.stopScenario('人工结束演练');
      return null;
    }
    const conf = SCENARIOS[type];
    const face = FACES.find((f) => f.id === faceId) || FACES[0];
    const duration = conf.duration;
    this.scenario = {
      type,
      name: conf.name,
      code: conf.code,
      faceId: face.id,
      faceName: face.name,
      mineId: face.mineId,
      mineName: face.mineName,
      duration,
      startedAt: Date.now(),
      endsAt: Date.now() + duration * 1000,
      elapsed: 0,
      remaining: duration
    };
    this.logs.unshift({
      id: `SIM-${Date.now()}`,
      t: new Date().toISOString(),
      level: 'info',
      text: `演练开始：${face.mineName} ${face.name} · ${conf.name}`
    });
    return this.scenario;
  }

  stopScenario(reason = '人工停止演练') {
    if (!this.scenario) return;
    const scenario = this.scenario;
    this.scenario = null;
    this.logs.unshift({
      id: `SIM-END-${Date.now()}`,
      t: new Date().toISOString(),
      level: 'info',
      text: `演练结束：${scenario.faceName} · ${reason}`
    });
  }

  faceEquipment(face, levels) {
    const has = (types, minRank = 2) => face.sensors.some((s) => types.includes(s.type) && rank(levels[s.id]) >= minRank);
    const critical = has(['ch4', 'ch4b', 'wind'], 3);
    const gasAlarm = has(['ch4', 'ch4b'], 2);
    const powerCut = gasAlarm;
    const coAlarm = has(['co'], 2);
    const dustAlarm = has(['dust'], 2);
    return {
      fan: {
        name: '局部通风机',
        status: critical || gasAlarm ? '变频 50 Hz' : '变频 38 Hz',
        state: critical || gasAlarm ? 'boost' : 'normal',
        detail: critical ? '强排模式 · 已切换备用回路' : '按需通风 · 运行平稳'
      },
      power: {
        name: '工作面动力电源',
        status: powerCut ? '已切断' : '正常供电',
        state: powerCut ? 'danger' : 'normal',
        detail: powerCut ? '馈电反馈：分闸成功 · 动力闭锁' : '馈电反馈：合闸'
      },
      spray: {
        name: '洒水降尘',
        status: dustAlarm || coAlarm ? '喷洒中' : '待机',
        state: dustAlarm || coAlarm ? 'active' : 'normal',
        detail: dustAlarm ? '转载点 2 路电磁阀开启' : coAlarm ? '回风巷喷雾抑尘' : '粉尘浓度未超限'
      },
      siren: {
        name: '声光报警器',
        status: critical || gasAlarm || coAlarm || dustAlarm ? '鸣响' : '静默',
        state: critical || gasAlarm || coAlarm || dustAlarm ? 'danger' : 'normal',
        detail: critical || gasAlarm || coAlarm || dustAlarm ? '工作面入口 + 回风巷双端告警' : '设备在线自检正常'
      },
      camera: {
        name: 'AI 摄像仪',
        status: '在线',
        state: 'normal',
        detail: '视频复核可用 · 录像留存 30 天'
      }
    };
  }

  getState() {
    const alarmStats = this.alarmEngine.stats();
    const activeEvents = this.alarmEngine.active();
    const levels = {};
    const mines = MINE_META.map((mine) => {
      const faces = FACES.filter((f) => f.mineId === mine.id).map((face) => {
        const sensors = face.sensors.map((sensor) => {
          const def = SENSOR_TYPES[sensor.type];
          const value = this.current.get(sensor.id) ?? 0;
          const level = evaluateValue(sensor.type, value);
          levels[sensor.id] = level;
          const recent = this.recent.get(sensor.id) || [];
          const prev = recent.length > 5 ? recent[recent.length - 5].v : value;
          return {
            ...sensor,
            value,
            display: Number(value).toFixed(def.decimals),
            level,
            levelLabel: LEVEL_LABEL[level],
            trend: value > prev + (def.normal[1] - def.normal[0]) * 0.04 ? 'up' : value < prev - (def.normal[1] - def.normal[0]) * 0.04 ? 'down' : 'flat',
            threshold: thresholdOf(sensor.type),
            thresholdText: this.thresholdText(sensor.type),
            history: recent.slice(-32).map((p) => p.v)
          };
        });
        const faceAlarms = activeEvents.filter((e) => e.faceId === face.id);
        const faceLevels = [...sensors.map((s) => s.level), ...faceAlarms.map((e) => e.level)];
        const maxLevel = faceLevels.includes('critical') ? 'critical' : faceLevels.includes('alarm') ? 'alarm' : faceLevels.includes('warning') ? 'warning' : 'normal';
        const gas = average(sensors.filter((s) => s.type.startsWith('ch4')).map((s) => s.value));
        return {
          ...face,
          sensors,
          equipment: this.faceEquipment(face, levels),
          level: maxLevel,
          levelLabel: LEVEL_LABEL[maxLevel],
          gas: Number(gas.toFixed(2)),
          online: sensors.length,
          total: sensors.length,
          risk: this.riskScore(maxLevel, gas, mine.riskBase),
          activeAlarms: faceAlarms.length
        };
      });
      const mineAlarms = activeEvents.filter((e) => e.mineId === mine.id);
      const mineLevels = [...faces.map((f) => f.level), ...mineAlarms.map((e) => e.level)];
      const maxLevel = mineLevels.includes('critical') ? 'critical' : mineLevels.includes('alarm') ? 'alarm' : mineLevels.includes('warning') ? 'warning' : 'normal';
      const allSensors = faces.flatMap((f) => f.sensors);
      const gas = average(allSensors.filter((s) => s.type.startsWith('ch4')).map((s) => s.value));
      return {
        ...mine,
        faces,
        level: maxLevel,
        levelLabel: LEVEL_LABEL[maxLevel],
        activeAlarms: mineAlarms.length,
        online: allSensors.length,
        total: allSensors.length,
        avgGas: Number(gas.toFixed(2)),
        avgTemp: Number(average(allSensors.filter((s) => s.type === 'temp').map((s) => s.value)).toFixed(1)),
        avgWind: Number(average(allSensors.filter((s) => s.type === 'wind').map((s) => s.value)).toFixed(2)),
        risk: this.riskScore(maxLevel, gas, mine.riskBase),
        riskBase: mine.riskBase,
      };
    });

    const active = activeEvents;
    const allSensors = [...SENSOR_INDEX.values()];
    const ch4Values = allSensors.filter((s) => s.type === 'ch4').map((s) => this.current.get(s.id) || 0);
    const online = allSensors.filter((s) => this.current.has(s.id)).length;
    const total = allSensors.length;
    return {
      ts: new Date().toISOString(),
      tick: this.tickCount,
      mode: 'live',
      scenario: this.scenario,
      system: {
        mines: mines.length,
        faces: FACES.length,
        totalPoints: total,
        onlinePoints: online,
        onlineRate: Number(((online / total) * 100).toFixed(1)),
        activeAlarms: active.length,
        criticalAlarms: active.filter((e) => e.level === 'critical').length,
        avgGas: Number(average(ch4Values).toFixed(2)),
        maxGas: Number(Math.max(...ch4Values).toFixed(2)),
        closureRate: alarmStats.closureRate,
        todayAlarms: alarmStats.today,
        resolvedToday: alarmStats.resolvedToday,
        riskIndex: Number(average(mines.map((m) => m.risk)).toFixed(1)),
        sensorHealth: 99.8,
        production: 28640,
        crew: 279,
        power: 8862,
        uptime: 99.97
      },
      mines,
      alarms: active.slice(0, 8).map((e) => ({ ...e, clock: this.clock(e.time) })),
      link: {
        rtt: 18 + Math.floor(this.rand() * 9),
        loss: Number((0.012 + this.rand() * 0.025).toFixed(3)),
        packets: this.packets,
        throughput: Number((1.72 + this.rand() * 0.28).toFixed(2)),
        nodes: LINK_NODES,
        onlineStations: 9,
        totalStations: 9,
        ringHealthy: true,
        lastSync: new Date().toISOString()
      },
      logs: this.logs.slice(0, 12),
      updatedAt: new Date().toISOString()
    };
  }

  thresholdText(type) {
    const def = SENSOR_TYPES[type];
    if (def.direction === 'low') return `预警 ≤ ${def.warning}${def.unit} · 告警 ≤ ${def.alarm}${def.unit}`;
    if (def.direction === 'range') return `正常 ${def.warningLow}~${def.warningHigh}${def.unit}`;
    return `预警 ≥ ${def.warning}${def.unit} · 告警 ≥ ${def.alarm}${def.unit}`;
  }

  riskScore(level, gas, base = 8) {
    const extra = level === 'critical' ? 30 : level === 'alarm' ? 18 : level === 'warning' ? 7 : 0;
    return Math.min(97, Math.round(base + gas * 10 + extra));
  }

  clock(iso) {
    const d = new Date(iso);
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`;
  }

  getHistory({ faceId, sensorId, from, to, maxPoints = 320 }) {
    const list = sensorId
      ? [SENSOR_INDEX.get(sensorId)].filter(Boolean)
      : FACES.find((f) => f.id === faceId)?.sensors.map((s) => SENSOR_INDEX.get(s.id)) || [];
    const fromMs = from ? new Date(from).getTime() : Date.now() - 24 * 60 * 60_000;
    const toMs = to ? new Date(to).getTime() : Date.now();
    return list.map((sensor) => {
      const def = SENSOR_TYPES[sensor.type];
      const all = (this.history.get(sensor.id) || []).filter((p) => p.t >= fromMs && p.t <= toMs);
      const step = Math.max(1, Math.ceil(all.length / maxPoints));
      const points = [];
      for (let i = 0; i < all.length; i += step) points.push(all[i]);
      if (all.length && points[points.length - 1] !== all[all.length - 1]) points.push(all[all.length - 1]);
      const values = all.map((p) => p.v);
      return {
        sensorId: sensor.id,
        faceId: sensor.face.id,
        name: sensor.name,
        type: sensor.type,
        unit: def.unit,
        decimals: def.decimals,
        points,
        stats: {
          min: values.length ? Math.min(...values) : 0,
          max: values.length ? Math.max(...values) : 0,
          avg: values.length ? Number(average(values).toFixed(def.decimals)) : 0,
          count: values.length,
          exceed: values.filter((v) => evaluateValue(sensor.type, v) !== 'normal').length
        }
      };
    });
  }

  getAlarms({ status = 'all', level = 'all', mineId = 'all', limit = 100 } = {}) {
    return this.alarmEngine.events
      .filter((e) => (status === 'all' ? true : status === 'open' ? e.status !== 'resolved' : e.status === 'resolved'))
      .filter((e) => (level === 'all' ? true : e.level === level))
      .filter((e) => (mineId === 'all' ? true : e.mineId === mineId))
      .slice(0, limit)
      .map((e) => ({ ...e, clock: this.clock(e.time), updatedClock: this.clock(e.updatedAt) }));
  }

  getAlarm(id) {
    const event = this.alarmEngine.events.find((e) => e.id === id);
    return event ? { ...event, clock: this.clock(event.time), updatedClock: this.clock(event.updatedAt) } : null;
  }

  ackAlarm(id, operator) {
    return this.alarmEngine.ack(id, operator);
  }

  resolveAlarm(id, operator) {
    return this.alarmEngine.resolve(id, operator);
  }

  deviceSummary() {
    return DEVICE_CATALOG.map((group) => ({
      ...group,
      items: group.items.map((item) => {
        const qty = item.key === 'ch4' || item.key === 'temp' ? 18 : item.qty;
        return { ...item, qty, status: item.key === 'camera' ? '18/18 在线' : '运行正常' };
      })
    }));
  }
}

export { TICK_MS };
