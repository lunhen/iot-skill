import assert from 'node:assert/strict';
import { AlarmEngine, evaluateValue } from './alarm.js';
import { Simulator } from './simulator.js';

const sensor = {
  id: 'QL-1301-CH4-01',
  type: 'ch4',
  name: '甲烷 T1',
  mineId: 'QL',
  mineName: '青龙煤矿',
  faceId: 'QL-1301',
  faceName: '1301 综采工作面'
};

// 阈值分级
assert.equal(evaluateValue('ch4', 0.5), 'normal');
assert.equal(evaluateValue('ch4', 0.85), 'warning');
assert.equal(evaluateValue('ch4', 1.1), 'alarm');
assert.equal(evaluateValue('ch4', 1.6), 'critical');
assert.equal(evaluateValue('o2', 17.9), 'alarm');
assert.equal(evaluateValue('wind', 0.2), 'critical');

// 告警生成、升级与自动闭环
const engine = new AlarmEngine();
const first = engine.update(sensor, 1.1);
assert.equal(first.level, 'alarm');
assert.equal(engine.active().length, 1);

const escalated = engine.update(sensor, 1.6);
assert.equal(escalated.id, first.id);
assert.equal(escalated.level, 'critical');

engine.update(sensor, 0.5);
engine.update(sensor, 0.5);
const resolved = engine.update(sensor, 0.5);
assert.equal(resolved.status, 'resolved');
assert.equal(engine.active().length, 0);

// 演练场景能够在有限采样周期内触发告警
const simulator = new Simulator();
simulator.startScenario('gas', 'QL-1301');
for (let i = 0; i < 30; i += 1) simulator.tick();
const state = simulator.getState();
assert.equal(state.scenario.type, 'gas');
assert.ok(state.system.activeAlarms >= 1);
assert.ok(state.alarms.some((a) => a.faceId === 'QL-1301'));

// 历史查询具备数据点与统计
const history = simulator.getHistory({ faceId: 'QL-1301', sensorId: 'QL-1301-CH4-01' });
assert.equal(history.length, 1);
assert.ok(history[0].points.length > 100);
assert.ok(history[0].stats.count > 0);

simulator.startScenario('normal', 'QL-1301');
assert.equal(simulator.getState().scenario, null);

console.log('✓ 告警引擎、演练场景、历史查询测试通过');
