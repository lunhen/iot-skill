import { SENSOR_TYPES, thresholdOf } from './data.js';

const LEVEL_RANK = { normal: 0, warning: 1, alarm: 2, critical: 3 };
export const LEVEL_LABEL = { normal: '正常', warning: '预警', alarm: '告警', critical: '严重告警' };

export function evaluateValue(type, value) {
  const def = SENSOR_TYPES[type];
  if (!def) return 'normal';
  if (def.direction === 'low') {
    if (value <= def.critical) return 'critical';
    if (value <= def.alarm) return 'alarm';
    if (value <= def.warning) return 'warning';
    return 'normal';
  }
  if (def.direction === 'range') {
    if (value <= def.alarmLow || value >= def.criticalHigh) return 'critical';
    if (value < def.warningLow || value >= def.warningHigh) return 'alarm';
    return 'normal';
  }
  if (value >= def.critical) return 'critical';
  if (value >= def.alarm) return 'alarm';
  if (value >= def.warning) return 'warning';
  return 'normal';
}

export function thresholdLabel(type) {
  const def = SENSOR_TYPES[type];
  const t = thresholdOf(type);
  if (def.direction === 'low') return `≤${t.warning} ${def.unit} 预警 / ≤${t.alarm} ${def.unit} 告警`;
  if (def.direction === 'range') return `${t.warningLow}~${t.warningHigh} ${def.unit} 正常`;
  return `≥${t.warning} ${def.unit} 预警 / ≥${t.alarm} ${def.unit} 告警`;
}

export function actionPlan(type) {
  const common = [{ label: '触发工作面声光报警', kind: 'siren' }];
  switch (type) {
    case 'ch4':
    case 'ch4b':
      return [
        ...common,
        { label: '局部通风机提频至 50 Hz', kind: 'fan' },
        { label: '切断工作面动力电源', kind: 'power' },
        { label: '推送集团调度与矿值班室', kind: 'notify' }
      ];
    case 'co':
      return [
        ...common,
        { label: '开启回风巷洒水降尘', kind: 'valve' },
        { label: '通知防灭火队现场复核', kind: 'notify' },
        { label: '联动摄像仪抓拍留存', kind: 'camera' }
      ];
    case 'wind':
      return [
        ...common,
        { label: '切换备用局部通风机', kind: 'fan' },
        { label: '停止掘进作业并撤离人员', kind: 'power' },
        { label: '推送通风科应急工单', kind: 'notify' }
      ];
    case 'o2':
      return [
        ...common,
        { label: '开启压风自救装置', kind: 'valve' },
        { label: '撤离作业人员至新鲜风流', kind: 'power' },
        { label: '通知救护队待命', kind: 'notify' }
      ];
    case 'dust':
      return [
        ...common,
        { label: '开启转载点喷雾电磁阀', kind: 'valve' },
        { label: '降低采煤机割煤速度', kind: 'power' },
        { label: '推送职业健康工单', kind: 'notify' }
      ];
    default:
      return [
        ...common,
        { label: '开启洒水降温', kind: 'valve' },
        { label: '通知通风科现场巡检', kind: 'notify' }
      ];
  }
}

function nowIso() {
  return new Date().toISOString();
}

function fmtTime(iso) {
  const d = new Date(iso);
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`;
}

export class AlarmEngine {
  constructor({ seed = [] } = {}) {
    this.events = [];
    this.activeBySensor = new Map();
    this.normalStreak = new Map();
    this.seq = 1;
    for (const item of seed) this.seed(item);
  }

  seed(input) {
    const time = input.time || new Date(Date.now() - 8 * 60_000).toISOString();
    const def = SENSOR_TYPES[input.type];
    const event = {
      id: `ALM-${String(this.seq++).padStart(4, '0')}`,
      time,
      updatedAt: time,
      mineId: input.mineId,
      mineName: input.mineName,
      faceId: input.faceId,
      faceName: input.faceName,
      sensorId: input.sensorId,
      sensorName: input.sensorName || def.name,
      type: input.type,
      value: input.value,
      unit: def.unit,
      level: input.level,
      status: input.resolvedAt ? 'resolved' : input.acknowledged ? 'acknowledged' : 'active',
      acknowledged: Boolean(input.acknowledged),
      resolvedAt: input.resolvedAt || null,
      manualHold: Boolean(input.manualHold),
      message: input.message || this.buildMessage(input, def),
      cause: input.cause || this.inferCause(input.type),
      actions: (input.actions || actionPlan(input.type)).map((a, i) => ({
        ...a,
        status: input.resolvedAt || i < 2 ? 'done' : 'running',
        time: new Date(new Date(time).getTime() + i * 1300).toISOString()
      })),
      timeline: input.timeline || [
        { time, text: `采集到 ${def.name} ${this.fmt(input.value, def)} ${def.unit}，超过${LEVEL_LABEL[input.level]}阈值` },
        { time: new Date(new Date(time).getTime() + 1000).toISOString(), text: '告警引擎完成规则匹配，生成联动工单' },
        ...(input.acknowledged ? [{ time: new Date(new Date(time).getTime() + 90_000).toISOString(), text: '值班调度员已确认，现场复核中' }] : []),
        ...(input.resolvedAt ? [{ time: input.resolvedAt, text: '监测值恢复安全区间，告警自动闭环' }] : [])
      ]
    };
    this.events.unshift(event);
    if (!event.resolvedAt && !event.manualHold) this.activeBySensor.set(event.sensorId, event);
    return event;
  }

  buildMessage(input, def) {
    if (def.direction === 'low') return `${input.sensorName || def.name}浓度低于${LEVEL_LABEL[input.level]}阈值`;
    if (def.direction === 'range') return `${input.sensorName || def.name}风速偏离安全区间`;
    return `${input.sensorName || def.name}超过${LEVEL_LABEL[input.level]}阈值`;
  }

  inferCause(type) {
    return {
      ch4: '采空区周期来压，瓦斯异常涌出',
      ch4b: '回风隅角瓦斯积聚',
      co: '遗煤氧化升温，存在自燃征兆',
      o2: '采空区漏风或局部通风异常',
      wind: '局部通风机失电 / 风筒破损',
      dust: '转载点喷雾失效，产尘量增大',
      temp: '地温异常或设备散热聚集',
      humidity: '巷道淋水或喷雾持续开启'
    }[type] || '环境参数异常';
  }

  fmt(value, def) {
    return Number(value).toFixed(def.decimals ?? 1);
  }

  update(sensor, value) {
    const def = SENSOR_TYPES[sensor.type];
    if (!def) return null;
    const level = evaluateValue(sensor.type, value);
    let event = this.activeBySensor.get(sensor.id);
    const key = sensor.id;

    if (level === 'normal') {
      const streak = (this.normalStreak.get(key) || 0) + 1;
      this.normalStreak.set(key, streak);
      if (event && streak >= 3) {
        event.status = 'resolved';
        event.resolvedAt = nowIso();
        event.updatedAt = event.resolvedAt;
        event.timeline.push({ time: event.resolvedAt, text: '连续 3 个采样周期恢复正常，联动复位，事件自动闭环' });
        for (const action of event.actions) {
          if (action.status !== 'done') {
            action.status = 'done';
            action.time = event.resolvedAt;
          }
        }
        this.activeBySensor.delete(key);
        return event;
      }
      return null;
    }

    this.normalStreak.set(key, 0);
    if (event) {
      const escalated = LEVEL_RANK[level] > LEVEL_RANK[event.level];
      event.level = escalated ? level : event.level;
      event.value = value;
      event.updatedAt = nowIso();
      if (escalated) {
        event.timeline.push({ time: event.updatedAt, text: `告警等级升级为${LEVEL_LABEL[level]}，联动策略同步升级` });
      }
      if (event.actions.every((a) => a.status === 'done')) {
        event.actions.forEach((a) => { a.status = 'running'; });
      }
      return event;
    }

    const created = this.seed({
      time: nowIso(),
      mineId: sensor.mineId,
      mineName: sensor.mineName,
      faceId: sensor.faceId,
      faceName: sensor.faceName,
      sensorId: sensor.id,
      sensorName: sensor.name,
      type: sensor.type,
      value,
      level
    });
    created.timeline = [
      { time: created.time, text: `${sensor.name} 采集值 ${this.fmt(value, def)} ${def.unit}，触发${LEVEL_LABEL[level]}` },
      { time: new Date(Date.now() + 900).toISOString(), text: '告警规则 R-ENV-01 命中，生成联动处置工单' },
      { time: new Date(Date.now() + 1600).toISOString(), text: `${actionPlan(sensor.type)[0]?.label || '现场声光报警'}已下发` }
    ];
    this.activeBySensor.set(sensor.id, created);
    return created;
  }

  ack(id, operator = '集团调度中心') {
    const event = this.events.find((e) => e.id === id);
    if (!event) return null;
    event.acknowledged = true;
    if (event.status === 'active') event.status = 'acknowledged';
    event.updatedAt = nowIso();
    event.timeline.push({ time: event.updatedAt, text: `${operator}已确认告警，现场复核进行中` });
    return event;
  }

  resolve(id, operator = '集团调度中心') {
    const event = this.events.find((e) => e.id === id);
    if (!event) return null;
    event.status = 'resolved';
    event.resolvedAt = nowIso();
    event.updatedAt = event.resolvedAt;
    event.acknowledged = true;
    event.timeline.push({ time: event.resolvedAt, text: `${operator}确认现场恢复，事件人工闭环` });
    event.actions.forEach((a) => {
      if (a.status !== 'done') {
        a.status = 'done';
        a.time = event.resolvedAt;
      }
    });
    this.activeBySensor.delete(event.sensorId);
    return event;
  }

  active() {
    return this.events.filter((e) => e.status !== 'resolved');
  }

  stats() {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayEvents = this.events.filter((e) => new Date(e.time) >= today);
    const resolved = todayEvents.filter((e) => e.status === 'resolved');
    return {
      active: this.events.filter((e) => e.status !== 'resolved').length,
      critical: this.events.filter((e) => e.status !== 'resolved' && e.level === 'critical').length,
      today: todayEvents.length,
      resolvedToday: resolved.length,
      closureRate: todayEvents.length ? Math.round((resolved.length / todayEvents.length) * 1000) / 10 : 100,
      avgAckSeconds: 42,
      total: this.events.length
    };
  }
}

export function makeAlarmTimeline(event) {
  return event.timeline.map((t) => ({ ...t, clock: fmtTime(t.time) }));
}
