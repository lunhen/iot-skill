import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Simulator, TICK_MS } from './simulator.js';
import { MINE_META, SENSOR_TYPES, DEVICE_CATALOG, SCENARIOS, LINK_NODES, API_PORTS } from './data.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
const PUBLIC = path.join(ROOT, 'public');
const PORT = Number(process.env.PORT || API_PORTS.http);

const sim = new Simulator();
sim.tick();

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
  '.csv': 'text/csv; charset=utf-8'
};

const sseClients = new Set();

function json(res, data, status = 200) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Content-Length': Buffer.byteLength(body)
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk;
      if (body.length > 1_000_000) req.destroy();
    });
    req.on('end', () => {
      if (!body) return resolve({});
      try {
        resolve(JSON.parse(body));
      } catch (error) {
        reject(error);
      }
    });
    req.on('error', reject);
  });
}

function serveStatic(req, res) {
  const pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
  const safePath = pathname === '/' ? '/index.html' : pathname;
  const filePath = path.resolve(PUBLIC, `.${safePath}`);
  if (filePath !== PUBLIC && !filePath.startsWith(PUBLIC + path.sep)) {
    res.writeHead(403);
    return res.end('Forbidden');
  }
  fs.stat(filePath, (err, stat) => {
    if (err || !stat.isFile()) {
      if (pathname !== '/' && !pathname.includes('.')) {
        return serveIndex(res);
      }
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('404 Not Found');
    }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(filePath).toLowerCase()] || 'application/octet-stream',
      'Cache-Control': pathname === '/' || /\.(html|js|css)$/i.test(pathname) ? 'no-store' : 'public, max-age=3600'
    });
    fs.createReadStream(filePath).pipe(res);
  });
}

function serveIndex(res) {
  const file = path.join(PUBLIC, 'index.html');
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  fs.createReadStream(file).pipe(res);
}

function csvEscape(value) {
  const text = String(value ?? '');
  return /[",\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const pathname = url.pathname;

  try {
    if (pathname === '/api/health') {
      return json(res, { ok: true, uptime: process.uptime(), ts: new Date().toISOString() });
    }

    if (pathname === '/api/bootstrap' && req.method === 'GET') {
      return json(res, {
        mines: MINE_META,
        sensorTypes: SENSOR_TYPES,
        devices: DEVICE_CATALOG,
        scenarios: SCENARIOS,
        linkNodes: LINK_NODES,
        tickMs: TICK_MS,
        systemName: '深地智安',
        version: '1.0.0'
      });
    }

    if (pathname === '/api/state' && req.method === 'GET') {
      return json(res, sim.getState());
    }

    if (pathname === '/api/history' && req.method === 'GET') {
      return json(res, {
        series: sim.getHistory({
          faceId: url.searchParams.get('faceId') || undefined,
          sensorId: url.searchParams.get('sensorId') || undefined,
          from: url.searchParams.get('from') || undefined,
          to: url.searchParams.get('to') || undefined
        }),
        ts: new Date().toISOString()
      });
    }

    if (pathname === '/api/alarms' && req.method === 'GET') {
      return json(res, {
        items: sim.getAlarms({
          status: url.searchParams.get('status') || 'all',
          level: url.searchParams.get('level') || 'all',
          mineId: url.searchParams.get('mineId') || 'all',
          limit: Number(url.searchParams.get('limit') || 100)
        }),
        stats: sim.alarmEngine.stats(),
        ts: new Date().toISOString()
      });
    }

    if (pathname === '/api/devices' && req.method === 'GET') {
      return json(res, { groups: sim.deviceSummary(), ts: new Date().toISOString() });
    }

    const alarmMatch = pathname.match(/^\/api\/alarms\/([^/]+)(?:\/(ack|resolve))?$/);
    if (alarmMatch) {
      const id = decodeURIComponent(alarmMatch[1]);
      if (req.method === 'GET' && !alarmMatch[2]) {
        const item = sim.getAlarm(id);
        return item ? json(res, item) : json(res, { error: '告警不存在' }, 404);
      }
      if (req.method === 'POST' && alarmMatch[2]) {
        const body = await readBody(req);
        const item = alarmMatch[2] === 'ack'
          ? sim.ackAlarm(id, body.operator)
          : sim.resolveAlarm(id, body.operator);
        if (!item) return json(res, { error: '告警不存在' }, 404);
        broadcast();
        return json(res, { ok: true, item: sim.getAlarm(id) });
      }
    }

    if (pathname === '/api/scenario' && req.method === 'POST') {
      const body = await readBody(req);
      if (!body.type || !SCENARIOS[body.type]) return json(res, { error: '未知的演练类型' }, 400);
      if (body.type !== 'normal' && !MINE_META.some((m) => m.faces.some((f) => f.id === body.faceId))) {
        return json(res, { error: '工作面不存在' }, 400);
      }
      const scenario = sim.startScenario(body.type, body.faceId);
      broadcast();
      return json(res, { ok: true, scenario: scenario || null, state: sim.getState() });
    }

    if (pathname === '/api/export/alarms.csv' && req.method === 'GET') {
      const items = sim.getAlarms({ limit: 1000 });
      const rows = [
        ['告警编号', '时间', '矿井', '工作面', '测点', '类型', '数值', '单位', '等级', '状态', '原因', '处置结果'],
        ...items.map((e) => [
          e.id,
          new Date(e.time).toLocaleString('zh-CN', { hour12: false }),
          e.mineName,
          e.faceName,
          e.sensorName,
          e.type,
          e.value,
          e.unit,
          e.level,
          e.status === 'resolved' ? '已闭环' : e.acknowledged ? '复核中' : '待处置',
          e.cause,
          e.resolvedAt ? new Date(e.resolvedAt).toLocaleString('zh-CN', { hour12: false }) : ''
        ])
      ];
      const csv = '\uFEFF' + rows.map((row) => row.map(csvEscape).join(',')).join('\r\n');
      res.writeHead(200, {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': 'attachment; filename="mine-alarms.csv"',
        'Cache-Control': 'no-store'
      });
      return res.end(csv);
    }

    if (pathname === '/api/stream' && req.method === 'GET') {
      res.writeHead(200, {
        'Content-Type': 'text/event-stream; charset=utf-8',
        'Cache-Control': 'no-cache, no-transform',
        Connection: 'keep-alive',
        'X-Accel-Buffering': 'no'
      });
      res.write(`retry: 3000\n`);
      res.write(`event: state\ndata: ${JSON.stringify(sim.getState())}\n\n`);
      sseClients.add(res);
      req.on('close', () => sseClients.delete(res));
      return;
    }

    if (pathname.startsWith('/api/')) {
      return json(res, { error: 'Not Found' }, 404);
    }

    serveStatic(req, res);
  } catch (error) {
    console.error('[api]', error);
    if (!res.headersSent) json(res, { error: '服务器内部错误', detail: error.message }, 500);
    else res.end();
  }
});

function broadcast() {
  if (!sseClients.size) return;
  const payload = `event: state\ndata: ${JSON.stringify(sim.getState())}\n\n`;
  for (const client of sseClients) {
    try {
      client.write(payload);
    } catch {
      sseClients.delete(client);
    }
  }
}

setInterval(() => {
  sim.tick();
  broadcast();
}, TICK_MS).unref();

const heartbeat = setInterval(() => {
  for (const client of sseClients) {
    try {
      client.write(`: ping ${Date.now()}\n\n`);
    } catch {
      sseClients.delete(client);
    }
  }
}, 15000);
heartbeat.unref();

server.listen(PORT, '127.0.0.1', () => {
  console.log('');
  console.log('  ██████  深地智安 · 矿井安全物联网监测平台  ██████');
  console.log(`  本地访问: http://127.0.0.1:${PORT}`);
  console.log(`  健康检查: http://127.0.0.1:${PORT}/api/health`);
  console.log(`  数据链路: SSE 实时推送 / ${TICK_MS} ms 采样周期`);
  console.log('');
});

function shutdown() {
  console.log('\n正在关闭服务...');
  for (const client of sseClients) {
    try { client.end(); } catch { /* noop */ }
  }
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 1500).unref();
}

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
