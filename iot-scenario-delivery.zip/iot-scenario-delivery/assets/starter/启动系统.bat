@echo off
chcp 65001 >nul
title 深地智安 · 矿井安全物联网监测平台
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo [错误] 未检测到 Node.js，请先安装 Node.js 20 或更高版本。
  pause
  exit /b 1
)
echo.
echo   深地智安 · 矿井安全物联网监测平台
echo   正在启动本地服务...
echo.
start "" http://127.0.0.1:4173
node server/index.js
pause
