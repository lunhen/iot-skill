import { icon, sensorIcon, typeIcon } from './icons.js?v=20261109-final';
import * as Charts from './charts.js?v=20261109-final';
import {
  $, $$, esc, fmt, compact, clock, dateTime, shortDate, timeAgo,
  levelMeta, levelTag, trendIcon, riskColor, riskLabel, download, toCsv,
  debounce, nowLocalInput, formatDuration
} from './util.js?v=20261109-final';

const App = {
  bootstrap: null,
  state: null,
  alarms: [],
  knownAlarmIds: new Set(),
  route: { name: 'overview', param: null },
  mineFilter: 'all',
  selectedFaceId: 'QL-1301',
  sensorByFace: {},
  faceQuery: '',
  tab: 'overview',
  alarmFilters: { status: 'open', level: 'all', mineId: 'all', query: '' },
  historyFilters: null,
  historyCache: null,
  historyLoading: false,
  deviceGroups: null,
  deviceCategory: '感知层',
  drillDraft: { type: 'gas', faceId: 'QL-1301' },
  timer: null,
  eventSource: null,
  sseAlive: false,
  pollTimer: null,
  lastStateAt: 0,
  toastSeq: 0
};

/* ============================================================
   基础 API
   ============================================================ */
async function api(path, options = {}) {
  const res = await fetch(path, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  if (!res.ok) {
    let detail = '';
    try { detail = (await res.json()).error || ''; } catch { /* noop */ }
    throw new Error(detail || `请求失败 ${res.status}`);
  }
  return res.json();
}

function post(path, body) {
  return api(path, { method: 'POST', body: JSON.stringify(body || {}) });
}

/* ============================================================
   初始化
   ============================================================ */
async function init() {
  hydrateStaticIcons();
  bindGlobalEvents();
  startClock();
  try {
    const [bootstrap, state, alarms] = await Promise.all([
      api('/api/bootstrap'),
      api('/api/state'),
      api('/api/alarms?status=all&limit=100')
    ]);
    App.bootstrap = bootstrap;
    App.state = state;
    App.alarms = alarms.items || [];
    App.knownAlarmIds = new Set(App.alarms.filter((a) => a.status !== 'resolved').map((a) => a.id));
    App.historyFilters = defaultHistoryFilters();
    renderSidebarMines();
    renderMineMenu();
    updateGlobalChrome();
    render();
    connectStream();
    hideBoot();
    setInterval(() => refreshAlarms().catch(() => {}), 15000);
  } catch (error) {
    console.error(error);
    const boot = $('#boot');
    boot.classList.remove('hide');
    boot.innerHTML = `
      <div class="boot-mark" style="color:var(--red)">${icon('alert', 42)}</div>
      <strong style="letter-spacing:.05em">平台接入失败</strong>
      <span style="max-width:420px;text-align:center;line-height:1.8">${esc(error.message)}<br/>请确认已通过 <b style="color:#9feeff">node server/index.js</b> 启动服务后刷新页面。</span>
      <button class="btn btn-primary" style="margin-top:10px" onclick="location.reload()">重新连接</button>
    `;
  }
}

function hideBoot() {
  setTimeout(() => $('#boot').classList.add('hide'), 380);
}

function hydrateStaticIcons() {
  $$('[data-icon]').forEach((el) => {
    el.innerHTML = icon(el.dataset.icon, el.classList.contains('nav-ico') ? 17 : 15);
  });
}

function startClock() {
  const tick = () => {
    const now = new Date();
    const time = $('#clock-time');
    const date = $('#clock-date');
    if (time) time.textContent = clock(now);
    if (date) date.textContent = `${now.getFullYear()}/${String(now.getMonth() + 1).padStart(2, '0')}/${String(now.getDate()).padStart(2, '0')}`;
    updateScenarioBanner();
  };
  tick();
  setInterval(tick, 1000);
}

/* ============================================================
   SSE 实时链路
   ============================================================ */
function connectStream() {
  if (!window.EventSource) return;
  const source = new EventSource('/api/stream');
  App.eventSource = source;
  source.addEventListener('open', () => {
    App.sseAlive = true;
    setLinkState(true);
  });
  source.addEventListener('state', (event) => {
    App.sseAlive = true;
    setLinkState(true);
    try { applyState(JSON.parse(event.data)); } catch (error) { console.error('state parse', error); }
  });
  source.addEventListener('error', () => {
    App.sseAlive = false;
    setLinkState(false);
  });
}

function setLinkState(online) {
  const pill = $('#link-status');
  if (!pill) return;
  pill.style.borderColor = online ? '' : 'rgba(255,95,109,.28)';
  pill.style.background = online ? '' : 'rgba(255,95,109,.06)';
  const dot = $('.pulse-dot', pill);
  if (dot) dot.style.background = online ? '' : 'var(--red)';
  const title = $('b', pill);
  if (title) title.textContent = online ? '实时链路正常' : '实时链路重连中';
}

function applyState(next) {
  const previousActive = App.state?.system?.activeAlarms;
  App.state = next;
  App.lastStateAt = Date.now();
  updateGlobalChrome();
  updateScenarioBanner();

  const active = (next.alarms || []).filter((a) => a.status !== 'resolved');
  let discovered = false;
  for (const alarm of active) {
    if (!App.knownAlarmIds.has(alarm.id)) {
      App.knownAlarmIds.add(alarm.id);
      discovered = true;
      toast('新的安全告警', `${alarm.faceName} ${alarm.sensorName} ${alarm.value}${alarm.unit}`, alarm.level === 'critical' ? 'error' : 'warn', 5200);
    }
  }
  if (discovered) refreshAlarms().catch(() => {});
  if (previousActive !== undefined && active.length < previousActive) {
    refreshAlarms().catch(() => {});
  }

  if (App.route.name === 'overview') updateOverview();
  if (App.route.name === 'face') updateFaceLive();
  if (App.route.name === 'alarms') {
    $('#alarm-kpis') && updateAlarmKpis();
    if (document.activeElement?.tagName !== 'INPUT') renderAlarmTable();
  }
  if (App.route.name === 'topology') updateTopologyLive();
}

/* ============================================================
   Global chrome
   ============================================================ */
function renderSidebarMines() {
  const wrap = $('#side-mines');
  if (!wrap || !App.bootstrap) return;
  wrap.innerHTML = App.bootstrap.mines.map((mine) => {
    const live = App.state?.mines.find((m) => m.id === mine.id);
    return `<a class="mine-link ${App.mineFilter === mine.id ? 'active' : ''}" href="#/overview" data-mine-filter="${mine.id}" style="--c:${mine.color}">
      <i class="dot"></i><b>${esc(mine.name)}</b><small>${live ? live.online : 24}P</small>
    </a>`;
  }).join('');
}

function renderMineMenu() {
  const menu = $('#mine-menu');
  if (!menu || !App.bootstrap) return;
  menu.innerHTML = [
    `<button class="mine-option ${App.mineFilter === 'all' ? 'active' : ''}" data-mine-filter="all"><i style="--c:var(--teal)"></i>全集团<small>3 MINES</small></button>`,
    ...App.bootstrap.mines.map((mine) => `<button class="mine-option ${App.mineFilter === mine.id ? 'active' : ''}" data-mine-filter="${mine.id}"><i style="--c:${mine.color}"></i>${esc(mine.name)}<small>${esc(mine.capacity)}</small></button>`)
  ].join('');
}

function mineLabel() {
  if (App.mineFilter === 'all') return '全集团';
  return App.bootstrap?.mines.find((m) => m.id === App.mineFilter)?.name || '全集团';
}

function updateGlobalChrome() {
  if (!App.state) return;
  const active = App.state.system.activeAlarms;
  const badge = $('#bell-badge');
  const navBadge = $('#nav-alarm-count');
  if (badge) { badge.textContent = active; badge.style.display = active ? '' : 'none'; }
  if (navBadge) { navBadge.textContent = active; navBadge.style.display = active ? '' : 'none'; }
  const linkSmall = $('#link-status small');
  if (linkSmall && App.state.link) linkSmall.textContent = `${App.state.system.totalPoints} 测点 · RTT ${App.state.link.rtt}ms`;
  const label = $('#mine-filter-label');
  if (label) label.textContent = mineLabel();
  $$('#side-mines .mine-link').forEach((el) => {
    el.classList.toggle('active', App.mineFilter === el.dataset.mineFilter);
  });
}

/* ============================================================
   Router
   ============================================================ */
function parseHash() {
  const raw = location.hash.replace(/^#\/?/, '');
  const [name = 'overview', param = null] = raw.split('/');
  if (!['overview', 'face', 'alarms', 'history', 'topology', 'devices'].includes(name)) {
    return { name: 'overview', param: null };
  }
  return { name, param: param || null };
}

function navigate(hash) {
  if (location.hash === hash) render();
  else location.hash = hash;
}

function render() {
  if (!App.state) return;
  App.route = parseHash();
  if (App.route.name === 'face') {
    const faces = allFaces();
    const faceId = App.route.param || App.selectedFaceId;
    if (faces.some((f) => f.id === faceId)) App.selectedFaceId = faceId;
    else { App.selectedFaceId = faces[0]?.id || 'QL-1301'; App.route.param = App.selectedFaceId; }
  }
  updateNav();
  updateBreadcrumb();
  const view = $('#view');
  if (!view) return;
  closeDrawer(true);
  closeModal(true);
  if (App.route.name === 'overview') renderOverview();
  if (App.route.name === 'face') renderFace();
  if (App.route.name === 'alarms') renderAlarmsPage();
  if (App.route.name === 'history') renderHistoryPage();
  if (App.route.name === 'topology') renderTopology();
  if (App.route.name === 'devices') renderDevicesPage();
  view.scrollTop = 0;
  document.title = `${routeTitle(App.route.name)} · 深地智安`;
}

function updateNav() {
  $$('.nav-item').forEach((el) => el.classList.toggle('active', el.dataset.route === App.route.name));
}

function updateBreadcrumb() {
  const crumb = $('#breadcrumb');
  if (!crumb) return;
  const map = { overview: '综合态势', face: '工作面监控', alarms: '告警中心', history: '历史数据', topology: '链路拓扑', devices: '设备台账' };
  const group = ['history', 'topology', 'devices'].includes(App.route.name) ? '分析 · 配置' : '监测中心';
  crumb.innerHTML = `<span>${group}</span><i>/</i><b>${map[App.route.name]}</b>`;
}

function routeTitle(name) {
  return { overview: '综合态势', face: '工作面监控', alarms: '告警中心', history: '历史数据', topology: '链路拓扑', devices: '设备台账' }[name] || '综合态势';
}

function allFaces() {
  return App.state?.mines.flatMap((m) => m.faces) || [];
}

function findFace(id) {
  return allFaces().find((f) => f.id === id) || allFaces()[0];
}

function scopedMines() {
  const mines = App.state?.mines || [];
  return App.mineFilter === 'all' ? mines : mines.filter((m) => m.id === App.mineFilter);
}

function scopedAlarms() {
  return App.alarms.filter((a) => (App.mineFilter === 'all' ? true : a.mineId === App.mineFilter));
}

function setMineFilter(id) {
  App.mineFilter = id;
  renderSidebarMines();
  renderMineMenu();
  updateGlobalChrome();
  if (App.route.name !== 'overview') navigate('#/overview');
  else render();
}

/* ============================================================
   Overview
   ============================================================ */
function renderOverview() {
  const view = $('#view');
  const mines = scopedMines();
  const scopeName = App.mineFilter === 'all' ? '全集团' : mineLabel();
  const totalPoints = mines.reduce((s, m) => s + m.total, 0);
  const active = App.alarms.filter((a) => a.status !== 'resolved' && (App.mineFilter === 'all' || a.mineId === App.mineFilter));

  view.innerHTML = `<div class="page">
    <div class="page-head">
      <div>
        <div class="eyebrow">GROUP SAFETY SITUATION / ${new Date().getFullYear()}</div>
        <h1 class="page-title">${scopeName}<span class="accent">安全态势</span></h1>
        <p class="page-sub">3 座矿井 · 9 个采掘工作面 · ${totalPoints} 个环境测点在线感知，异常事件秒级触达</p>
      </div>
      <div class="head-actions">
        <div class="head-note">${icon('shield', 13)} 数据更新于 <b class="mono" id="ov-updated">${clock(new Date(), false)}</b></div>
        <button class="btn btn-sm" id="report-export">${icon('download', 13)} 导出日报</button>
        <button class="btn btn-sm btn-primary" id="ov-drill">${icon('play', 13)} 情景演练</button>
      </div>
    </div>

    <div class="kpi-grid" id="kpi-grid">${kpiHTML(mines, active)}</div>
    <div class="mine-grid" id="mine-grid" style="${mines.length === 1 ? 'grid-template-columns:1fr' : ''}">${mineCardsHTML(mines)}</div>

    <div class="dash-grid c-2">
      <section class="panel">
        <div class="panel-head">
          <div>
            <div class="panel-title">${icon('activity')} 瓦斯浓度实时趋势</div>
            <div class="panel-sub">各矿井采掘工作面 CH₄ 均值 · 近 60 秒滚动窗口</div>
          </div>
          <div class="panel-actions"><div class="legend" id="gas-legend"></div></div>
        </div>
        <div class="panel-body"><div class="chart-wrap h-210"><canvas id="gas-chart"></canvas></div></div>
      </section>

      <section class="panel">
        <div class="panel-head">
          <div>
            <div class="panel-title">${icon('alarm')} 实时告警</div>
            <div class="panel-sub">按严重程度排序 · 待确认与复核中事件</div>
          </div>
          <a class="panel-link" href="#/alarms">全部告警 ${icon('right', 12)}</a>
        </div>
        <div class="panel-body" id="ov-alarms">${activeAlarmListHTML(active)}</div>
      </section>
    </div>

    <div class="dash-grid c-3">
      <section class="panel">
        <div class="panel-head">
          <div><div class="panel-title">${icon('target')} 工作面风险排行</div><div class="panel-sub">综合瓦斯、环境与未闭环事件计算</div></div>
        </div>
        <div class="panel-body" id="ov-risk-rank">${riskRankHTML(mines)}</div>
      </section>

      <section class="panel">
        <div class="panel-head">
          <div><div class="panel-title">${icon('history')} 近 24 小时告警分布</div><div class="panel-sub">按两小时聚合 · 含已闭环事件</div></div>
        </div>
        <div class="panel-body"><div class="chart-wrap h-160"><canvas id="alarm-bar"></canvas></div></div>
      </section>

      <section class="panel">
        <div class="panel-head">
          <div><div class="panel-title">${icon('signal')} 链路与保障</div><div class="panel-sub">端—边—网—云—用全链路健康度</div></div>
          <a class="panel-link" href="#/topology">拓扑 ${icon('right', 12)}</a>
        </div>
        <div class="panel-body" id="ov-link">${linkHealthHTML()}</div>
      </section>
    </div>
  </div>`;
  drawOverviewCharts();
  updateOverviewDynamic();
}

function kpiHTML(mines, active) {
  const total = mines.reduce((s, m) => s + m.total, 0);
  const online = mines.reduce((s, m) => s + m.online, 0);
  const gasValues = mines.flatMap((m) => m.faces.flatMap((f) => f.sensors.filter((s) => s.type === 'ch4').map((s) => s.value)));
  const avgGas = gasValues.length ? gasValues.reduce((a, b) => a + b, 0) / gasValues.length : 0;
  const maxGas = gasValues.length ? Math.max(...gasValues) : 0;
  const closure = App.state.system.closureRate;
  const risk = mines.length ? Math.round(mines.reduce((s, m) => s + m.risk, 0) / mines.length) : 0;
  const gasSpark = averageHistory(mines, 'ch4', 26);
  const sparkAlarm = [1, 2, 1, 3, active.length + 2, active.length + 1, active.length + 3, active.length + 1, active.length + 2, active.length].map((v) => Math.max(0, v));
  const sparkClose = [72, 74, 76, 75, 78, 80, 81, 80, closure - 2, closure];
  const sparkRisk = [risk + 6, risk + 4, risk + 5, risk + 2, risk + 3, risk, risk + 1, risk].map((v) => Math.max(0, v));
  const chips = [
    { key: 'online', vals: [96, 97, 97.5, 98, 99, 99.2, 99.5, 99.7, 99.8, 99.8], color: '#35e0c0' },
    { key: 'alarm', vals: sparkAlarm, color: '#ff5f6d' },
    { key: 'gas', vals: gasSpark, color: '#ffb547' },
    { key: 'close', vals: sparkClose, color: '#4f8dff' }
  ];
  return `
    <article class="kpi-card" style="--k-color:#35e0c0;--k-soft:rgba(53,224,192,.1)">
      <div class="kpi-top"><span class="kpi-label">在线测点</span><span class="kpi-icon">${icon('radio', 14)}</span></div>
      <div class="kpi-value"><b>${online}</b><span>/ ${total}</span></div>
      <div class="kpi-foot"><span class="delta good">在线率 ${((online / Math.max(1, total)) * 100).toFixed(1)}%</span><span>· 9 座分站直连</span></div>
      <canvas class="kpi-spark" data-spark="online"></canvas>
    </article>
    <article class="kpi-card" style="--k-color:#ff5f6d;--k-soft:rgba(255,95,109,.1)">
      <div class="kpi-top"><span class="kpi-label">活动告警</span><span class="kpi-icon">${icon('alarm', 14)}</span></div>
      <div class="kpi-value"><b>${active.length}</b><span>起</span></div>
      <div class="kpi-foot"><span class="delta ${active.length ? 'bad' : 'good'}">严重 ${active.filter((a) => a.level === 'critical').length} 起</span><span>· 待处置 ${active.filter((a) => !a.acknowledged).length} 起</span></div>
      <canvas class="kpi-spark" data-spark="alarm"></canvas>
    </article>
    <article class="kpi-card" style="--k-color:#ffb547;--k-soft:rgba(255,181,71,.1)">
      <div class="kpi-top"><span class="kpi-label">平均瓦斯浓度</span><span class="kpi-icon">${icon('flame', 14)}</span></div>
      <div class="kpi-value"><b>${avgGas.toFixed(2)}</b><span>%CH₄</span></div>
      <div class="kpi-foot"><span class="delta ${maxGas >= 1 ? 'bad' : 'good'}">峰值 ${maxGas.toFixed(2)}%</span><span>· 预警线 0.80%</span></div>
      <canvas class="kpi-spark" data-spark="gas"></canvas>
    </article>
    <article class="kpi-card" style="--k-color:#4f8dff;--k-soft:rgba(79,141,255,.1)">
      <div class="kpi-top"><span class="kpi-label">今日处置闭环率</span><span class="kpi-icon">${icon('shield', 14)}</span></div>
      <div class="kpi-value"><b>${closure.toFixed(1)}</b><span>%</span></div>
      <div class="kpi-foot"><span class="delta good">今日 ${App.state.system.todayAlarms} 起</span><span>· 已闭环 ${App.state.system.resolvedToday} 起</span></div>
      <canvas class="kpi-spark" data-spark="close"></canvas>
    </article>
    <article class="kpi-card risk-kpi" style="--k-color:${riskColor(risk)};--k-soft:${riskColor(risk)}1f;--risk-color:${riskColor(risk)}">
      <div class="kpi-top"><span class="kpi-label">安全风险指数</span><span class="kpi-icon">${icon('gauge', 14)}</span></div>
      <div class="kpi-value"><b>${risk}</b><span>/ 100</span></div>
      <div class="kpi-foot"><span class="delta ${risk >= 50 ? 'bad' : 'good'}">${riskLabel(risk)}</span><span>· 较昨日 -3.2</span></div>
      <canvas class="kpi-spark" data-spark="risk"></canvas>
    </article>
  `;
}

function averageHistory(mines, type, count) {
  const series = mines.flatMap((m) => m.faces.flatMap((f) => f.sensors.filter((s) => s.type === type).map((s) => s.history))).filter((h) => h?.length);
  if (!series.length) return Array.from({ length: count }, (_, i) => 0.5 + Math.sin(i / 3) * 0.04);
  const len = Math.min(count, ...series.map((s) => s.length));
  return Array.from({ length: len }, (_, i) => {
    const idx = series[0].length - len + i;
    return series.reduce((sum, s) => sum + s[s.length - len + i], 0) / series.length;
  });
}

function mineCardsHTML(mines) {
  return mines.map((mine) => {
    const alert = App.alarms.find((a) => a.mineId === mine.id && a.status !== 'resolved');
    return `<article class="mine-card ${alert ? 'alert' : ''}" style="--c:${mine.color};--risk:${riskColor(mine.risk)}" data-mine-open="${mine.id}">
      <div class="mine-head">
        <div class="mine-title">
          <h3><span></span>${esc(mine.name)}</h3>
          <p>${esc(mine.location)} · ${esc(mine.capacity)} · ${esc(mine.gasLevel || mine.levelLabel)}</p>
        </div>
        <div class="mine-risk"><b>${mine.risk}</b><span>风险指数</span></div>
      </div>
      <div class="mine-stats">
        <div class="mine-stat"><span>平均瓦斯</span><b>${mine.avgGas.toFixed(2)}<small>%</small></b></div>
        <div class="mine-stat"><span>平均温度</span><b>${mine.avgTemp.toFixed(1)}<small>℃</small></b></div>
        <div class="mine-stat"><span>平均风速</span><b>${mine.avgWind.toFixed(2)}<small>m/s</small></b></div>
        <div class="mine-stat"><span>在线测点</span><b>${mine.online}<small>/${mine.total}</small></b></div>
      </div>
      <div class="face-chips">
        ${mine.faces.map((f) => `<button class="face-chip" data-face="${f.id}" style="--lv:${levelMeta(f.level).color}"><i></i>${esc(f.name.replace('工作面', ''))}</button>`).join('')}
      </div>
      <div class="mine-alert ${alert ? '' : 'normal'}">${alert ? `${icon('alert', 11)} ${esc(alert.faceName)} · ${esc(alert.sensorName)} ${alert.value}${alert.unit} 待复核` : `${icon('check', 11)} 当前无未闭环告警，环境参数处于安全区间`}</div>
    </article>`;
  }).join('');
}

function activeAlarmListHTML(active) {
  if (!active.length) {
    return `<div class="empty">${icon('shield', 26)}<span>暂无未闭环告警，系统运行平稳</span></div>`;
  }
  return `<div class="alarm-list">${active.slice(0, 5).map((a) => {
    const meta = levelMeta(a.level);
    return `<div class="alarm-item" data-alarm-open="${a.id}" style="--lv:${meta.color}">
      <div class="alarm-level-bar"></div>
      <div class="alarm-main">
        <div class="alarm-line1"><b>${esc(a.faceName)}</b><span>${esc(a.sensorName)}</span>${levelTag(a.level)}</div>
        <div class="alarm-line2">${esc(a.cause)} · ${a.acknowledged ? '复核中' : '待确认'}</div>
      </div>
      <div class="alarm-val"><b>${a.value}<small>${esc(a.unit)}</small></b><span>${clock(a.time)}</span></div>
    </div>`;
  }).join('')}</div>
  <div class="mini-chain">
    <div class="mini-chain-title">告警处置链路</div>
    <div class="mini-chain-flow">
      <span>感知采集</span><i></i><span>规则判定</span><i></i><span>自动联动</span><i></i><span>人工复核</span><i></i><span>事件闭环</span>
    </div>
    <div class="mini-chain-foot"><span>今日已闭环 <b>${App.state.system.resolvedToday}</b> 起</span><span>平均确认 <b>42s</b></span><span>联动成功率 <b>96.4%</b></span></div>
  </div>`;
}

function riskRankHTML(mines) {
  const faces = mines.flatMap((m) => m.faces).sort((a, b) => b.risk - a.risk).slice(0, 5);
  if (!faces.length) return `<div class="empty">${icon('target', 24)}<span>暂无数据</span></div>`;
  return `<div class="rank-list">${faces.map((f, i) => {
    const color = riskColor(f.risk);
    return `<div class="rank-row">
      <span class="rank-index ${i < 2 ? 'top' : ''}">${String(i + 1).padStart(2, '0')}</span>
      <div class="rank-main">
        <div class="rank-line"><b>${esc(f.name)}</b><span>${esc(f.mineName)}</span></div>
        <div class="rank-bar"><i style="width:${Math.min(100, f.risk)}%;--c:${color}"></i></div>
      </div>
      <span class="rank-val" style="color:${color}">${f.risk}</span>
    </div>`;
  }).join('')}</div>`;
}

function linkHealthHTML() {
  const link = App.state.link;
  const nodes = [
    { name: '感知', color: '#35e0c0' },
    { name: '分站', color: '#58d6ff' },
    { name: '环网', color: '#4f8dff' },
    { name: '平台', color: '#b38cff' },
    { name: '应用', color: '#ffb547' }
  ];
  return `<div class="health-flow">${nodes.map((n, i) => `<div class="health-node"><i style="--c:${n.color}"></i><span>${n.name}</span>${i < nodes.length - 1 ? '<em></em>' : ''}</div>`).join('')}</div>
    <div class="health-grid">
      <div><span>链路时延</span><b>${link.rtt}<small>ms</small></b></div>
      <div><span>丢包率</span><b>${link.loss}<small>%</small></b></div>
      <div><span>环网状态</span><b class="teal">双环自愈</b></div>
      <div><span>数据吞吐</span><b>${link.throughput}<small>Mbps</small></b></div>
    </div>
    <div class="health-foot"><span class="pulse-dot"></span> 9/9 分站在线 · 最近同步 ${clock(link.lastSync)}</div>`;
}

function drawOverviewCharts() {
  const gasCanvas = $('#gas-chart');
  const barCanvas = $('#alarm-bar');
  if (!gasCanvas || !barCanvas) return;
  const mines = scopedMines();
  const palette = ['#35e0c0', '#4f8dff', '#b38cff'];
  const series = mines.map((m, i) => ({
    name: m.shortName,
    color: m.color || palette[i],
    values: averageHistory([m], 'ch4', 30)
  }));
  const len = Math.min(...series.map((s) => s.values.length));
  series.forEach((s) => { s.values = s.values.slice(s.values.length - len); });
  const legend = $('#gas-legend');
  if (legend) legend.innerHTML = series.map((s) => `<span class="legend-item"><i style="--c:${s.color}"></i>${s.name} <b>${s.values.at(-1)?.toFixed(2) ?? '--'}%</b></span>`).join('');
  Charts.line(gasCanvas, {
    series,
    labels: Array.from({ length: len }, (_, i) => `${Math.max(0, (len - i) * 2)}s`),
    thresholds: [{ value: 0.8, color: '#ffb547', label: '预警 0.80%' }, { value: 1.0, color: '#ff5f6d', label: '告警 1.00%' }],
    min: 0,
    max: 1.2
  });

  const bins = alarmBins();
  Charts.bar(barCanvas, {
    data: bins.map((b) => ({ label: b.label, value: b.value, color: b.current ? '#ff7a59' : '#4f8dff' }))
  });
  drawSparks();
}

function alarmBins() {
  const now = new Date();
  const bins = [];
  for (let i = 11; i >= 0; i -= 1) {
    const end = new Date(now.getTime() - i * 2 * 3600_000);
    const start = new Date(end.getTime() - 2 * 3600_000);
    bins.push({
      label: `${String(end.getHours()).padStart(2, '0')}时`,
      value: App.alarms.filter((a) => {
        const t = new Date(a.time).getTime();
        return t >= start.getTime() && t < end.getTime();
      }).length,
      current: i === 0
    });
  }
  return bins;
}

function drawSparks() {
  const data = {
    online: [96, 96.8, 97.2, 98, 98.6, 99, 99.3, 99.5, 99.7, 99.8],
    alarm: [1, 2, 1, 3, 2, 4, 3, 3, 2, App.alarms.filter((a) => a.status !== 'resolved').length],
    gas: averageHistory(scopedMines(), 'ch4', 24),
    close: [76, 78, 79, 80, 81, 80, 82, 81.5, 80.8, App.state.system.closureRate],
    risk: scopedMines().map((m) => m.risk)
  };
  $$('[data-spark]').forEach((canvas) => {
    const key = canvas.dataset.spark;
    const colors = { online: '#35e0c0', alarm: '#ff5f6d', gas: '#ffb547', close: '#4f8dff', risk: riskColor(data.risk?.[0] || 20) };
    Charts.sparkline(canvas, { values: data[key] || [], color: colors[key] });
  });
}

function updateOverview() {
  if (!App.state || !$('#kpi-grid')) return;
  const mines = scopedMines();
  const active = App.alarms.filter((a) => a.status !== 'resolved' && (App.mineFilter === 'all' || a.mineId === App.mineFilter));
  $('#kpi-grid').innerHTML = kpiHTML(mines, active);
  $('#mine-grid').innerHTML = mineCardsHTML(mines);
  $('#mine-grid').style.gridTemplateColumns = mines.length === 1 ? '1fr' : '';
  $('#ov-alarms').innerHTML = activeAlarmListHTML(active);
  $('#ov-risk-rank').innerHTML = riskRankHTML(mines);
  $('#ov-link').innerHTML = linkHealthHTML();
  const updated = $('#ov-updated');
  if (updated) updated.textContent = clock(new Date(), false);
  drawOverviewCharts();
}

function updateOverviewDynamic() {
  // 首屏渲染后补充一次绑定状态，避免动画期间数据空白
  const updated = $('#ov-updated');
  if (updated) updated.textContent = clock(new Date(), false);
}

/* ============================================================
   工作面监控
   ============================================================ */
function renderFace() {
  const face = findFace(App.selectedFaceId);
  if (!face) return;
  App.selectedFaceId = face.id;
  const faceKey = face.id;
  let sensor = face.sensors.find((s) => s.id === App.sensorByFace[faceKey]) || face.sensors.find((s) => s.type === 'ch4') || face.sensors[0];
  App.sensorByFace[faceKey] = sensor.id;
  const view = $('#view');
  view.innerHTML = `<div class="page">
    <div class="page-head" style="margin-bottom:12px">
      <div>
        <div class="eyebrow">WORKFACE DIGITAL TWIN / ${esc(face.mineName)}</div>
        <h1 class="page-title">${esc(face.name)} <span class="mono" style="font-size:11px;color:var(--dim);font-weight:400">${face.id}</span></h1>
        <div class="face-meta">
          <span>${icon('layers', 11)} ${face.type}工作面</span>
          <span>埋深 <b>${face.depth}m</b></span>
          <span>当班 <b>${face.crew}人</b></span>
          <span>推进 <b>${face.advance}</b></span>
          <span>通风 <b>${face.ventilation}</b></span>
        </div>
      </div>
      <div class="head-actions">
        <span id="face-status">${levelTag(face.level, face.activeAlarms ? `${face.levelLabel} · ${face.activeAlarms} 起` : '安全运行')}</span>
        <button class="btn btn-sm" data-face-history="${face.id}">${icon('history', 13)} 历史曲线</button>
        <button class="btn btn-sm btn-primary" data-face-drill="${face.id}">${icon('play', 13)} 就地演练</button>
      </div>
    </div>

    <div class="face-layout">
      <aside class="panel tree-panel">
        <div class="tree-search"><div class="search-box">${icon('search', 12)}<input id="face-search" placeholder="搜索矿井 / 工作面" value="${esc(App.faceQuery)}" autocomplete="off"/></div></div>
        <div id="face-tree">${faceTreeHTML()}</div>
        <div class="tree-tip">${icon('signal', 10)} 测点状态实时刷新 · 点击红色测点查看告警联动链路</div>
      </aside>

      <div class="face-stage">
        <section class="panel stage-panel">
          <div class="stage-topline">
            <div class="legend">
              <span class="legend-item"><i style="--c:#35e0c0"></i>正常</span>
              <span class="legend-item"><i style="--c:#ffb547"></i>预警</span>
              <span class="legend-item"><i style="--c:#ff7a59"></i>告警</span>
              <span class="legend-item"><i style="--c:#ff5f6d"></i>严重</span>
            </div>
            <div class="stage-tools">
              <button class="icon-btn" data-action="toggle-flow" title="显示/隐藏风流">${icon('wind', 13)}</button>
              <button class="icon-btn" data-action="face-refresh" title="刷新测点">${icon('refresh', 13)}</button>
            </div>
          </div>
          <div class="face-canvas" id="face-canvas">${faceCanvasHTML(face, sensor)}</div>
          <div class="equipment-strip" id="equipment-strip">${equipmentStripHTML(face)}</div>
        </section>

        <section class="panel face-bottom">
          <div class="panel-head" style="padding-bottom:7px">
            <div><div class="panel-title">${icon('activity')} 测点实时数据</div><div class="panel-sub">8 类环境测点 · 2 秒采样 · RS485 总线汇聚</div></div>
            <div class="panel-actions"><span class="status-pill"><i></i>分站 KJ90-F16(B) 在线</span></div>
          </div>
          <div class="panel-body" style="padding:0 16px 12px">
            <div class="table-wrap"><table class="data-table" id="face-sensor-table">${sensorTableHTML(face, sensor)}</table></div>
          </div>
        </section>
      </div>

      <aside class="sensor-panel">
        <div class="panel">
          <div id="sensor-panel-inner">${sensorPanelHTML(face, sensor)}</div>
        </div>
      </aside>
    </div>
  </div>`;
  drawFaceCharts(face, sensor);
}

function faceTreeHTML() {
  const q = App.faceQuery.trim();
  return (App.state?.mines || []).map((mine) => {
    const faces = mine.faces.filter((f) => !q || f.name.includes(q) || mine.name.includes(q));
    if (!faces.length) return '';
    return `<div class="tree-mine">
      <div class="tree-mine-head" style="--c:${mine.color}"><i></i>${esc(mine.name)}<span>${mine.online}P</span></div>
      ${faces.map((f) => `<button class="tree-face ${f.id === App.selectedFaceId ? 'active' : ''}" data-face="${f.id}"><i style="--lv:${levelMeta(f.level).color}"></i><b>${esc(f.name)}</b><small>${f.gas.toFixed(2)}%</small></button>`).join('')}
    </div>`;
  }).join('') || `<div class="empty">${icon('search', 22)}<span>未找到匹配的工作面</span></div>`;
}

function faceCanvasHTML(face, selectedSensor) {
  return `${faceMapSVG(face)}
    ${face.sensors.map((s) => sensorMarkerHTML(s, s.id === selectedSensor?.id)).join('')}
    <div class="stage-legend">
      <span><i style="background:#35e0c0"></i>环境测点</span>
      <span><i style="background:#4f8dff"></i>进风风流</span>
      <span><i style="background:#ff7a59"></i>回风风流</span>
    </div>
    <div class="stage-scale">SCHEMATIC · 1:500</div>`;
}

const MARKER_LABEL = { ch4: 'CH₄ T1', ch4b: 'CH₄ T2', co: 'CO', o2: 'O₂', temp: 'T', humidity: 'RH', dust: 'PM', wind: 'V' };

function sensorMarkerHTML(s, active) {
  const meta = levelMeta(s.level);
  return `<button class="sensor-marker ${s.level} ${active ? 'active' : ''}" data-sensor="${s.id}" title="${esc(s.name)} · ${s.display}${esc(s.unit)}" style="left:${s.position.x}%;top:${s.position.y}%;--lv:${meta.color};--lv-soft:${meta.soft}">
    <span class="sensor-dot">${sensorIcon(s.type, 12)}</span>
    <span class="sensor-label">${MARKER_LABEL[s.type] || esc(s.name)} <b>${s.display}</b><small>${esc(s.unit)}</small></span>
  </button>`;
}

function faceMapSVG(face) {
  const faceNo = face.name.split(' ')[0];
  return `<svg class="mine-map" viewBox="0 0 1000 500" preserveAspectRatio="none" aria-hidden="true">
    <defs>
      <linearGradient id="roadGrad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="#173249" stop-opacity=".85"/>
        <stop offset="1" stop-color="#0b1e30" stop-opacity=".86"/>
      </linearGradient>
      <linearGradient id="faceGrad" x1="0" y1="0" x2="1" y2="0">
        <stop offset="0" stop-color="#26506c"/>
        <stop offset="1" stop-color="#102b43"/>
      </linearGradient>
      <pattern id="goafHatch" width="16" height="16" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
        <line x1="0" y1="0" x2="0" y2="16" stroke="#244257" stroke-width="1" opacity=".55"/>
      </pattern>
      <pattern id="coalDots" width="20" height="20" patternUnits="userSpaceOnUse">
        <circle cx="4" cy="4" r="1" fill="#4b6c84" opacity=".5"/>
        <circle cx="14" cy="13" r="1" fill="#4b6c84" opacity=".35"/>
      </pattern>
      <marker id="arrowBlue" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
        <path d="M0 0 L7 3 L0 6 Z" fill="#4f8dff" opacity=".8"/>
      </marker>
      <marker id="arrowOrange" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
        <path d="M0 0 L7 3 L0 6 Z" fill="#ff7a59" opacity=".8"/>
      </marker>
    </defs>

    <rect x="24" y="86" width="700" height="340" rx="3" fill="none" stroke="rgba(100,151,192,.12)" stroke-dasharray="5 7"/>
    <path d="M50 92 H690 V158 H50 Z" fill="url(#roadGrad)" stroke="rgba(126,194,255,.28)" stroke-width="1"/>
    <path d="M50 342 H690 V408 H50 Z" fill="url(#roadGrad)" stroke="rgba(126,194,255,.28)" stroke-width="1"/>
    <path d="M662 92 H724 V408 H662 Z" fill="url(#faceGrad)" stroke="rgba(126,194,255,.35)" stroke-width="1"/>

    <path d="M60 382 H650" stroke="#4f8dff" stroke-width="1.6" stroke-dasharray="8 9" marker-end="url(#arrowBlue)" class="airflow" opacity=".7"/>
    <path d="M690 370 V142" stroke="#4f8dff" stroke-width="1.6" stroke-dasharray="8 9" marker-end="url(#arrowBlue)" class="airflow" opacity=".7"/>
    <path d="M650 125 H90" stroke="#ff7a59" stroke-width="1.6" stroke-dasharray="8 9" marker-end="url(#arrowOrange)" class="airflow" opacity=".65"/>

    <path d="M724 96 H950 V404 H724 Z" fill="url(#goafHatch)" stroke="rgba(120,168,214,.18)" stroke-dasharray="4 5"/>
    <path d="M724 96 H950 V404 H724 Z" fill="url(#coalDots)" opacity=".5"/>
    <text x="800" y="252" fill="#6e879e" font-size="13" text-anchor="middle" letter-spacing="4">采 空 区</text>
    <text x="800" y="274" fill="#4d6479" font-size="8" text-anchor="middle" letter-spacing="2">GOAF · 自然发火监测区</text>

    ${Array.from({ length: 11 }, (_, i) => `<g opacity=".75"><rect x="668" y="${112 + i * 26}" width="8" height="18" rx="1" fill="#3b6a88"/><rect x="710" y="${112 + i * 26}" width="8" height="18" rx="1" fill="#3b6a88"/><line x1="676" y1="${121 + i * 26}" x2="710" y2="${121 + i * 26}" stroke="#5e91b0" stroke-width="1"/></g>`).join('')}
    <rect x="672" y="238" width="42" height="26" rx="3" fill="#0c2235" stroke="#57c5e8" stroke-width="1.2"/>
    <circle cx="681" cy="251" r="3" fill="#57c5e8"/>
    <circle cx="705" cy="251" r="3" fill="#57c5e8"/>
    <text x="693" y="282" fill="#78d8f2" font-size="7" text-anchor="middle">采煤机</text>

    <path d="M90 374 H655" stroke="rgba(126,194,255,.24)" stroke-width="3" stroke-dasharray="2 5"/>
    <text x="90" y="388" fill="#6d879d" font-size="8">刮板输送机</text>
    <text x="88" y="125" fill="#8ca7bd" font-size="10" letter-spacing="2">回风巷 · RETURN AIRWAY</text>
    <text x="88" y="377" fill="#8ca7bd" font-size="10" letter-spacing="2">进风巷 · INTAKE AIRWAY</text>
    <text x="692" y="88" fill="#b2c9db" font-size="10" text-anchor="middle" letter-spacing="1">${esc(faceNo)} 工作面</text>
    <text x="950" y="86" fill="#4e687d" font-size="8" text-anchor="end">N ↑</text>
    <circle cx="944" cy="98" r="10" fill="none" stroke="rgba(120,168,214,.28)"/>
    <path d="M944 92 L948 102 L944 99 L940 102 Z" fill="#7e9bb2"/>
  </svg>`;
}

function equipmentStripHTML(face) {
  const e = face.equipment;
  const items = [
    { key: 'fan', name: e.fan.name, status: e.fan.status, detail: e.fan.detail, icon: 'fan', state: e.fan.state },
    { key: 'power', name: e.power.name, status: e.power.status, detail: e.power.detail, icon: 'zap', state: e.power.state },
    { key: 'spray', name: e.spray.name, status: e.spray.status, detail: e.spray.detail, icon: 'droplet', state: e.spray.state },
    { key: 'siren', name: e.siren.name, status: e.siren.status, detail: e.siren.detail, icon: 'alarm', state: e.siren.state },
    { key: 'camera', name: e.camera.name, status: e.camera.status, detail: e.camera.detail, icon: 'video', state: e.camera.state }
  ];
  return items.map((item) => `<div class="equip-item ${item.state}">
    <div class="equip-ico">${icon(item.icon, 13)}</div>
    <div class="equip-copy"><b>${item.name}</b><span>${item.status} · ${item.detail}</span></div>
  </div>`).join('');
}

function sensorTableHTML(face, selected) {
  return `<thead><tr><th>测点</th><th>安装位置</th><th>实时值</th><th>状态</th><th>趋势</th><th>阈值口径</th><th>设备型号</th><th></th></tr></thead>
  <tbody>${face.sensors.map((s) => {
    const meta = levelMeta(s.level);
    return `<tr class="row-click ${s.id === selected?.id ? 'selected-row' : ''}" data-sensor-row="${s.id}">
      <td><div class="cell-title"><span class="sensor-ico" style="color:${meta.color}">${sensorIcon(s.type, 12)}</span><div><div class="strong">${esc(s.name)}</div><div class="cell-sub">${s.id.split('-').slice(-1)}</div></div></div></td>
      <td class="muted">${esc(s.role)}</td>
      <td><b class="mono" style="font-size:13px;color:${meta.color}">${s.display}</b> <span class="text-dim">${esc(s.unit)}</span></td>
      <td>${levelTag(s.level)}</td>
      <td>${trendIcon(s.trend)}</td>
      <td class="muted nowrap">${esc(s.thresholdText)}</td>
      <td class="mono muted">${esc(s.model)}</td>
      <td class="text-dim">›</td>
    </tr>`;
  }).join('')}</tbody>`;
}

function sensorPanelHTML(face, s) {
  const meta = levelMeta(s.level);
  const max = typeGaugeMax(s.type);
  return `<div class="sensor-detail-head">
      <div><h3>${sensorIcon(s.type, 14)} ${esc(s.name)}</h3><p>${esc(s.role)} · ${esc(s.model)}</p></div>
      ${levelTag(s.level)}
    </div>
    <div class="sensor-gauge"><canvas id="sensor-gauge"></canvas></div>
    <div class="sensor-threshold" style="background:${meta.soft};border-color:${meta.color}33">${icon('alert', 11)}<span style="color:${meta.color}">${esc(s.thresholdText)} · 当前 ${s.display}${esc(s.unit)}</span></div>
    <div class="kv-grid">
      <div class="kv"><span>量程</span><b>${esc(SENSOR_META(s.type).range)}</b></div>
      <div class="kv"><span>精度</span><b>${esc(SENSOR_META(s.type).precision)}</b></div>
      <div class="kv"><span>通信</span><b>RS485 / 在线</b></div>
      <div class="kv"><span>标校日期</span><b>2026-10-18</b></div>
      <div class="kv"><span>安装位置</span><b class="txt">${esc(s.role)}</b></div>
      <div class="kv"><span>分站端口</span><b>CH-${String(s.order).padStart(2, '0')}</b></div>
    </div>
    <div class="sensor-mini-chart"><canvas id="sensor-mini"></canvas></div>
    <div class="sensor-actions">
      <button class="btn btn-sm" data-sensor-history="${s.id}">${icon('history', 12)} 历史曲线</button>
      <button class="btn btn-sm" data-sensor-check="${s.id}">${icon('wrench', 12)} 校准记录</button>
    </div>`;
}

function SENSOR_META(type) {
  return App.bootstrap?.sensorTypes?.[type] || {};
}

function typeGaugeMax(type) {
  return { ch4: 1.6, ch4b: 1.6, co: 60, o2: 25, temp: 45, humidity: 100, dust: 50, wind: 6 }[type] || 100;
}

function drawFaceCharts(face, sensor) {
  const gauge = $('#sensor-gauge');
  const mini = $('#sensor-mini');
  if (gauge) {
    const meta = levelMeta(sensor.level);
    Charts.gauge(gauge, {
      value: sensor.value,
      min: 0,
      max: typeGaugeMax(sensor.type),
      color: meta.color,
      text: sensor.display,
      unit: sensor.unit,
      caption: `等级：${meta.label}`
    });
  }
  if (mini) {
    const meta = levelMeta(sensor.level);
    Charts.line(mini, {
      series: [{ name: sensor.name, color: meta.color, values: sensor.history || [], fill: true }],
      labels: (sensor.history || []).map((_, i) => `${(sensor.history.length - i) * 2}s`),
      thresholds: sensor.threshold?.warning !== undefined ? [{ value: sensor.threshold.warning, color: '#ff5f6d', label: '' }] : []
    });
  }
}

function updateFaceLive() {
  if (!App.state || App.route.name !== 'face') return;
  const face = findFace(App.selectedFaceId);
  if (!face) return;
  const sensor = face.sensors.find((s) => s.id === App.sensorByFace[face.id]) || face.sensors[0];
  App.sensorByFace[face.id] = sensor.id;

  const status = $('#face-status');
  if (status) status.innerHTML = levelTag(face.level, face.activeAlarms ? `${face.levelLabel} · ${face.activeAlarms} 起` : '安全运行');
  const canvas = $('#face-canvas');
  if (canvas) canvas.innerHTML = faceCanvasHTML(face, sensor).replace(/^<svg/, '<svg');
  const equipment = $('#equipment-strip');
  if (equipment) equipment.innerHTML = equipmentStripHTML(face);
  const table = $('#face-sensor-table');
  if (table) table.innerHTML = sensorTableHTML(face, sensor);
  const tree = $('#face-tree');
  if (tree) tree.innerHTML = faceTreeHTML();
  const panel = $('#sensor-panel-inner');
  if (panel) panel.innerHTML = sensorPanelHTML(face, sensor);
  drawFaceCharts(face, sensor);
}

/* ============================================================
   告警中心
   ============================================================ */
function renderAlarmsPage() {
  const view = $('#view');
  const open = App.alarms.filter((a) => a.status !== 'resolved');
  view.innerHTML = `<div class="page">
    <div class="page-head">
      <div>
        <div class="eyebrow">ALARM &amp; RESPONSE CENTER</div>
        <h1 class="page-title">告警<span class="accent">处置中心</span></h1>
        <p class="page-sub">告警全生命周期管理 · 自动联动 · 人工复核 · 闭环归档</p>
      </div>
      <div class="head-actions">
        <button class="btn btn-sm" id="refresh-alarms">${icon('refresh', 13)} 刷新</button>
        <a class="btn btn-sm" href="/api/export/alarms.csv">${icon('download', 13)} 导出 CSV</a>
        <button class="btn btn-sm btn-primary" id="alarm-drill">${icon('play', 13)} 演练验证</button>
      </div>
    </div>
    <div class="alarm-kpis" id="alarm-kpis">${alarmKpisHTML(open)}</div>
    <div class="filter-bar">
      <div class="filter-field"><span>处置状态</span>
        <select class="select" id="alarm-status-filter">
          <option value="open" ${App.alarmFilters.status === 'open' ? 'selected' : ''}>待处置 / 复核中</option>
          <option value="all" ${App.alarmFilters.status === 'all' ? 'selected' : ''}>全部事件</option>
          <option value="resolved" ${App.alarmFilters.status === 'resolved' ? 'selected' : ''}>已闭环</option>
        </select>
      </div>
      <div class="filter-field"><span>告警等级</span>
        <select class="select" id="alarm-level-filter">
          <option value="all">全部等级</option>
          <option value="critical" ${App.alarmFilters.level === 'critical' ? 'selected' : ''}>严重告警</option>
          <option value="alarm" ${App.alarmFilters.level === 'alarm' ? 'selected' : ''}>告警</option>
          <option value="warning" ${App.alarmFilters.level === 'warning' ? 'selected' : ''}>预警</option>
        </select>
      </div>
      <div class="filter-field"><span>所属矿井</span>
        <select class="select" id="alarm-mine-filter">
          <option value="all">全集团</option>
          ${App.bootstrap.mines.map((m) => `<option value="${m.id}" ${App.alarmFilters.mineId === m.id ? 'selected' : ''}>${esc(m.name)}</option>`).join('')}
        </select>
      </div>
      <div class="filter-field"><span>关键词</span><input class="input" id="alarm-query" placeholder="工作面 / 测点 / 原因" value="${esc(App.alarmFilters.query)}"/></div>
      <div class="filter-spacer"></div>
      <div class="seg" id="alarm-quick">
        <button class="${App.alarmFilters.status === 'open' ? 'active' : ''}" data-alarm-quick="open">待处置</button>
        <button class="${App.alarmFilters.status === 'all' ? 'active' : ''}" data-alarm-quick="all">全部</button>
        <button class="${App.alarmFilters.status === 'resolved' ? 'active' : ''}" data-alarm-quick="resolved">已闭环</button>
      </div>
    </div>
    <section class="panel">
      <div class="panel-head" style="padding-bottom:9px">
        <div><div class="panel-title">${icon('alarm')} 告警事件列表</div><div class="panel-sub" id="alarm-list-sub">按时间倒序 · 共 ${filteredAlarms().length} 条事件</div></div>
        <div class="panel-actions"><span class="status-pill"><i></i>规则引擎 R-ENV-01 运行中</span></div>
      </div>
      <div class="panel-body" style="padding-top:0">
        <div class="table-wrap"><table class="data-table alarm-table">
          <thead><tr><th>等级</th><th>发生时间</th><th>矿井 / 工作面</th><th>测点</th><th>实时值</th><th>研判原因</th><th>处置状态</th><th>操作</th></tr></thead>
          <tbody id="alarm-table-body">${alarmTableRows()}</tbody>
        </table></div>
      </div>
    </section>
    <div class="dash-grid c-3" style="margin-top:11px">
      <section class="panel">
        <div class="panel-head"><div><div class="panel-title">${icon('history')} 告警时段分布</div><div class="panel-sub">近 24 小时 · 两小时聚合</div></div></div>
        <div class="panel-body"><div class="chart-wrap h-160"><canvas id="alarm-trend"></canvas></div></div>
      </section>
      <section class="panel">
        <div class="panel-head"><div><div class="panel-title">${icon('gauge')} 处置效能</div><div class="panel-sub">本月滚动均值</div></div></div>
        <div class="panel-body">${efficiencyHTML()}</div>
      </section>
      <section class="panel">
        <div class="panel-head"><div><div class="panel-title">${icon('zap')} 自动联动策略</div><div class="panel-sub">规则命中后自动执行 · 支持人工接管</div></div></div>
        <div class="panel-body">${strategyHTML()}</div>
      </section>
    </div>
  </div>`;
  drawAlarmInsights();
}

function alarmKpisHTML(open) {
  const critical = open.filter((a) => a.level === 'critical').length;
  const unack = open.filter((a) => !a.acknowledged).length;
  const resolved = App.alarms.filter((a) => a.status === 'resolved').length;
  return `
    <div class="alarm-kpi"><span class="a-ico" style="--bgc:rgba(255,95,109,.12);--fgc:#ff7a85">${icon('alarm', 15)}</span><div><b>${open.length}</b><span>未闭环事件</span></div></div>
    <div class="alarm-kpi"><span class="a-ico" style="--bgc:rgba(255,95,109,.08);--fgc:#ff5f6d">${icon('alert', 15)}</span><div><b>${critical}</b><span>严重告警</span></div></div>
    <div class="alarm-kpi"><span class="a-ico" style="--bgc:rgba(255,181,71,.1);--fgc:#ffb547">${icon('clock', 15)}</span><div><b>${unack}</b><span>待确认</span></div></div>
    <div class="alarm-kpi"><span class="a-ico" style="--bgc:rgba(53,224,192,.1);--fgc:#35e0c0">${icon('shield', 15)}</span><div><b>${resolved}</b><span>已闭环归档</span></div></div>`;
}

function filteredAlarms() {
  const f = App.alarmFilters;
  return App.alarms.filter((a) => {
    if (f.status === 'open' && a.status === 'resolved') return false;
    if (f.status === 'resolved' && a.status !== 'resolved') return false;
    if (f.level !== 'all' && a.level !== f.level) return false;
    if (f.mineId !== 'all' && a.mineId !== f.mineId) return false;
    if (f.query) {
      const q = f.query.trim().toLowerCase();
      const text = `${a.mineName} ${a.faceName} ${a.sensorName} ${a.cause} ${a.id}`.toLowerCase();
      if (!text.includes(q)) return false;
    }
    return true;
  });
}

function alarmTableRows() {
  const items = filteredAlarms();
  if (!items.length) return `<tr><td colspan="8"><div class="empty">${icon('shield', 26)}<span>暂无符合条件的告警事件</span></div></td></tr>`;
  return items.map((a) => {
    const meta = levelMeta(a.level);
    const status = a.status === 'resolved' ? { text: '已闭环', color: '#35e0c0' } : a.acknowledged ? { text: '复核中', color: '#4f8dff' } : { text: '待处置', color: '#ffb547' };
    return `<tr class="row-click" data-alarm-open="${a.id}">
      <td>${levelTag(a.level)}</td>
      <td><div class="mono" style="font-size:10px">${clock(a.time)}</div><div class="cell-sub">${esc(timeAgo(a.time))}</div></td>
      <td><div class="strong">${esc(a.mineName)}</div><div class="cell-sub">${esc(a.faceName)}</div></td>
      <td><div class="cell-title"><span class="sensor-ico" style="color:${meta.color}">${sensorIcon(a.type, 12)}</span><div><div>${esc(a.sensorName)}</div><div class="cell-sub">${esc(a.id)}</div></div></div></td>
      <td><b class="mono" style="color:${meta.color};font-size:12px">${a.value}</b> <span class="text-dim">${esc(a.unit)}</span></td>
      <td><div style="max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(a.cause)}">${esc(a.cause)}</div></td>
      <td><span class="status-tag" style="--s:${status.color}"><i></i>${status.text}</span></td>
      <td><button class="btn btn-sm btn-ghost" data-alarm-open="${a.id}">查看 ${icon('right', 11)}</button></td>
    </tr>`;
  }).join('');
}

function renderAlarmTable() {
  const body = $('#alarm-table-body');
  if (!body) return;
  body.innerHTML = alarmTableRows();
  const sub = $('#alarm-list-sub');
  if (sub) sub.textContent = `按时间倒序 · 共 ${filteredAlarms().length} 条事件`;
}

function updateAlarmKpis() {
  const open = App.alarms.filter((a) => a.status !== 'resolved');
  const wrap = $('#alarm-kpis');
  if (wrap) wrap.innerHTML = alarmKpisHTML(open);
  drawAlarmInsights();
}

function efficiencyHTML() {
  const items = [
    { label: '平均确认时长', value: '42', unit: '秒', pct: 88 },
    { label: '平均闭环时长', value: '18', unit: '分钟', pct: 74 },
    { label: '自动联动成功率', value: '96.4', unit: '%', pct: 96 },
    { label: '超时未处置', value: '0', unit: '起', pct: 100 }
  ];
  return `<div class="eff-list">${items.map((i) => `<div class="eff-row">
    <div class="eff-label"><span>${i.label}</span><b>${i.value}<small>${i.unit}</small></b></div>
    <div class="eff-bar"><i style="width:${i.pct}%"></i></div>
  </div>`).join('')}</div>`;
}

function strategyHTML() {
  const items = [
    { cond: 'CH₄ ≥ 1.0%', act: '声光报警 + 断电 + 局扇强排', color: '#ff5f6d' },
    { cond: 'CO ≥ 24 ppm', act: '喷雾降尘 + 视频复核 + 防灭火工单', color: '#ff7a59' },
    { cond: '风速 < 0.25 m/s', act: '备用风机切换 + 停止掘进 + 撤人', color: '#ffb547' },
    { cond: '粉尘 ≥ 10 mg/m³', act: '转载点喷雾 + 降速割煤', color: '#4f8dff' }
  ];
  return `<div class="strategy-list">${items.map((i) => `<div class="strategy-row">
    <span class="strategy-dot" style="--c:${i.color}"></span>
    <div><b>${i.cond}</b><span>${i.act}</span></div>
    <em>自动</em>
  </div>`).join('')}</div>`;
}

function drawAlarmInsights() {
  const canvas = $('#alarm-trend');
  if (!canvas) return;
  const bins = alarmBins();
  Charts.bar(canvas, { data: bins.map((b) => ({ label: b.label, value: b.value, color: b.current ? '#ff7a59' : '#4f8dff' })) });
}

async function refreshAlarms(silent = true) {
  const data = await api('/api/alarms?status=all&limit=100');
  App.alarms = data.items || [];
  App.knownAlarmIds = new Set(App.alarms.filter((a) => a.status !== 'resolved').map((a) => a.id));
  updateGlobalChrome();
  if (App.route.name === 'alarms') {
    updateAlarmKpis();
    renderAlarmTable();
  }
  if (App.route.name === 'overview') updateOverview();
  if (!silent) toast('告警数据已刷新', '已从平台同步最新事件状态', 'success');
}

async function openAlarmDrawer(id) {
  let alarm;
  try {
    alarm = await api(`/api/alarms/${encodeURIComponent(id)}`);
  } catch (error) {
    toast('无法读取告警详情', error.message, 'error');
    return;
  }
  const meta = levelMeta(alarm.level);
  const resolved = alarm.status === 'resolved';
  const root = $('#drawer-root');
  root.innerHTML = `<div class="drawer-backdrop" data-close-drawer></div>
    <aside class="drawer" id="alarm-drawer">
      <div class="drawer-head">
        <div>
          <div class="eyebrow" style="margin-bottom:4px">ALARM ${esc(alarm.id)}</div>
          <h3>${esc(alarm.sensorName)} ${alarm.value}${esc(alarm.unit)}</h3>
          <p>${esc(alarm.mineName)} · ${esc(alarm.faceName)} · ${dateTime(alarm.time)}</p>
        </div>
        <button class="icon-btn" data-close-drawer aria-label="关闭">${icon('close', 15)}</button>
      </div>
      <div class="drawer-body">
        <div class="detail-block">
          <div class="detail-grid">
            <div class="detail-cell"><span>告警等级</span><b>${levelTag(alarm.level)}</b></div>
            <div class="detail-cell"><span>处置状态</span><b>${resolved ? '已闭环' : alarm.acknowledged ? '复核中' : '待处置'}</b></div>
            <div class="detail-cell"><span>测点编号</span><b class="num">${esc(alarm.sensorId)}</b></div>
            <div class="detail-cell"><span>传感器型号</span><b>${esc(SENSOR_META(alarm.type).model || '--')}</b></div>
            <div class="detail-cell"><span>告警阈值</span><b>${esc(sensorThresholdText(alarm.type))}</b></div>
            <div class="detail-cell"><span>持续时长</span><b class="num">${resolved ? Math.max(1, Math.round((new Date(alarm.resolvedAt) - new Date(alarm.time)) / 60000)) : Math.max(1, Math.round((Date.now() - new Date(alarm.time)) / 60000))} 分钟</b></div>
          </div>
        </div>
        <div class="detail-block">
          <h4>研判原因</h4>
          <p style="font-size:10px;color:var(--muted);line-height:1.7">${esc(alarm.cause)}。系统已自动关联本工作面历史趋势与相邻测点数据，建议调度员结合视频复核确认现场情况。</p>
        </div>
        <div class="detail-block">
          <h4>处置时间线</h4>
          <div class="timeline">${(alarm.timeline || []).map((t) => `<div class="timeline-item" style="--tl:${meta.color}"><time>${clock(t.time)}</time><p>${esc(t.text)}</p></div>`).join('')}</div>
        </div>
        <div class="detail-block">
          <h4>自动联动执行</h4>
          <div class="action-list">${(alarm.actions || []).map((a) => `<div class="action-row ${a.status === 'done' ? '' : 'running'}"><span class="a-check">${icon(a.status === 'done' ? 'check' : 'refresh', 9)}</span><span>${esc(a.label)}</span><time>${a.time ? clock(a.time) : '执行中'}</time></div>`).join('')}</div>
        </div>
        <div class="detail-block">
          <h4>视频复核证据</h4>
          <div class="evidence">
            <div class="evidence-placeholder">${icon('video', 17)}<span style="font-size:8px">抓拍帧 01</span></div>
            <div class="evidence-placeholder">${icon('video', 17)}<span style="font-size:8px">抓拍帧 02</span></div>
            <div class="evidence-placeholder">${icon('video', 17)}<span style="font-size:8px">抓拍帧 03</span></div>
          </div>
        </div>
      </div>
      <div class="drawer-foot">
        ${resolved ? '<button class="btn" data-close-drawer>关闭</button>' : `<button class="btn" data-alarm-ack="${alarm.id}" ${alarm.acknowledged ? 'disabled' : ''}>${icon('check', 13)} ${alarm.acknowledged ? '已确认' : '确认并复核'}</button><button class="btn btn-primary" data-alarm-resolve="${alarm.id}">${icon('shield', 13)} 确认闭环</button>`}
      </div>
    </aside>`;
  requestAnimationFrame(() => {
    $('.drawer-backdrop', root).classList.add('show');
    $('#alarm-drawer', root).classList.add('show');
  });
}

function closeDrawer(force = false) {
  const root = $('#drawer-root');
  if (!root) return;
  const drawer = $('#alarm-drawer', root);
  const backdrop = $('.drawer-backdrop', root);
  if (!drawer) return;
  if (force) { root.innerHTML = ''; return; }
  drawer.classList.remove('show');
  backdrop.classList.remove('show');
  setTimeout(() => { if (!drawer.classList.contains('show')) root.innerHTML = ''; }, 280);
}

async function ackAlarm(id) {
  try {
    await post(`/api/alarms/${encodeURIComponent(id)}/ack`, { operator: '集团调度中心 · 值班员' });
    toast('告警已确认', '已通知现场人员复核，事件进入复核中状态', 'success');
    closeDrawer();
    await refreshAlarms(false);
  } catch (error) {
    toast('确认失败', error.message, 'error');
  }
}

async function resolveAlarm(id) {
  try {
    await post(`/api/alarms/${encodeURIComponent(id)}/resolve`, { operator: '集团调度中心 · 值班员' });
    toast('事件已闭环', '现场确认恢复正常，联动设备已复位归档', 'success');
    closeDrawer();
    await refreshAlarms(false);
  } catch (error) {
    toast('闭环失败', error.message, 'error');
  }
}

function sensorThresholdText(type) {
  const t = App.bootstrap?.sensorTypes?.[type];
  if (!t) return '--';
  if (t.direction === 'low') return `≤${t.warning}${t.unit} 预警 / ≤${t.alarm}${t.unit} 告警`;
  if (t.direction === 'range') return `${t.warningLow}~${t.warningHigh}${t.unit}`;
  return `≥${t.warning}${t.unit} 预警 / ≥${t.alarm}${t.unit} 告警`;
}

/* ============================================================
   历史数据
   ============================================================ */
function defaultHistoryFilters() {
  const mine = App.bootstrap?.mines?.[0] || { id: 'QL', faces: [{ id: 'QL-1301', name: '1301 综采工作面' }] };
  const face = mine.faces?.[0] || { id: 'QL-1301', name: '1301 综采工作面' };
  return { mineId: mine.id, faceId: face.id, sensorId: `${face.id}-CH4-01`, quick: '24h', from: nowLocalInput(-24), to: nowLocalInput(0) };
}

function renderHistoryPage() {
  if (!App.historyFilters) App.historyFilters = defaultHistoryFilters();
  const view = $('#view');
  view.innerHTML = `<div class="page">
    <div class="page-head">
      <div>
        <div class="eyebrow">TIME-SERIES EXPLORER</div>
        <h1 class="page-title">历史数据<span class="accent">分析</span></h1>
        <p class="page-sub">分钟级时序数据回溯 · 阈值超限统计 · 异常事件关联 · CSV 导出</p>
      </div>
      <div class="head-actions">
        <button class="btn btn-sm" id="history-export">${icon('download', 13)} 导出当前结果</button>
        <button class="btn btn-sm btn-primary" id="history-query">${icon('search', 13)} 执行查询</button>
      </div>
    </div>
    <div id="history-filter">${historyFilterHTML()}</div>
    <div id="history-content">${historySkeletonHTML()}</div>
  </div>`;
  loadHistory();
}

function historyFilterHTML() {
  const f = App.historyFilters;
  const mine = App.bootstrap.mines.find((m) => m.id === f.mineId) || App.bootstrap.mines[0];
  const face = mine.faces.find((x) => x.id === f.faceId) || mine.faces[0];
  const faces = App.state.mines.find((m) => m.id === mine.id)?.faces || [];
  const sensors = faces.find((x) => x.id === face.id)?.sensors || [];
  return `<div class="filter-bar">
    <div class="filter-field"><span>矿井</span><select class="select" id="history-mine">${App.bootstrap.mines.map((m) => `<option value="${m.id}" ${m.id === mine.id ? 'selected' : ''}>${esc(m.name)}</option>`).join('')}</select></div>
    <div class="filter-field"><span>工作面</span><select class="select" id="history-face">${faces.map((x) => `<option value="${x.id}" ${x.id === face.id ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select></div>
    <div class="filter-field"><span>测点</span><select class="select" id="history-sensor">${sensors.map((s) => `<option value="${s.id}" ${s.id === f.sensorId ? 'selected' : ''}>${esc(s.name)} · ${esc(s.unit)}</option>`).join('')}</select></div>
    <div class="filter-field"><span>起始时间</span><input class="input" type="datetime-local" id="history-from" value="${esc(f.from)}"/></div>
    <div class="filter-field"><span>结束时间</span><input class="input" type="datetime-local" id="history-to" value="${esc(f.to)}"/></div>
    <div class="filter-spacer"></div>
    <div class="seg" id="history-quick">
      <button class="${f.quick === '1h' ? 'active' : ''}" data-range="1h">1 小时</button>
      <button class="${f.quick === '8h' ? 'active' : ''}" data-range="8h">8 小时</button>
      <button class="${f.quick === '24h' ? 'active' : ''}" data-range="24h">24 小时</button>
      <button class="${f.quick === '7d' ? 'active' : ''}" data-range="7d">7 天</button>
    </div>
  </div>`;
}

function historySkeletonHTML() {
  return `<div class="history-stats">
    ${['最小值', '最大值', '平均值', '超限样本'].map((x) => `<div class="stat-box"><span>${x}</span><b>--</b></div>`).join('')}
  </div>
  <div class="history-layout">
    <div class="history-main"><section class="panel"><div class="panel-head"><div><div class="panel-title">${icon('activity')} 测点趋势曲线</div><div class="panel-sub">正在加载时序数据…</div></div></div><div class="panel-body"><div class="chart-wrap h-240"><canvas id="history-chart"></canvas></div></div></section></div>
    <div class="history-side"><section class="panel"><div class="panel-head"><div><div class="panel-title">${icon('file')} 数据摘要</div></div></div><div class="panel-body"><div class="empty">${icon('database', 24)}<span>查询后显示统计信息</span></div></div></section></div>
  </div>`;
}

async function loadHistory() {
  if (App.historyLoading) return;
  const f = App.historyFilters;
  if (!f) return;
  App.historyLoading = true;
  const content = $('#history-content');
  if (content) {
    const sub = $('.panel-sub', content);
    if (sub) sub.textContent = '正在从时序库读取数据…';
  }
  try {
    const params = new URLSearchParams({ faceId: f.faceId, sensorId: f.sensorId, from: new Date(f.from).toISOString(), to: new Date(f.to).toISOString() });
    const data = await api(`/api/history?${params}`);
    App.historyCache = data;
    renderHistoryResult(data);
  } catch (error) {
    if (content) content.innerHTML = `<div class="panel"><div class="empty">${icon('alert', 24)}<span>查询失败：${esc(error.message)}</span></div></div>`;
  } finally {
    App.historyLoading = false;
  }
}

function renderHistoryResult(data) {
  const series = data.series?.[0];
  const content = $('#history-content');
  if (!content) return;
  if (!series) {
    content.innerHTML = `<div class="panel"><div class="empty">${icon('search', 24)}<span>该时间范围内没有数据</span></div></div>`;
    return;
  }
  const points = series.points || [];
  const labels = points.map((p) => shortDate(p.t));
  const dec = series.decimals ?? 1;
  const values = points.map((p) => p.v);
  const f = App.historyFilters;
  const rangeText = `${f.from.replace('T', ' ')} 至 ${f.to.replace('T', ' ')}`;
  const alarms = App.alarms.filter((a) => a.sensorId === series.sensorId).slice(0, 5);
  content.innerHTML = `<div class="history-stats">
    <div class="stat-box"><span>最小值</span><b style="color:#35e0c0">${fmt(series.stats.min, dec)}<small>${esc(series.unit)}</small></b></div>
    <div class="stat-box"><span>最大值</span><b style="color:#ff7a59">${fmt(series.stats.max, dec)}<small>${esc(series.unit)}</small></b></div>
    <div class="stat-box"><span>平均值</span><b>${fmt(series.stats.avg, dec)}<small>${esc(series.unit)}</small></b></div>
    <div class="stat-box"><span>超限样本</span><b style="color:${series.stats.exceed ? '#ffb547' : '#35e0c0'}">${series.stats.exceed}<small>/${series.stats.count}</small></b></div>
  </div>
  <div class="history-layout">
    <div class="history-main">
      <section class="panel">
        <div class="panel-head">
          <div><div class="panel-title">${icon('activity')} ${esc(series.name)} · 时序曲线</div><div class="panel-sub">${esc(rangeText)} · ${series.stats.count} 个采样点 · 自动抽稀至 ${points.length} 点</div></div>
          <div class="panel-actions"><span class="tag tag-normal"><i class="tag-dot"></i>${esc(series.unit)}</span></div>
        </div>
        <div class="panel-body"><div class="chart-wrap h-240"><canvas id="history-chart"></canvas></div></div>
      </section>
      <section class="panel" style="margin-top:11px">
        <div class="panel-head"><div><div class="panel-title">${icon('database')} 样本明细</div><div class="panel-sub">按时间倒序展示最近 12 个采样点</div></div></div>
        <div class="panel-body" style="padding-top:8px">
          <div class="table-wrap"><table class="data-table mini-table">
            <thead><tr><th>采样时间</th><th>数值</th><th>状态</th><th>较前值</th></tr></thead>
            <tbody>${historyTableRows(points.slice(-12).reverse(), series)}</tbody>
          </table></div>
        </div>
      </section>
    </div>
    <div class="history-side">
      <section class="panel">
        <div class="panel-head"><div><div class="panel-title">${icon('target')} 数据质量</div><div class="panel-sub">采集链路完整性评估</div></div></div>
        <div class="panel-body">
          <div class="metric-grid" style="grid-template-columns:1fr 1fr">
            <div class="metric-cell"><span>样本数量</span><b>${series.stats.count}</b></div>
            <div class="metric-cell"><span>采样间隔</span><b>${series.stats.count > 2 ? Math.max(1, Math.round((new Date(points.at(-1).t) - new Date(points[0].t)) / 60000 / (points.length - 1))) : 0}<small>min</small></b></div>
            <div class="metric-cell"><span>数据完整率</span><b>99.8<small>%</small></b></div>
            <div class="metric-cell"><span>异常标记</span><b>${series.stats.exceed}</b></div>
          </div>
        </div>
      </section>
      <section class="panel">
        <div class="panel-head"><div><div class="panel-title">${icon('alarm')} 关联告警</div><div class="panel-sub">该测点近期事件</div></div></div>
        <div class="panel-body" style="padding-top:6px">
          ${alarms.length ? alarms.map((a) => `<div class="alarm-item" data-alarm-open="${a.id}" style="--lv:${levelMeta(a.level).color};grid-template-columns:3px 1fr auto">
            <div class="alarm-level-bar"></div><div class="alarm-main"><div class="alarm-line1"><b>${esc(a.sensorName)}</b>${levelTag(a.level)}</div><div class="alarm-line2">${esc(a.cause)}</div></div><div class="alarm-val"><b>${a.value}<small>${esc(a.unit)}</small></b><span>${clock(a.time)}</span></div>
          </div>`).join('') : `<div class="empty" style="padding:20px">${icon('check', 22)}<span>该测点近期无告警</span></div>`}
        </div>
      </section>
      <section class="panel">
        <div class="panel-head"><div><div class="panel-title">${icon('file')} 导出说明</div></div></div>
        <div class="panel-body"><p style="font-size:9px;color:var(--dim);line-height:1.8">导出内容包含采样时间、测点编号、数值、单位与阈值判定结果，编码为 UTF-8 with BOM，可直接在 Excel 中打开。</p></div>
      </section>
    </div>
  </div>`;
  const canvas = $('#history-chart');
  if (canvas) {
    const thresholds = [];
    const type = SENSOR_META(series.type);
    if (type.direction === 'up') {
      thresholds.push({ value: type.warning, color: '#ffb547', label: `预警 ${type.warning}${type.unit}` });
      thresholds.push({ value: type.alarm, color: '#ff5f6d', label: `告警 ${type.alarm}${type.unit}` });
    } else if (type.direction === 'low') {
      thresholds.push({ value: type.warning, color: '#ffb547', label: `预警 ${type.warning}${type.unit}` });
    }
    Charts.line(canvas, {
      series: [{ name: series.name, color: type.direction === 'low' ? '#4f8dff' : '#35e0c0', values, fill: true }],
      labels,
      thresholds
    });
  }
}

function historyTableRows(points, series) {
  return points.map((p, i) => {
    const prev = points[i + 1]?.v;
    const diff = prev !== undefined ? p.v - prev : 0;
    return `<tr><td class="mono">${shortDate(p.t)}</td><td><b class="mono">${fmt(p.v, series.decimals ?? 1)}</b> <span class="text-dim">${esc(series.unit)}</span></td><td>${levelTag(valueLevel(series.type, p.v))}</td><td class="mono ${diff > 0 ? 'text-amber' : diff < 0 ? 'text-teal' : 'text-dim'}">${diff > 0 ? '+' : ''}${fmt(diff, series.decimals ?? 1)}</td></tr>`;
  }).join('');
}

function valueLevel(type, value) {
  const t = SENSOR_META(type);
  if (!t || !Number.isFinite(Number(value))) return 'normal';
  if (t.direction === 'low') {
    if (value <= t.critical) return 'critical';
    if (value <= t.alarm) return 'alarm';
    if (value <= t.warning) return 'warning';
    return 'normal';
  }
  if (t.direction === 'range') {
    if (value <= t.alarmLow || value >= t.criticalHigh) return 'critical';
    if (value < t.warningLow || value >= t.warningHigh) return 'alarm';
    return 'normal';
  }
  if (value >= t.critical) return 'critical';
  if (value >= t.alarm) return 'alarm';
  if (value >= t.warning) return 'warning';
  return 'normal';
}

function exportHistory() {
  const series = App.historyCache?.series?.[0];
  if (!series) { toast('暂无可导出数据', '请先执行查询', 'warn'); return; }
  const rows = [
    ['采样时间', '矿井', '工作面', '测点编号', '测点名称', '数值', '单位'],
    ...(series.points || []).map((p) => {
      const face = findFace(series.faceId);
      return [dateTime(p.t), face?.mineName || '', face?.name || '', series.sensorId, series.name, p.v, series.unit];
    })
  ];
  download(`history-${series.sensorId}-${Date.now()}.csv`, toCsv(rows), 'text/csv;charset=utf-8');
  toast('导出完成', '历史数据 CSV 已生成，可直接使用 Excel 打开', 'success');
}

function applyHistoryRange(range) {
  const f = App.historyFilters;
  f.quick = range;
  const hours = { '1h': 1, '8h': 8, '24h': 24, '7d': 24 * 7 }[range] || 24;
  f.from = nowLocalInput(-hours);
  f.to = nowLocalInput(0);
  App.historyFilters = f;
  $('#history-filter').innerHTML = historyFilterHTML();
  loadHistory();
}

/* ============================================================
   链路拓扑
   ============================================================ */
function renderTopology() {
  const link = App.state.link;
  const score = topologyScore(link);
  const view = $('#view');
  view.innerHTML = `<div class="page">
    <div class="page-head">
      <div>
        <div class="eyebrow">END-EDGE-NETWORK-CLOUD-APP</div>
        <h1 class="page-title">应用<span class="accent">拓扑</span>与链路健康</h1>
        <p class="page-sub">感知层 → 分站层 → 环网层 → 平台层 → 应用层 · 全链路冗余与实时遥测</p>
      </div>
      <div class="head-actions">
        <a class="btn btn-sm" href="/downloads/application-topology.drawio" download>${icon('download', 13)} 下载拓扑工程文件</a>
        <button class="btn btn-sm btn-primary" id="topo-check">${icon('refresh', 13)} 链路自检</button>
      </div>
    </div>

    <section class="topo-hero">
      <div>
        <h2>三矿一中心 · 双环冗余工业环网</h2>
        <p>每座矿井部署 3 台矿用本安分站和 3 台隔爆环网交换机，传感器以 RS485 接入分站，经光纤环网上联至地面平台。任一分站或单段光缆故障时，环网 50ms 内自愈，监测数据不中断。</p>
        <div class="hero-badges">
          <span class="hero-badge">${icon('shield', 11)} 等保三级</span>
          <span class="hero-badge">${icon('signal', 11)} 环网自愈 &lt;50ms</span>
          <span class="hero-badge">${icon('database', 11)} 断网本地缓存 ≥4h</span>
          <span class="hero-badge">${icon('lock', 11)} 生产网 / 管理网隔离</span>
        </div>
      </div>
      <div class="topo-score">
        <div class="score-ring" id="topo-score">
          <svg viewBox="0 0 104 104"><circle cx="52" cy="52" r="45" fill="none" stroke="rgba(120,168,214,.12)" stroke-width="6"/><circle id="score-arc" cx="52" cy="52" r="45" fill="none" stroke="${score >= 90 ? '#35e0c0' : '#ffb547'}" stroke-width="6" stroke-linecap="round" stroke-dasharray="${score * 2.827} 282.7"/></svg>
          <div class="score-copy"><b>${score.toFixed(1)}</b><span>链路健康分</span></div>
        </div>
        <div class="score-side">
          <div class="score-item"><span>在线分站</span><b>9 / 9</b></div>
          <div class="score-item"><span>环网状态</span><b style="color:var(--teal)">双环正常</b></div>
          <div class="score-item"><span>最近自检</span><b id="topo-last">${clock(link.lastSync)}</b></div>
        </div>
      </div>
    </section>

    <section class="panel">
      <div class="panel-head">
        <div><div class="panel-title">${icon('topology')} 五层应用拓扑</div><div class="panel-sub">实线为生产数据链路 · 虚线为视频/管理链路 · 节点状态实时刷新</div></div>
        <div class="panel-actions"><span class="status-pill"><i></i>数据流正常</span></div>
      </div>
      <div class="panel-body">
        <div class="topo-canvas">
          <div class="topo-col">
            <div class="topo-col-title">01 / PERCEPTION</div>
            ${App.bootstrap.mines.map((m) => `<div class="topo-box perception"><b>${esc(m.shortName)} · 感知层</b><span>24 环境测点 · 6 视频</span><em>ONLINE</em></div>`).join('')}
          </div>
          <div class="topo-col">
            <div class="topo-col-title">02 / STATION</div>
            ${App.bootstrap.mines.map((m) => `<div class="topo-box edge"><b>${esc(m.shortName)} 分站群</b><span>KJ90-F16 ×3 · RS485</span><em>9/9</em></div>`).join('')}
          </div>
          <div class="topo-col">
            <div class="topo-col-title">03 / RING</div>
            <div class="topo-box edge"><b>地面核心环网</b><span>KJJ127 千兆 · 双环</span><em>50ms</em></div>
            <div class="topo-box edge"><b>矿用隔爆交换机</b><span>4 光 8 电 · 自愈环</span><em>9 台</em></div>
            <div class="topo-box edge"><b>安全隔离网关</b><span>单向隔离 · 白名单</span><em>ACTIVE</em></div>
          </div>
          <div class="topo-col">
            <div class="topo-col-title">04 / PLATFORM</div>
            <div class="topo-box platform"><b>采集接入服务</b><span>SSE / REST · 2s 周期</span><em>1.9 Mbps</em></div>
            <div class="topo-box platform"><b>告警规则引擎</b><span>R-ENV-01 · 12 条规则</span><em>RUNNING</em></div>
            <div class="topo-box platform"><b>时序数据库</b><span>72 测点 · 保留 5 年</span><em>99.97%</em></div>
          </div>
          <div class="topo-col">
            <div class="topo-col-title">05 / APPLICATION</div>
            <div class="topo-box app"><b>集团调度中心</b><span>大屏 / 工作站</span><em>3 席</em></div>
            <div class="topo-box app"><b>矿调度室</b><span>双屏值守 · 电话联动</span><em>3 矿</em></div>
            <div class="topo-box app"><b>移动巡检端</b><span>告警推送 · 工单闭环</span><em>在线</em></div>
          </div>
        </div>
        <div class="metric-grid" id="topo-metrics">
          ${topoMetricsHTML()}
        </div>
      </div>
    </section>

    <div class="topo-bottom">
      <section class="panel">
        <div class="panel-head"><div><div class="panel-title">${icon('activity')} 链路指标</div><div class="panel-sub">最近一次采样周期</div></div></div>
        <div class="panel-body">
          <div class="chart-wrap h-160"><canvas id="topo-chart"></canvas></div>
          <div class="legend" style="margin-top:4px"><span class="legend-item"><i style="--c:#4f8dff"></i>链路时延 <b>ms</b></span><span class="legend-item"><i style="--c:#35e0c0"></i>丢包率 <b>×100</b></span></div>
        </div>
      </section>
      <section class="panel">
        <div class="panel-head"><div><div class="panel-title">${icon('radio')} 数据包实时日志</div><div class="panel-sub">采集 / 告警 / 联动事件流</div></div><span class="tag tag-normal"><i class="tag-dot"></i>LIVE</span></div>
        <div class="panel-body"><div class="packet-log" id="packet-log">${packetLogHTML()}</div></div>
      </section>
    </div>
  </div>`;
  drawTopoChart();
}

function topoMetricsHTML() {
  const link = App.state.link;
  return `
    <div class="metric-cell"><span>链路时延</span><b>${link.rtt}<small>ms</small></b></div>
    <div class="metric-cell"><span>丢包率</span><b>${link.loss}<small>%</small></b></div>
    <div class="metric-cell"><span>累计数据包</span><b>${compact(link.packets)}<small>包</small></b></div>
    <div class="metric-cell"><span>吞吐量</span><b>${link.throughput}<small>Mbps</small></b></div>`;
}

function topologyScore(link) {
  return Math.max(90, Math.min(100, 100 - link.loss * 120 - Math.max(0, link.rtt - 20) * 0.15));
}

function packetLogHTML() {
  const logs = [...(App.state.logs || [])];
  if (!logs.length) logs.push({ t: new Date().toISOString(), level: 'info', text: '链路自检完成，全部节点响应正常' });
  return logs.slice(0, 10).map((l) => {
    const color = l.level === 'critical' ? '#ff5f6d' : l.level === 'alarm' ? '#ff7a59' : l.level === 'warning' ? '#ffb547' : '#35e0c0';
    return `<div class="packet-row"><span class="packet-dot" style="--p:${color}"></span><time>${clock(l.t)}</time><span>${esc(l.text)}</span></div>`;
  }).join('');
}

function drawTopoChart() {
  const canvas = $('#topo-chart');
  if (!canvas) return;
  const link = App.state.link;
  const baseRtt = link.rtt;
  const rtt = Array.from({ length: 18 }, (_, i) => Math.max(12, baseRtt + Math.sin(i * 1.2) * 2 + (i % 3)));
  const loss = Array.from({ length: 18 }, (_, i) => Math.max(0.005, link.loss + Math.sin(i * 0.9) * 0.006));
  Charts.line(canvas, {
    series: [
      { name: 'RTT', color: '#4f8dff', values: rtt, fill: true },
      { name: 'LOSS×100', color: '#35e0c0', values: loss.map((v) => v * 100), fill: false }
    ],
    labels: rtt.map((_, i) => `-${(rtt.length - i) * 2}s`)
  });
}

function updateTopologyLive() {
  if (App.route.name !== 'topology' || !$('#topo-metrics')) return;
  const link = App.state.link;
  const score = topologyScore(link);
  $('#topo-metrics').innerHTML = topoMetricsHTML();
  const log = $('#packet-log');
  if (log) log.innerHTML = packetLogHTML();
  const arc = $('#score-arc');
  if (arc) arc.setAttribute('stroke-dasharray', `${score * 2.827} 282.7`);
  const scoreText = $('#topo-score b');
  if (scoreText) scoreText.textContent = score.toFixed(1);
  const last = $('#topo-last');
  if (last) last.textContent = clock(link.lastSync);
  drawTopoChart();
}

/* ============================================================
   设备台账
   ============================================================ */
function renderDevicesPage() {
  const view = $('#view');
  view.innerHTML = `<div class="page">
    <div class="page-head">
      <div>
        <div class="eyebrow">DEVICE SELECTION &amp; INVENTORY</div>
        <h1 class="page-title">设备<span class="accent">选型台账</span></h1>
        <p class="page-sub">4 层设备体系 · 感知 / 传输 / 执行 / 平台 · 选型依据与矿用适配参数</p>
      </div>
      <div class="head-actions">
        <a class="btn btn-sm" href="/downloads/device-selection.xlsx" download>${icon('download', 13)} 下载设备清单</a>
        <button class="btn btn-sm btn-primary" id="device-refresh">${icon('refresh', 13)} 同步台账</button>
      </div>
    </div>
    <div class="device-tabs" id="device-tabs">${deviceTabsHTML()}</div>
    <div class="device-summary" id="device-summary">${deviceSummaryHTML()}</div>
    <div class="device-grid" id="device-grid">${deviceGridHTML()}</div>
    <section class="panel" style="margin-top:11px">
      <div class="panel-head"><div><div class="panel-title">${icon('target')} 选型方法与校核维度</div><div class="panel-sub">从风险适配、矿用合规、全生命周期成本、安装约束四个维度闭环论证</div></div></div>
      <div class="panel-body">${deviceMethodologyHTML()}</div>
    </section>
  </div>`;
  if (!App.deviceGroups) loadDevices();
}

function deviceSummaryHTML() {
  const groups = App.deviceGroups || App.bootstrap.devices;
  const models = groups.reduce((s, g) => s + g.items.length, 0);
  const qty = groups.reduce((s, g) => s + g.items.reduce((a, i) => a + (i.unit === 'km' ? 0 : Number(i.qty) || 0), 0), 0);
  return `<div class="device-summary-item"><span>设备层级</span><b>4<small>层</small></b></div>
    <div class="device-summary-item"><span>设备型号</span><b>${models}<small>型</small></b></div>
    <div class="device-summary-item"><span>部署总量</span><b>${qty}<small>台/套</small></b></div>
    <div class="device-summary-item"><span>矿用认证覆盖</span><b class="teal">100<small>%</small></b></div>`;
}

function deviceMethodologyHTML() {
  const items = [
    { icon: 'target', title: '风险适配', text: '按低瓦斯、高瓦斯、易自燃三类矿井差异化配置；瓦斯重点区域双测点冗余，自燃矿井强化 CO 与温度监测。' },
    { icon: 'shield', title: '矿用合规', text: '全部井下设备满足 Ex ib I Mb / Ex d I Mb 防爆等级与 MA 矿用产品安全标志，入井前完成联检。' },
    { icon: 'battery', title: '全生命周期', text: '优先选择免标校周期长、备件通用、功耗低的设备；分站断电续航 ≥4h，降低运维与更换成本。' },
    { icon: 'wrench', title: '安装约束', text: '传感器采用标准 RS485 总线与快插接头，避开转载点强振动区；摄像仪与报警器布置在人员出入口。' }
  ];
  return `<div class="method-grid">${items.map((i) => `<div class="method-card">
    <div class="method-ico">${icon(i.icon, 15)}</div>
    <div><h4>${i.title}</h4><p>${i.text}</p></div>
  </div>`).join('')}</div>`;
}

function deviceTabsHTML() {
  const groups = App.deviceGroups || App.bootstrap.devices;
  return groups.map((g) => `<button class="device-tab ${g.category === App.deviceCategory ? 'active' : ''}" data-device-cat="${esc(g.category)}">${esc(g.category)} <span class="mono" style="color:var(--dim);margin-left:4px">${g.items.length}</span></button>`).join('');
}

function deviceGridHTML() {
  const groups = App.deviceGroups || App.bootstrap.devices;
  const group = groups.find((g) => g.category === App.deviceCategory) || groups[0];
  if (!group) return `<div class="empty">${icon('box', 24)}<span>暂无设备数据</span></div>`;
  return group.items.map((item) => `<article class="device-card">
    <div class="device-card-head">
      <div class="device-ico">${sensorIcon(item.key, 17)}</div>
      <div class="device-name"><h4>${esc(item.name)}</h4><span>${esc(item.model)}</span></div>
      <div class="device-qty">${item.qty}<small>${esc(item.unit)}</small></div>
    </div>
    <div class="device-params">
      <div class="device-param"><b>技术参数</b><span>${esc(item.params)}</span></div>
    </div>
    <div class="device-reason">${icon('check', 10)}<span>${esc(item.reason)}</span></div>
    <div class="device-status">
      <span class="status-pill"><i style="--s:#35e0c0"></i>${esc(item.status || '运行正常')}</span>
      <span class="tag tag-normal"><i class="tag-dot"></i>矿用本安/隔爆</span>
    </div>
  </article>`).join('');
}

async function loadDevices() {
  try {
    const data = await api('/api/devices');
    App.deviceGroups = data.groups;
    if ($('#device-tabs')) {
      $('#device-tabs').innerHTML = deviceTabsHTML();
      $('#device-summary').innerHTML = deviceSummaryHTML();
      $('#device-grid').innerHTML = deviceGridHTML();
    }
  } catch (error) {
    toast('设备台账读取失败', error.message, 'error');
  }
}

/* ============================================================
   情景演练
   ============================================================ */
function drillFaceLabel(faceId) {
  const face = allFaces().find((f) => f.id === faceId);
  return face ? `${face.mineName} · ${face.name}` : '未选择工作面';
}

function openDrillModal() {
  const scenarios = Object.values(App.bootstrap.scenarios).filter((s) => s.key !== 'normal');
  if (!allFaces().some((f) => f.id === App.drillDraft.faceId)) App.drillDraft.faceId = allFaces()[0]?.id;
  if (!scenarios.some((s) => s.key === App.drillDraft.type)) App.drillDraft.type = scenarios[0]?.key;
  const root = $('#modal-root');
  root.innerHTML = `<div class="modal-backdrop" data-close-modal></div>
    <div class="modal" id="drill-modal">
      <div class="modal-head">
        <div>
          <div class="eyebrow" style="margin-bottom:4px">SCENARIO REPLAY SANDBOX</div>
          <h2>${icon('target', 18)} 应急演练控制台</h2>
          <p>注入真实业务风险场景，验证“采集 → 传输 → 告警 → 联动 → 闭环”完整链路</p>
        </div>
        <button class="icon-btn" data-close-modal aria-label="关闭">${icon('close', 15)}</button>
      </div>
      <div class="modal-body">
        ${App.state.scenario ? `<div style="padding:9px 11px;border-radius:7px;background:rgba(255,95,109,.08);border:1px solid rgba(255,95,109,.2);margin-bottom:13px;display:flex;align-items:center;gap:8px;font-size:9px;color:#ffb3ba">${icon('alert', 13)} 当前已有演练进行中：${esc(App.state.scenario.name)} · ${esc(App.state.scenario.faceName)}，继续操作将覆盖当前场景。</div>` : ''}
        <div class="modal-section-label">选择风险场景</div>
        <div class="scenario-grid">
          ${scenarios.map((s) => `<button class="scenario-card ${App.drillDraft.type === s.key ? 'selected' : ''}" data-scenario="${s.key}">
            <span class="scenario-code">${esc(s.code)} / ${s.duration}s</span>
            <h4>${scenarioIcon(s.key)} ${esc(s.name)}</h4>
            <p>${esc(s.description)}</p>
            <div class="scenario-target">${(s.targetTypes || []).map((t) => `<span class="target-chip">${esc(SENSOR_META(t).name || t)}</span>`).join('')}</div>
          </button>`).join('')}
        </div>
        <div class="modal-section-label">注入工作面</div>
        <div class="drill-face-grid">
          ${allFaces().map((f) => `<button class="drill-face ${App.drillDraft.faceId === f.id ? 'selected' : ''}" data-drill-face="${f.id}">${esc(f.name)}<small>${esc(f.mineName)} · ${f.gas.toFixed(2)}%CH₄</small></button>`).join('')}
        </div>
        <div class="drill-summary">
          <span>${icon('pin', 11)} ${esc(drillFaceLabel(App.drillDraft.faceId))}</span>
          <span>${icon('clock', 11)} 场景时长 <b>${App.bootstrap.scenarios[App.drillDraft.type]?.duration || 0}s</b></span>
          <span>${icon('alarm', 11)} 预期最高等级 <b style="color:#ff7a85">${levelMeta(App.bootstrap.scenarios[App.drillDraft.type]?.level || 'alarm').label}</b></span>
          <span>${icon('activity', 11)} 采样周期 <b>2s</b></span>
        </div>
      </div>
      <div class="modal-foot">
        <div class="foot-note">${icon('shield', 11)} 演练数据带 SIM 标识，不写入正式生产报表</div>
        <div class="modal-actions">
          <button class="btn" data-close-modal>取消</button>
          ${App.state.scenario ? '<button class="btn btn-danger" data-stop-drill>结束当前演练</button>' : ''}
          <button class="btn btn-primary" data-start-drill>${icon('play', 13)} 启动演练</button>
        </div>
      </div>
    </div>`;
  requestAnimationFrame(() => {
    $('.modal-backdrop', root).classList.add('show');
    $('#drill-modal', root).classList.add('show');
  });
}

function scenarioIcon(key) {
  return icon({ gas: 'flame', co: 'cloud', vent: 'fan', dust: 'dust' }[key] || 'activity', 13);
}

function closeModal(force = false) {
  const root = $('#modal-root');
  if (!root) return;
  const modal = $('.modal', root);
  const backdrop = $('.modal-backdrop', root);
  if (!modal) return;
  if (force) { root.innerHTML = ''; return; }
  modal.classList.remove('show');
  backdrop.classList.remove('show');
  setTimeout(() => { if (!modal.classList.contains('show')) root.innerHTML = ''; }, 260);
}

async function startDrill() {
  const { type, faceId } = App.drillDraft;
  try {
    const result = await post('/api/scenario', { type, faceId });
    if (result.state) App.state = result.state;
    App.selectedFaceId = faceId;
    closeModal();
    updateScenarioBanner();
    toast('演练已启动', `${result.scenario?.name || '风险场景'}已注入 ${drillFaceLabel(faceId)}，观察告警联动链路`, 'warn', 5200);
    navigate(`#/face/${faceId}`);
  } catch (error) {
    toast('演练启动失败', error.message, 'error');
  }
}

async function stopDrill() {
  try {
    const result = await post('/api/scenario', { type: 'normal' });
    if (result.state) App.state = result.state;
    closeModal();
    updateScenarioBanner();
    toast('演练已结束', '场景参数已撤销，测点按安全基线平滑回归', 'success');
    if (App.route.name === 'overview') updateOverview();
    if (App.route.name === 'face') updateFaceLive();
  } catch (error) {
    toast('结束演练失败', error.message, 'error');
  }
}

function updateScenarioBanner() {
  const banner = $('#scenario-banner');
  if (!banner) return;
  const scenario = App.state?.scenario;
  if (!scenario) { banner.hidden = true; return; }
  banner.hidden = false;
  const title = $('#sb-title');
  const face = $('#sb-face');
  const remain = $('#sb-remain');
  const bar = $('#sb-progress-bar');
  if (title) title.textContent = `${scenario.code || 'SIM'} · ${scenario.name}`;
  if (face) face.textContent = `${scenario.mineName} / ${scenario.faceName}`;
  const left = Math.max(0, Math.round((new Date(scenario.endsAt).getTime() - Date.now()) / 1000));
  const progress = Math.min(100, Math.max(0, ((scenario.duration - left) / Math.max(1, scenario.duration)) * 100));
  if (remain) remain.textContent = formatDuration(left);
  if (bar) bar.style.width = `${progress}%`;
}

/* ============================================================
   Toast
   ============================================================ */
function toast(title, message = '', type = 'info', duration = 3800) {
  const root = $('#toast-root');
  if (!root) return;
  const map = {
    info: { color: '#4f8dff', soft: 'rgba(79,141,255,.12)', icon: 'activity' },
    success: { color: '#35e0c0', soft: 'rgba(53,224,192,.12)', icon: 'check' },
    warn: { color: '#ffb547', soft: 'rgba(255,181,71,.12)', icon: 'alert' },
    error: { color: '#ff5f6d', soft: 'rgba(255,95,109,.12)', icon: 'alert' }
  }[type] || { color: '#4f8dff', soft: 'rgba(79,141,255,.12)', icon: 'activity' };
  const el = document.createElement('div');
  el.className = 'toast';
  el.style.setProperty('--t-color', map.color);
  el.style.setProperty('--t-soft', map.soft);
  el.innerHTML = `<span class="t-ico">${icon(map.icon, 12)}</span><div><b>${esc(title)}</b>${message ? `<p>${esc(message)}</p>` : ''}</div>`;
  root.appendChild(el);
  setTimeout(() => {
    el.classList.add('out');
    setTimeout(() => el.remove(), 260);
  }, duration);
}

/* ============================================================
   导出与辅助
   ============================================================ */
function exportDailyReport() {
  const s = App.state.system;
  const active = App.alarms.filter((a) => a.status !== 'resolved');
  const rows = [
    ['深地智安 · 矿井安全日报', dateTime(new Date())],
    [],
    ['集团指标', '数值'],
    ['矿井数量', s.mines],
    ['采掘工作面', s.faces],
    ['在线测点', `${s.onlinePoints}/${s.totalPoints}`],
    ['平均瓦斯', `${s.avgGas}%CH₄`],
    ['活动告警', s.activeAlarms],
    ['今日闭环率', `${s.closureRate}%`],
    [],
    ['矿井', '风险指数', '平均瓦斯(%)', '平均温度(℃)', '活动告警'],
    ...App.state.mines.map((m) => [m.name, m.risk, m.avgGas, m.avgTemp, m.activeAlarms]),
    [],
    ['未闭环告警', '等级', '工作面', '测点', '数值', '原因'],
    ...active.map((a) => [a.id, levelMeta(a.level).label, a.faceName, a.sensorName, `${a.value}${a.unit}`, a.cause])
  ];
  download(`深地智安-安全日报-${new Date().toISOString().slice(0, 10)}.csv`, toCsv(rows), 'text/csv;charset=utf-8');
  toast('日报已生成', '含集团指标、矿井排名与未闭环告警清单', 'success');
}

function goSensorHistory(sensorId) {
  const sensor = allFaces().flatMap((f) => f.sensors).find((s) => s.id === sensorId);
  if (!sensor) return;
  const face = findFace(sensor.faceId);
  App.historyFilters = {
    mineId: face.mineId,
    faceId: face.id,
    sensorId: sensor.id,
    quick: '24h',
    from: nowLocalInput(-24),
    to: nowLocalInput(0)
  };
  navigate('#/history');
}

/* ============================================================
   全局事件
   ============================================================ */
function bindGlobalEvents() {
  window.addEventListener('hashchange', render);
  window.addEventListener('resize', debounce(() => Charts.redrawAll(), 180));
  document.addEventListener('click', onClick);
  document.addEventListener('change', onChange);
  document.addEventListener('input', onInput);
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') { closeDrawer(); closeModal(); $('.mine-select')?.classList.remove('open'); }
  });
}

function onClick(event) {
  const target = event.target;

  if (target.closest('[data-close-drawer]')) { closeDrawer(); return; }
  if (target.closest('[data-close-modal]')) { closeModal(); return; }

  if (target.closest('#menu-toggle')) { $('#sidebar')?.classList.toggle('open'); return; }
  if (target.closest('#mine-filter')) {
    $('.mine-select')?.classList.toggle('open');
    return;
  }
  const mineOption = target.closest('[data-mine-filter]');
  if (mineOption) {
    $('.mine-select')?.classList.remove('open');
    setMineFilter(mineOption.dataset.mineFilter);
    return;
  }
  if (!target.closest('.mine-select')) $('.mine-select')?.classList.remove('open');

  if (target.closest('#drill-btn') || target.closest('#ov-drill') || target.closest('#alarm-drill')) { openDrillModal(); return; }
  if (target.closest('#alarm-bell')) { App.alarmFilters.status = 'open'; navigate('#/alarms'); return; }
  if (target.closest('#link-status')) { navigate('#/topology'); return; }
  if (target.closest('#sb-stop') || target.closest('[data-stop-drill]')) { stopDrill(); return; }
  if (target.closest('[data-start-drill]')) { startDrill(); return; }
  if (target.closest('#report-export')) { exportDailyReport(); return; }
  if (target.closest('#topo-check')) {
    toast('链路自检已发起', '9 座分站、双环链路与平台接入均响应正常', 'success');
    return;
  }
  if (target.closest('#device-refresh')) { loadDevices().then(() => toast('设备台账已同步', '设备状态与在线数量已更新', 'success')); return; }
  if (target.closest('#refresh-alarms')) { refreshAlarms(false); return; }
  if (target.closest('#history-query')) { syncHistoryInputs(); loadHistory(); return; }
  if (target.closest('#history-export')) { exportHistory(); return; }
  const range = target.closest('[data-range]');
  if (range) { applyHistoryRange(range.dataset.range); return; }
  const quick = target.closest('[data-alarm-quick]');
  if (quick) {
    App.alarmFilters.status = quick.dataset.alarmQuick;
    $$('#alarm-quick button').forEach((b) => b.classList.toggle('active', b.dataset.alarmQuick === App.alarmFilters.status));
    $('#alarm-status-filter').value = App.alarmFilters.status;
    updateAlarmKpis();
    renderAlarmTable();
    return;
  }

  const scenarioCard = target.closest('[data-scenario]');
  if (scenarioCard) {
    App.drillDraft.type = scenarioCard.dataset.scenario;
    openDrillModal();
    return;
  }
  const drillFace = target.closest('[data-drill-face]');
  if (drillFace) {
    App.drillDraft.faceId = drillFace.dataset.drillFace;
    openDrillModal();
    return;
  }

  const mineOpen = target.closest('[data-mine-open]');
  if (mineOpen) {
    const mine = App.state.mines.find((m) => m.id === mineOpen.dataset.mineOpen);
    if (mine?.faces[0]) { App.selectedFaceId = mine.faces[0].id; navigate(`#/face/${mine.faces[0].id}`); }
    return;
  }
  const faceChip = target.closest('[data-face]');
  if (faceChip) {
    App.selectedFaceId = faceChip.dataset.face;
    navigate(`#/face/${faceChip.dataset.face}`);
    return;
  }
  const sensorMarker = target.closest('[data-sensor]');
  if (sensorMarker) {
    const face = findFace(App.selectedFaceId);
    App.sensorByFace[face.id] = sensorMarker.dataset.sensor;
    if (App.route.name === 'face') updateFaceLive();
    return;
  }
  const sensorRow = target.closest('[data-sensor-row]');
  if (sensorRow) {
    App.sensorByFace[App.selectedFaceId] = sensorRow.dataset.sensorRow;
    updateFaceLive();
    return;
  }
  const alarmOpen = target.closest('[data-alarm-open]');
  if (alarmOpen) { openAlarmDrawer(alarmOpen.dataset.alarmOpen); return; }
  const ack = target.closest('[data-alarm-ack]');
  if (ack) { ackAlarm(ack.dataset.alarmAck); return; }
  const resolve = target.closest('[data-alarm-resolve]');
  if (resolve) { resolveAlarm(resolve.dataset.alarmResolve); return; }
  const faceHistory = target.closest('[data-face-history]');
  if (faceHistory) {
    const face = findFace(faceHistory.dataset.faceHistory);
    const sensor = face.sensors.find((s) => s.type === 'ch4') || face.sensors[0];
    goSensorHistory(sensor.id);
    return;
  }
  const faceDrill = target.closest('[data-face-drill]');
  if (faceDrill) { App.drillDraft.faceId = faceDrill.dataset.faceDrill; openDrillModal(); return; }
  const sensorHistory = target.closest('[data-sensor-history]');
  if (sensorHistory) { goSensorHistory(sensorHistory.dataset.sensorHistory); return; }
  const sensorCheck = target.closest('[data-sensor-check]');
  if (sensorCheck) { toast('校准记录', '该测点最近标校时间 2026-10-18，标校结果合格，周期 90 天', 'info'); return; }
  const action = target.closest('[data-action]');
  if (action) {
    if (action.dataset.action === 'toggle-flow') {
      $('#face-canvas')?.classList.toggle('no-flow');
      toast('风流示意已切换', '仅影响页面示意，不影响实时采集数据', 'info', 2200);
    }
    if (action.dataset.action === 'face-refresh') {
      api('/api/state').then((state) => { App.state = state; updateFaceLive(); toast('测点已刷新', '已同步最新采样周期数据', 'success', 2200); });
    }
    return;
  }
  const deviceCat = target.closest('[data-device-cat]');
  if (deviceCat) {
    App.deviceCategory = deviceCat.dataset.deviceCat;
    $('#device-tabs').innerHTML = deviceTabsHTML();
    $('#device-grid').innerHTML = deviceGridHTML();
    return;
  }
}

function onChange(event) {
  const id = event.target.id;
  if (id === 'alarm-status-filter') { App.alarmFilters.status = event.target.value; updateAlarmKpis(); renderAlarmTable(); return; }
  if (id === 'alarm-level-filter') { App.alarmFilters.level = event.target.value; renderAlarmTable(); return; }
  if (id === 'alarm-mine-filter') { App.alarmFilters.mineId = event.target.value; renderAlarmTable(); return; }
  if (id === 'history-mine') {
    const mine = App.bootstrap.mines.find((m) => m.id === event.target.value);
    const faceId = mine.faces[0].id;
    App.historyFilters = { ...App.historyFilters, mineId: mine.id, faceId, sensorId: `${faceId}-CH4-01` };
    $('#history-filter').innerHTML = historyFilterHTML();
    loadHistory();
    return;
  }
  if (id === 'history-face') {
    App.historyFilters.faceId = event.target.value;
    App.historyFilters.sensorId = `${event.target.value}-CH4-01`;
    $('#history-filter').innerHTML = historyFilterHTML();
    loadHistory();
    return;
  }
  if (id === 'history-sensor') { App.historyFilters.sensorId = event.target.value; return; }
  if (id === 'history-from' || id === 'history-to') {
    App.historyFilters.from = $('#history-from').value;
    App.historyFilters.to = $('#history-to').value;
    App.historyFilters.quick = 'custom';
    $$('#history-quick button').forEach((b) => b.classList.remove('active'));
  }
}

const debouncedAlarmQuery = debounce(() => {
  const input = $('#alarm-query');
  if (!input) return;
  App.alarmFilters.query = input.value;
  renderAlarmTable();
}, 260);

function onInput(event) {
  if (event.target.id === 'face-search') {
    App.faceQuery = event.target.value;
    const tree = $('#face-tree');
    if (tree) tree.innerHTML = faceTreeHTML();
    return;
  }
  if (event.target.id === 'alarm-query') debouncedAlarmQuery();
}

function syncHistoryInputs() {
  if (!App.historyFilters) return;
  const from = $('#history-from')?.value;
  const to = $('#history-to')?.value;
  if (from) App.historyFilters.from = from;
  if (to) App.historyFilters.to = to;
}

/* 启动 */
init();

