/**
 * 轻量 Canvas 图表库：折线、柱状、环形、仪表盘、迷你趋势。
 * 无第三方依赖，适配矿井内网/离线演示环境。
 */

const FONT = '"Microsoft YaHei UI", "Microsoft YaHei", "PingFang SC", sans-serif';
const NUM_FONT = '"Bahnschrift", "DIN Alternate", "Microsoft YaHei UI", sans-serif';

function fit(canvas) {
  const rect = canvas.getBoundingClientRect();
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  const w = Math.max(10, rect.width);
  const h = Math.max(10, rect.height);
  canvas.width = Math.round(w * dpr);
  canvas.height = Math.round(h * dpr);
  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);
  return { ctx, w, h };
}

function rgba(hex, alpha = 1) {
  const value = String(hex).replace('#', '');
  const full = value.length === 3 ? value.split('').map((c) => c + c).join('') : value;
  const n = parseInt(full, 16);
  const r = (n >> 16) & 255;
  const g = (n >> 8) & 255;
  const b = n & 255;
  return `rgba(${r},${g},${b},${alpha})`;
}

function niceBounds(min, max, ticks = 4) {
  if (!Number.isFinite(min) || !Number.isFinite(max)) return { min: 0, max: 1, step: 1 };
  if (min === max) {
    const pad = Math.abs(min) * 0.2 || 1;
    min -= pad;
    max += pad;
  }
  const span = max - min;
  const rough = span / ticks;
  const pow = Math.pow(10, Math.floor(Math.log10(rough)));
  const norm = rough / pow;
  const nice = norm <= 1 ? 1 : norm <= 2 ? 2 : norm <= 2.5 ? 2.5 : norm <= 5 ? 5 : 10;
  const step = nice * pow;
  const lower = Math.floor(min / step) * step;
  const upper = Math.ceil(max / step) * step;
  return { min: lower, max: upper, step };
}

function drawGrid(ctx, box, yMin, yMax, yStep, xLabels, color = 'rgba(132,166,198,.12)') {
  const { x, y, w, h } = box;
  ctx.save();
  ctx.strokeStyle = color;
  ctx.lineWidth = 1;
  ctx.font = `10px ${NUM_FONT}`;
  ctx.fillStyle = 'rgba(137,163,190,.7)';
  ctx.textAlign = 'right';
  ctx.textBaseline = 'middle';
  for (let v = yMin; v <= yMax + yStep * 0.01; v += yStep) {
    const py = y + h - ((v - yMin) / (yMax - yMin)) * h;
    ctx.beginPath();
    ctx.moveTo(x, Math.round(py) + 0.5);
    ctx.lineTo(x + w, Math.round(py) + 0.5);
    ctx.stroke();
    ctx.fillText(formatTick(v, yStep), x - 8, py);
  }
  if (xLabels?.length) {
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    const count = Math.min(6, xLabels.length);
    for (let i = 0; i < count; i += 1) {
      const idx = Math.round((i / (count - 1)) * (xLabels.length - 1));
      const px = x + (idx / Math.max(1, xLabels.length - 1)) * w;
      ctx.fillText(xLabels[idx], clampX(px, x, x + w, ctx), y + h + 10);
    }
  }
  ctx.restore();
}

function clampX(px, min, max, ctx) {
  const text = '';
  return Math.max(min + 12, Math.min(max - 12, px));
}

function formatTick(v, step) {
  if (step >= 10) return Math.round(v).toLocaleString('zh-CN');
  if (step >= 1) return Number(v).toFixed(0);
  if (step >= 0.1) return Number(v).toFixed(1);
  return Number(v).toFixed(2);
}

function linePath(ctx, points) {
  if (!points.length) return;
  ctx.moveTo(points[0].x, points[0].y);
  for (let i = 1; i < points.length - 1; i += 1) {
    const current = points[i];
    const next = points[i + 1];
    const midX = (current.x + next.x) / 2;
    const midY = (current.y + next.y) / 2;
    ctx.quadraticCurveTo(current.x, current.y, midX, midY);
  }
  if (points.length > 1) {
    const last = points[points.length - 1];
    ctx.lineTo(last.x, last.y);
  }
}

export function line(canvas, options = {}) {
  const draw = () => {
    if (!canvas?.isConnected) return;
    const { ctx, w, h } = fit(canvas);
    const series = (options.series || []).filter((s) => s.values?.length);
    if (!series.length) {
      ctx.fillStyle = 'rgba(137,163,190,.55)';
      ctx.font = `12px ${FONT}`;
      ctx.textAlign = 'center';
      ctx.fillText('暂无数据', w / 2, h / 2);
      return;
    }
    const values = series.flatMap((s) => s.values);
    const thresholdValues = (options.thresholds || []).map((t) => t.value);
    const hasMin = Number.isFinite(options.min);
    const hasMax = Number.isFinite(options.max);
    const rawMin = hasMin ? options.min : Math.min(...values, ...thresholdValues);
    const rawMax = hasMax ? options.max : Math.max(...values, ...thresholdValues);
    const pad = (rawMax - rawMin) * 0.08 || 1;
    let min;
    let max;
    let step;
    if (hasMin && hasMax) {
      min = rawMin;
      max = rawMax;
      step = (max - min) / 4;
    } else {
      const bounds = niceBounds(hasMin ? rawMin : rawMin - pad, hasMax ? rawMax : rawMax + pad, 4);
      min = bounds.min;
      max = bounds.max;
      step = bounds.step;
    }
    const box = { x: 46, y: 18, w: w - 62, h: h - 50 };

    drawGrid(ctx, box, min, max, step, options.labels || []);

    // 阈值参考线
    for (const t of options.thresholds || []) {
      if (t.value < min || t.value > max) continue;
      const py = box.y + box.h - ((t.value - min) / (max - min)) * box.h;
      ctx.save();
      ctx.strokeStyle = rgba(t.color || '#ff5f6d', 0.55);
      ctx.lineWidth = 1;
      ctx.setLineDash([5, 5]);
      ctx.beginPath();
      ctx.moveTo(box.x, py);
      ctx.lineTo(box.x + box.w, py);
      ctx.stroke();
      ctx.setLineDash([]);
      if (t.label) {
        ctx.font = `10px ${FONT}`;
        ctx.fillStyle = rgba(t.color || '#ff5f6d', 0.9);
        ctx.textAlign = 'right';
        ctx.textBaseline = 'bottom';
        ctx.fillText(t.label, box.x + box.w - 2, py - 3);
      }
      ctx.restore();
    }

    series.forEach((s, sIndex) => {
      const color = s.color || '#35e0c0';
      const points = s.values.map((v, i) => ({
        x: box.x + (i / Math.max(1, s.values.length - 1)) * box.w,
        y: box.y + box.h - ((v - min) / (max - min)) * box.h
      }));
      if (s.fill !== false) {
        const gradient = ctx.createLinearGradient(0, box.y, 0, box.y + box.h);
        gradient.addColorStop(0, rgba(color, sIndex === 0 ? 0.24 : 0.12));
        gradient.addColorStop(1, rgba(color, 0));
        ctx.beginPath();
        ctx.moveTo(points[0].x, box.y + box.h);
        linePath(ctx, points);
        ctx.lineTo(points[points.length - 1].x, box.y + box.h);
        ctx.closePath();
        ctx.fillStyle = gradient;
        ctx.fill();
      }
      ctx.save();
      ctx.beginPath();
      linePath(ctx, points);
      ctx.strokeStyle = color;
      ctx.lineWidth = s.width || 2;
      ctx.shadowColor = rgba(color, 0.35);
      ctx.shadowBlur = 8;
      ctx.stroke();
      ctx.restore();

      const last = points[points.length - 1];
      ctx.save();
      ctx.beginPath();
      ctx.arc(last.x, last.y, 3.2, 0, Math.PI * 2);
      ctx.fillStyle = color;
      ctx.shadowColor = color;
      ctx.shadowBlur = 10;
      ctx.fill();
      ctx.restore();
    });
  };
  canvas._redraw = draw;
  requestAnimationFrame(draw);
}

export function bar(canvas, options = {}) {
  const draw = () => {
    if (!canvas?.isConnected) return;
    const { ctx, w, h } = fit(canvas);
    const data = options.data || [];
    if (!data.length) return;
    const values = data.map((d) => Number(d.value) || 0);
    const { max, step } = niceBounds(0, Math.max(...values, 1), 3);
    const box = { x: 38, y: 16, w: w - 52, h: h - 44 };
    drawGrid(ctx, box, 0, max, step, []);
    const gap = Math.max(3, box.w / data.length * 0.32);
    const barW = Math.max(3, (box.w - gap * (data.length - 1)) / data.length);
    data.forEach((d, i) => {
      const value = Number(d.value) || 0;
      const bh = (value / max) * box.h;
      const x = box.x + i * (barW + gap);
      const y = box.y + box.h - bh;
      const gradient = ctx.createLinearGradient(0, y, 0, box.y + box.h);
      const color = d.color || '#4f8dff';
      gradient.addColorStop(0, color);
      gradient.addColorStop(1, rgba(color, 0.25));
      ctx.fillStyle = gradient;
      roundedRect(ctx, x, y, barW, Math.max(2, bh), Math.min(3, barW / 2));
      ctx.fill();
    });
    ctx.save();
    ctx.fillStyle = 'rgba(137,163,190,.7)';
    ctx.font = `10px ${FONT}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    const count = Math.min(6, data.length);
    for (let i = 0; i < count; i += 1) {
      const idx = Math.round((i / (count - 1)) * (data.length - 1));
      const x = box.x + idx * (barW + gap) + barW / 2;
      ctx.fillText(data[idx].label, x, box.y + box.h + 10);
    }
    ctx.restore();
  };
  canvas._redraw = draw;
  requestAnimationFrame(draw);
}

function roundedRect(ctx, x, y, w, h, r) {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + w, y, x + w, y + h, radius);
  ctx.arcTo(x + w, y + h, x, y + h, radius);
  ctx.arcTo(x, y + h, x, y, radius);
  ctx.arcTo(x, y, x + w, y, radius);
  ctx.closePath();
}

export function donut(canvas, options = {}) {
  const draw = () => {
    if (!canvas?.isConnected) return;
    const { ctx, w, h } = fit(canvas);
    const segments = (options.segments || []).filter((s) => s.value > 0);
    const total = segments.reduce((sum, s) => sum + s.value, 0);
    const cx = w / 2;
    const cy = h / 2;
    const radius = Math.min(w, h) * 0.34;
    const thickness = Math.max(10, radius * 0.22);
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(120,160,200,.1)';
    ctx.lineWidth = thickness;
    ctx.stroke();
    if (!total) {
      ctx.fillStyle = 'rgba(137,163,190,.55)';
      ctx.font = `12px ${FONT}`;
      ctx.textAlign = 'center';
      ctx.fillText('暂无告警', cx, cy + 4);
      return;
    }
    let start = -Math.PI / 2;
    segments.forEach((s) => {
      const angle = (s.value / total) * Math.PI * 2;
      ctx.beginPath();
      ctx.arc(cx, cy, radius, start + 0.025, start + angle - 0.025);
      ctx.strokeStyle = s.color;
      ctx.lineWidth = thickness;
      ctx.lineCap = 'round';
      ctx.shadowColor = rgba(s.color, 0.3);
      ctx.shadowBlur = 8;
      ctx.stroke();
      start += angle;
    });
    ctx.restore();
    ctx.save();
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#e9f3ff';
    ctx.font = `700 ${Math.round(radius * 0.42)}px ${NUM_FONT}`;
    ctx.fillText(String(options.centerValue ?? total), cx, cy - 4);
    ctx.fillStyle = 'rgba(137,163,190,.8)';
    ctx.font = `11px ${FONT}`;
    ctx.fillText(options.centerLabel || '活动事件', cx, cy + radius * 0.36);
    ctx.restore();
  };
  canvas._redraw = draw;
  requestAnimationFrame(draw);
}

export function gauge(canvas, options = {}) {
  const draw = () => {
    if (!canvas?.isConnected) return;
    const { ctx, w, h } = fit(canvas);
    const min = options.min ?? 0;
    const max = options.max ?? 100;
    const value = Math.max(min, Math.min(max, options.value ?? 0));
    const cx = w / 2;
    const cy = h * 0.78;
    const radius = Math.min(w * 0.4, h * 0.63);
    const start = Math.PI * 0.78;
    const end = Math.PI * 2.22;
    const ratio = (value - min) / (max - min || 1);
    const color = options.color || '#35e0c0';
    ctx.save();
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.arc(cx, cy, radius, start, end);
    ctx.strokeStyle = 'rgba(120,160,200,.12)';
    ctx.lineWidth = 10;
    ctx.stroke();
    if (ratio > 0.002) {
      ctx.beginPath();
      ctx.arc(cx, cy, radius, start, start + (end - start) * ratio);
      ctx.strokeStyle = color;
      ctx.lineWidth = 10;
      ctx.shadowColor = rgba(color, 0.5);
      ctx.shadowBlur = 12;
      ctx.stroke();
    }
    ctx.restore();
    // 刻度
    ctx.save();
    for (let i = 0; i <= 5; i += 1) {
      const a = start + ((end - start) * i) / 5;
      const x1 = cx + Math.cos(a) * (radius - 12);
      const y1 = cy + Math.sin(a) * (radius - 12);
      const x2 = cx + Math.cos(a) * (radius - 6);
      const y2 = cy + Math.sin(a) * (radius - 6);
      ctx.strokeStyle = 'rgba(170,200,225,.28)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
    }
    ctx.restore();
    ctx.save();
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#f2f8ff';
    ctx.font = `700 ${Math.round(radius * 0.38)}px ${NUM_FONT}`;
    ctx.fillText(options.text ?? String(value), cx, cy - 12);
    ctx.fillStyle = 'rgba(137,163,190,.9)';
    ctx.font = `11px ${FONT}`;
    ctx.fillText(options.unit || '', cx, cy + 14);
    if (options.caption) {
      ctx.fillStyle = 'rgba(137,163,190,.6)';
      ctx.font = `10px ${FONT}`;
      ctx.fillText(options.caption, cx, cy + 30);
    }
    ctx.restore();
  };
  canvas._redraw = draw;
  requestAnimationFrame(draw);
}

export function sparkline(canvas, options = {}) {
  const draw = () => {
    if (!canvas?.isConnected) return;
    const { ctx, w, h } = fit(canvas);
    const values = options.values || [];
    if (values.length < 2) return;
    const min = Math.min(...values);
    const max = Math.max(...values);
    const pad = (max - min) * 0.18 || 1;
    const color = options.color || '#35e0c0';
    const points = values.map((v, i) => ({
      x: (i / (values.length - 1)) * (w - 4) + 2,
      y: h - 3 - ((v - min + pad) / (max - min + pad * 2)) * (h - 6)
    }));
    const gradient = ctx.createLinearGradient(0, 0, 0, h);
    gradient.addColorStop(0, rgba(color, 0.3));
    gradient.addColorStop(1, rgba(color, 0));
    ctx.beginPath();
    ctx.moveTo(points[0].x, h);
    linePath(ctx, points);
    ctx.lineTo(points[points.length - 1].x, h);
    ctx.closePath();
    ctx.fillStyle = gradient;
    ctx.fill();
    ctx.beginPath();
    linePath(ctx, points);
    ctx.strokeStyle = color;
    ctx.lineWidth = 1.7;
    ctx.stroke();
  };
  canvas._redraw = draw;
  requestAnimationFrame(draw);
}

export function redrawAll(root = document) {
  requestAnimationFrame(() => {
    root.querySelectorAll('canvas').forEach((canvas) => {
      if (typeof canvas._redraw === 'function') canvas._redraw();
    });
  });
}

export function resizeObserver(view) {
  if (!view) return null;
  let timer = null;
  const observer = new ResizeObserver(() => {
    clearTimeout(timer);
    timer = setTimeout(() => redrawAll(view), 120);
  });
  observer.observe(view);
  return observer;
}
