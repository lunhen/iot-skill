export const LEVEL = {
  normal: { label: '正常', color: '#35e0c0', soft: 'rgba(53,224,192,.12)', cls: 'normal', rank: 0 },
  warning: { label: '预警', color: '#ffb547', soft: 'rgba(255,181,71,.13)', cls: 'warning', rank: 1 },
  alarm: { label: '告警', color: '#ff7a59', soft: 'rgba(255,122,89,.14)', cls: 'alarm', rank: 2 },
  critical: { label: '严重告警', color: '#ff5f6d', soft: 'rgba(255,95,109,.16)', cls: 'critical', rank: 3 }
};

export function $(sel, root = document) {
  return root.querySelector(sel);
}

export function $$(sel, root = document) {
  return [...root.querySelectorAll(sel)];
}

export function esc(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

export function fmt(value, digits = 1) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) return '--';
  return Number(value).toFixed(digits);
}

export function compact(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return '--';
  if (n >= 100000000) return `${(n / 100000000).toFixed(1)}亿`;
  if (n >= 10000) return `${(n / 10000).toFixed(1)}万`;
  return n.toLocaleString('zh-CN');
}

export function pad(n) {
  return String(n).padStart(2, '0');
}

export function clock(date = new Date(), withSeconds = true) {
  const d = date instanceof Date ? date : new Date(date);
  return `${pad(d.getHours())}:${pad(d.getMinutes())}${withSeconds ? `:${pad(d.getSeconds())}` : ''}`;
}

export function dateTime(date = new Date()) {
  const d = date instanceof Date ? date : new Date(date);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

export function shortDate(date = new Date()) {
  const d = date instanceof Date ? date : new Date(date);
  return `${pad(d.getMonth() + 1)}/${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export function timeAgo(iso) {
  const diff = Math.max(0, Date.now() - new Date(iso).getTime());
  const min = Math.floor(diff / 60000);
  if (min < 1) return '刚刚';
  if (min < 60) return `${min} 分钟前`;
  const h = Math.floor(min / 60);
  if (h < 24) return `${h} 小时前`;
  return `${Math.floor(h / 24)} 天前`;
}

export function levelMeta(level) {
  return LEVEL[level] || LEVEL.normal;
}

export function levelTag(level, text) {
  const meta = levelMeta(level);
  return `<span class="tag tag-${meta.cls}"><i class="tag-dot"></i>${esc(text ?? meta.label)}</span>`;
}

export function trendIcon(trend) {
  if (trend === 'up') return '<span class="trend up">▲</span>';
  if (trend === 'down') return '<span class="trend down">▼</span>';
  return '<span class="trend flat">–</span>';
}

export function riskColor(score) {
  if (score >= 70) return '#ff5f6d';
  if (score >= 50) return '#ff7a59';
  if (score >= 30) return '#ffb547';
  return '#35e0c0';
}

export function riskLabel(score) {
  if (score >= 70) return '高风险';
  if (score >= 50) return '较高风险';
  if (score >= 30) return '关注';
  return '低风险';
}

export function download(filename, content, type = 'text/plain;charset=utf-8') {
  const blob = content instanceof Blob ? content : new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

export function toCsv(rows) {
  return '\uFEFF' + rows.map((row) => row.map((cell) => {
    const text = String(cell ?? '');
    return /[",\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
  }).join(',')).join('\r\n');
}

export function debounce(fn, wait = 200) {
  let timer = null;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), wait);
  };
}

export function escapeAttr(value) {
  return esc(value).replaceAll('`', '&#96;');
}

export function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

export function nowLocalInput(offsetHours = 0) {
  const d = new Date(Date.now() + offsetHours * 3600_000);
  const local = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 16);
}

export function formatDuration(seconds) {
  const s = Math.max(0, Math.round(seconds));
  return `${pad(Math.floor(s / 60))}:${pad(s % 60)}`;
}

export function greeting() {
  const h = new Date().getHours();
  if (h < 6) return '夜间值守';
  if (h < 12) return '上午好';
  if (h < 18) return '下午好';
  return '晚上好';
}
