"""为 PPT 准备背景与截图裁切资源。"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter, ImageEnhance
import math

ROOT = Path(__file__).resolve().parent.parent
SHOTS = ROOT / "deliverables" / "screenshots"
OUT = ROOT / "deliverables" / "ppt-assets"
OUT.mkdir(parents=True, exist_ok=True)

W, H = 1920, 1080

# ---------- 背景 ----------
bg = Image.new("RGB", (W, H), (7, 17, 31))
glow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
g = ImageDraw.Draw(glow)
# 右上青色光晕
for r, a in [(700, 28), (520, 32), (340, 26)]:
    g.ellipse((W - 420 - r, -320 - r // 2, W - 420 + r, -320 + r // 2), fill=(53, 224, 192, a))
# 左下蓝色光晕
for r, a in [(760, 30), (560, 28)]:
    g.ellipse((-300 - r // 2, H - 420 - r, -300 + r, H - 420 + r), fill=(79, 141, 255, a))
glow = glow.filter(ImageFilter.GaussianBlur(160))
bg = Image.alpha_composite(bg.convert("RGBA"), glow)
d = ImageDraw.Draw(bg)
for x in range(0, W, 96):
    d.line([(x, 0), (x, H)], fill=(120, 170, 215, 4), width=1)
for y in range(0, H, 96):
    d.line([(0, y), (W, y)], fill=(120, 170, 215, 4), width=1)
# 顶部细线
d.line([(0, 0), (W, 0)], fill=(53, 224, 192, 60), width=2)
bg.convert("RGB").save(OUT / "bg.png", quality=94)


def crop_ratio(src, ratio, out, focus="center", brightness=1.0):
    im = Image.open(src).convert("RGB")
    w, h = im.size
    target = ratio
    if w / h > target:
        nw = int(h * target)
        left = 0 if focus == "left" else w - nw if focus == "right" else (w - nw) // 2
        im = im.crop((left, 0, left + nw, h))
    else:
        nh = int(w / target)
        top = 0 if focus == "top" else h - nh if focus == "bottom" else (h - nh) // 2
        im = im.crop((0, top, w, top + nh))
    if brightness != 1.0:
        im = ImageEnhance.Brightness(im).enhance(brightness)
    im.save(out, quality=94)
    return im


# 16:9 页面截图
crop_ratio(SHOTS / "01-overview.png", 16 / 9, OUT / "overview-169.png", brightness=1.08)
crop_ratio(SHOTS / "02-face.png", 16 / 9, OUT / "face-169.png", brightness=1.10)
crop_ratio(SHOTS / "03-alarms.png", 16 / 9, OUT / "alarms-169.png", brightness=1.08)
crop_ratio(SHOTS / "06-topology.png", 16 / 9, OUT / "topology-169.png", brightness=1.06)
crop_ratio(SHOTS / "09-scenario-live.png", 16 / 10, OUT / "scenario-1610.png", brightness=1.06)

# 封面右侧：从总览截图裁出竖图并压暗、加左侧渐变
hero = Image.open(SHOTS / "01-overview.png").convert("RGB")
# 目标宽高比 5.15 / 7.2 ≈ .715
target = 5.15 / 7.2
w, h = hero.size
nw = int(h * target)
crop = hero.crop((w - nw, 0, w, h))
crop = crop.resize((860, 1200), Image.LANCZOS)
crop = ImageEnhance.Brightness(crop).enhance(0.62)
# 左侧黑色渐变，与左侧文案衔接
grad = Image.new("L", crop.size, 0)
gd = ImageDraw.Draw(grad)
for x in range(crop.width):
    alpha = int(235 * max(0, 1 - x / (crop.width * 0.38)))
    gd.line([(x, 0), (x, crop.height)], fill=alpha)
black = Image.new("RGB", crop.size, (7, 17, 31))
crop = Image.composite(black, crop, grad)
crop.save(OUT / "cover-hero.png", quality=95)

# 设备卡片小图
crop_ratio(SHOTS / "07-devices.png", 16 / 9, OUT / "devices-169.png")

print("assets ready:", len(list(OUT.glob("*.png"))))
