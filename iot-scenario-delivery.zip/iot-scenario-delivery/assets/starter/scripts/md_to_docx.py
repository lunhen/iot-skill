"""将项目 Markdown 文档转换为排版后的 DOCX。

用法：
  python scripts/md_to_docx.py docs/设备选型说明.md deliverables/设备选型说明.docx \
      --subtitle "设备选型说明文档" --doc-code "MINE-IOT-DEV-001"
"""
from pathlib import Path
import argparse
import re

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor, Emu

NAVY = RGBColor(0x0B, 0x19, 0x29)
NAVY_HEX = "0B1929"
TEAL = RGBColor(0x0E, 0x7C, 0x6B)
TEAL_HEX = "35E0C0"
MUTED = RGBColor(0x5E, 0x74, 0x86)
DARK = RGBColor(0x1B, 0x33, 0x48)
LIGHT_HEX = "EAF4F7"
FONT_CN = "微软雅黑"
FONT_EN = "Arial"


def set_cell_shading(cell, hex_color):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), hex_color)
    shd.set(qn("w:val"), "clear")
    tc_pr.append(shd)


def set_cell_margins(cell, top=80, bottom=80, left=100, right=100):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for tag, value in (("top", top), ("left", left), ("bottom", bottom), ("right", right)):
        node = tc_mar.find(qn(f"w:{tag}"))
        if node is None:
            node = OxmlElement(f"w:{tag}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_repeat_table_header(row):
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def set_row_cant_split(row):
    tr_pr = row._tr.get_or_add_trPr()
    cant_split = OxmlElement("w:cantSplit")
    tr_pr.append(cant_split)


def set_run_font(run, size=None, bold=None, color=None, name_cn=FONT_CN, name_en=FONT_EN):
    run.font.name = name_en
    run._element.rPr.rFonts.set(qn("w:eastAsia"), name_cn)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.font.bold = bold
    if color is not None:
        run.font.color.rgb = color


def add_runs(paragraph, text, size=10.5, color=DARK, bold=False):
    # 支持 **加粗** 与 `代码`
    parts = re.split(r"(\*\*.+?\*\*|`.+?`)", text)
    for part in parts:
        if not part:
            continue
        if part.startswith("**") and part.endswith("**"):
            run = paragraph.add_run(part[2:-2])
            set_run_font(run, size=size, bold=True, color=color)
        elif part.startswith("`") and part.endswith("`"):
            run = paragraph.add_run(part[1:-1])
            set_run_font(run, size=size - 0.5, bold=False, color=TEAL, name_en="Consolas")
        else:
            run = paragraph.add_run(part)
            set_run_font(run, size=size, bold=bold, color=color)


def add_page_number(paragraph):
    run = paragraph.add_run()
    fld_char1 = OxmlElement("w:fldChar")
    fld_char1.set(qn("w:fldCharType"), "begin")
    instr_text = OxmlElement("w:instrText")
    instr_text.set(qn("xml:space"), "preserve")
    instr_text.text = "PAGE"
    fld_char2 = OxmlElement("w:fldChar")
    fld_char2.set(qn("w:fldCharType"), "end")
    run._r.append(fld_char1)
    run._r.append(instr_text)
    run._r.append(fld_char2)
    set_run_font(run, size=8, color=MUTED)


def add_bottom_border(paragraph, color="C9D9E5", size=6):
    p_pr = paragraph._p.get_or_add_pPr()
    p_bdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), str(size))
    bottom.set(qn("w:space"), "4")
    bottom.set(qn("w:color"), color)
    p_bdr.append(bottom)
    p_pr.append(p_bdr)


def setup_document():
    doc = Document()
    section = doc.sections[0]
    section.page_width = Cm(21.0)
    section.page_height = Cm(29.7)
    section.top_margin = Cm(2.0)
    section.bottom_margin = Cm(1.9)
    section.left_margin = Cm(2.1)
    section.right_margin = Cm(2.1)
    section.header_distance = Cm(0.8)
    section.footer_distance = Cm(0.8)

    normal = doc.styles["Normal"]
    normal.font.name = FONT_EN
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), FONT_CN)
    normal.font.size = Pt(10.5)
    normal.font.color.rgb = DARK
    normal.paragraph_format.line_spacing = 1.45
    normal.paragraph_format.space_after = Pt(5)

    for level, size, color, before, after in [
        (1, 17, NAVY, 16, 8),
        (2, 12.5, TEAL, 12, 5),
        (3, 11, DARK, 8, 3),
    ]:
        style = doc.styles[f"Heading {level}"]
        style.font.name = FONT_EN
        style._element.rPr.rFonts.set(qn("w:eastAsia"), FONT_CN)
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = color
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True
        if level == 1:
            style.paragraph_format.page_break_before = False

    # 页眉
    header = section.header
    hp = header.paragraphs[0]
    hp.text = ""
    hp.alignment = WD_ALIGN_PARAGRAPH.LEFT
    run = hp.add_run("深地智安 · 矿井安全物联网监测平台")
    set_run_font(run, size=8, color=MUTED)
    run2 = hp.add_run("    MINE SAFETY IOT / MODULE C")
    set_run_font(run2, size=7.5, color=RGBColor(0x9A, 0xAD, 0xBD))
    add_bottom_border(hp)

    # 页脚
    footer = section.footer
    fp = footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = fp.add_run("第 ")
    set_run_font(run, size=8, color=MUTED)
    add_page_number(fp)
    run = fp.add_run(" 页  |  模块 C · 场景创新与设计")
    set_run_font(run, size=8, color=MUTED)
    return doc


def add_cover(doc, title, subtitle, meta_lines, doc_code):
    # 顶部色带
    table = doc.add_table(rows=1, cols=1)
    table.autofit = False
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = table.cell(0, 0)
    cell.width = Cm(16.8)
    set_cell_shading(cell, NAVY_HEX)
    cell.text = ""
    p = cell.paragraphs[0]
    p.paragraph_format.space_before = Pt(22)
    p.paragraph_format.space_after = Pt(22)
    run = p.add_run("深 地 智 安")
    set_run_font(run, size=20, bold=True, color=RGBColor(0xE9, 0xF3, 0xFF))
    p2 = cell.add_paragraph()
    p2.paragraph_format.space_after = Pt(20)
    run = p2.add_run("MINE SAFETY IOT  /  SMART MINE SOLUTION")
    set_run_font(run, size=8, color=RGBColor(0x7F, 0xE8, 0xD6))

    doc.add_paragraph()
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(20)
    p.paragraph_format.space_after = Pt(6)
    run = p.add_run("智慧矿山安全物联网监测系统")
    set_run_font(run, size=15, color=MUTED)

    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(14)
    run = p.add_run(title)
    set_run_font(run, size=26, bold=True, color=NAVY)

    # 青色细线
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(12)
    p_pr = p._p.get_or_add_pPr()
    p_bdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "18")
    bottom.set(qn("w:space"), "1")
    bottom.set(qn("w:color"), TEAL_HEX)
    p_bdr.append(bottom)
    p_pr.append(p_bdr)

    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(28)
    run = p.add_run(subtitle)
    set_run_font(run, size=13, color=TEAL)

    for key, value in meta_lines:
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(5)
        run = p.add_run(f"{key}  ")
        set_run_font(run, size=9.5, bold=True, color=MUTED)
        run = p.add_run(value)
        set_run_font(run, size=9.5, color=DARK)

    doc.add_paragraph()
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(38)
    run = p.add_run("项目交付材料  ·  2026")
    set_run_font(run, size=9, color=RGBColor(0x8A, 0x9D, 0xAD))

    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(4)
    run = p.add_run(f"文件编号：{doc_code}    版本：V1.0    密级：内部")
    set_run_font(run, size=8.5, color=RGBColor(0x8A, 0x9D, 0xAD))

    doc.add_page_break()


def add_table(doc, rows, header=True):
    if not rows:
        return
    cols = max(len(r) for r in rows)
    table = doc.add_table(rows=len(rows), cols=cols)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    table.autofit = True

    # 计算列宽（按内容长度）
    lengths = [0] * cols
    for row in rows:
        for i, cell in enumerate(row):
            if i < cols:
                lengths[i] = max(lengths[i], len(re.sub(r"[*`]", "", cell)))
    total = sum(lengths) or 1
    usable = 16.8
    widths = [max(1.6, usable * l / total) for l in lengths]

    for r_idx, row in enumerate(rows):
        tr = table.rows[r_idx]
        set_row_cant_split(tr)
        if r_idx == 0 and header:
            set_repeat_table_header(tr)
        for c_idx in range(cols):
            cell = table.cell(r_idx, c_idx)
            cell.width = Cm(widths[c_idx])
            set_cell_margins(cell)
            text = row[c_idx] if c_idx < len(row) else ""
            cell.text = ""
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.15
            add_runs(p, text, size=8.6 if cols >= 5 else 9.2,
                     color=RGBColor(0xFF, 0xFF, 0xFF) if (r_idx == 0 and header) else DARK,
                     bold=(r_idx == 0 and header))
            if r_idx == 0 and header:
                set_cell_shading(cell, NAVY_HEX)
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            elif r_idx % 2 == 0:
                set_cell_shading(cell, LIGHT_HEX)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def add_code_block(doc, lines):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = table.cell(0, 0)
    set_cell_shading(cell, "F1F5F7")
    set_cell_margins(cell, top=110, bottom=110, left=160, right=160)
    cell.text = ""
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.line_spacing = 1.15
    for i, line in enumerate(lines):
        run = p.add_run(line)
        set_run_font(run, size=8, color=RGBColor(0x2A, 0x44, 0x55), name_en="Consolas")
        if i < len(lines) - 1:
            run.add_break()
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def add_paragraph(doc, text, style=None, bullet=False, numbered=False, quote=False):
    if bullet:
        p = doc.add_paragraph(style="List Bullet")
    elif numbered:
        p = doc.add_paragraph(style="List Number")
    else:
        p = doc.add_paragraph()
    if quote:
        p.paragraph_format.left_indent = Cm(0.5)
        p.paragraph_format.right_indent = Cm(0.4)
        p_pr = p._p.get_or_add_pPr()
        shd = OxmlElement("w:shd")
        shd.set(qn("w:fill"), "F1F7F9")
        p_pr.append(shd)
    add_runs(p, text, size=10.5 if not quote else 9.8, color=DARK if not quote else RGBColor(0x44, 0x5E, 0x73))


def convert(md_path, out_path, subtitle, doc_code):
    text = Path(md_path).read_text(encoding="utf-8")
    lines = text.splitlines()

    title = ""
    meta_lines = []
    body_start = 0

    # 提取 H1 与前置元数据
    for i, line in enumerate(lines):
        if line.startswith("# ") and not title:
            title = line[2:].strip()
        elif re.match(r"^\*\*(.+?)：\*\*\s*(.*)$", line):
            m = re.match(r"^\*\*(.+?)：\*\*\s*(.*)$", line)
            meta_lines.append((m.group(1), m.group(2)))
        elif title and line.strip() and not line.startswith("**"):
            body_start = i
            break

    doc = setup_document()
    add_cover(doc, title or "项目文档", subtitle, meta_lines, doc_code)

    while body_start < len(lines) and (not lines[body_start].strip() or lines[body_start].strip() == "<!-- pagebreak -->"):
        body_start += 1

    i = body_start
    in_code = False
    code_lines = []
    while i < len(lines):
        line = lines[i].rstrip("\n")
        stripped = line.strip()

        if stripped.startswith("```"):
            if not in_code:
                in_code = True
                code_lines = []
            else:
                in_code = False
                add_code_block(doc, code_lines)
            i += 1
            continue
        if in_code:
            code_lines.append(line)
            i += 1
            continue

        if not stripped:
            i += 1
            continue

        if stripped == "<!-- pagebreak -->":
            doc.add_page_break()
            i += 1
            continue

        if stripped.startswith("#### "):
            p = doc.add_paragraph()
            run = p.add_run(stripped[5:])
            set_run_font(run, size=10, bold=True, color=DARK)
            p.paragraph_format.space_before = Pt(8)
            p.paragraph_format.keep_with_next = True
            i += 1
            continue

        if stripped.startswith("### "):
            doc.add_heading(stripped[4:], level=3)
            i += 1
            continue
        if stripped.startswith("## "):
            doc.add_heading(stripped[3:], level=2)
            i += 1
            continue
        if stripped.startswith("# "):
            doc.add_heading(stripped[2:], level=1)
            i += 1
            continue

        if stripped.startswith("|"):
            table_rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                row = lines[i].strip()
                if not re.match(r"^\|[\s:|\-]+\|$", row):
                    cells = [c.strip() for c in row.strip("|").split("|")]
                    table_rows.append(cells)
                i += 1
            if table_rows:
                add_table(doc, table_rows)
            continue

        if stripped.startswith("> "):
            add_paragraph(doc, stripped[2:], quote=True)
            i += 1
            continue

        if stripped.startswith("- "):
            add_paragraph(doc, stripped[2:], bullet=True)
            i += 1
            continue

        m = re.match(r"^(\d+)\.\s+(.*)$", stripped)
        if m:
            add_paragraph(doc, m.group(2), numbered=True)
            i += 1
            continue

        add_paragraph(doc, stripped)
        i += 1

    # 文档属性
    doc.core_properties.title = title
    doc.core_properties.author = "深地智安项目组"
    doc.core_properties.subject = "模块 C：场景创新与设计"
    doc.core_properties.keywords = "智慧矿山, 安全物联网, 矿井监测, 设备选型, VibeCoding"

    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    doc.save(out)
    print(f"saved {out}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--subtitle", default="项目文档")
    parser.add_argument("--doc-code", default="MINE-IOT-DOC-001")
    args = parser.parse_args()
    convert(args.input, args.output, args.subtitle, args.doc_code)
