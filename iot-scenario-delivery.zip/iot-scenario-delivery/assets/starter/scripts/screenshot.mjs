/**
 * CDP 截图与页面健康检查脚本。
 * 前置：已启动 node server/index.js 与 Edge --remote-debugging-port=9222。
 */
import fs from 'node:fs';
import path from 'node:path';

const BASE = process.env.BASE_URL || 'http://127.0.0.1:4173/?v=20261109-final';
const OUT = path.resolve('deliverables/screenshots');
fs.mkdirSync(OUT, { recursive: true });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function newPage() {
  const target = await (await fetch(`http://127.0.0.1:9222/json/new?${encodeURIComponent('about:blank')}`, { method: 'PUT' })).json();
  const ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve, { once: true });
    ws.addEventListener('error', reject, { once: true });
  });
  let id = 0;
  const pending = new Map();
  const errors = [];
  ws.addEventListener('message', (event) => {
    const msg = JSON.parse(event.data);
    if (msg.id && pending.has(msg.id)) {
      const { resolve, reject } = pending.get(msg.id);
      pending.delete(msg.id);
      if (msg.error) reject(new Error(msg.error.message));
      else resolve(msg.result);
    }
    if (msg.method === 'Runtime.exceptionThrown') {
      errors.push(msg.params.exceptionDetails?.exception?.description || msg.params.exceptionDetails?.text || 'unknown exception');
    }
    if (msg.method === 'Log.entryAdded' && msg.params.entry.level === 'error') {
      errors.push(msg.params.entry.text);
    }
  });
  const send = (method, params = {}) => new Promise((resolve, reject) => {
    const mid = ++id;
    pending.set(mid, { resolve, reject });
    ws.send(JSON.stringify({ id: mid, method, params }));
  });
  await send('Page.enable');
  await send('Runtime.enable');
  await send('Log.enable');
  await send('Emulation.setDeviceMetricsOverride', { width: 1600, height: 1100, deviceScaleFactor: 1, mobile: false });
  return { ws, send, errors };
}

async function goto(page, url, wait = 2600) {
  await page.send('Page.navigate', { url });
  await sleep(wait);
}

async function shot(page, name) {
  const result = await page.send('Page.captureScreenshot', { format: 'png', fromSurface: true, captureBeyondViewport: false });
  const file = path.join(OUT, name);
  fs.writeFileSync(file, Buffer.from(result.data, 'base64'));
  console.log(`saved ${name} (${(fs.statSync(file).size / 1024).toFixed(0)} KB)`);
}

async function evalJs(page, expression) {
  const result = await page.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  if (result.exceptionDetails) throw new Error(result.exceptionDetails.text);
  return result.result?.value;
}

const page = await newPage();
try {
  await goto(page, `${BASE}#/overview`, 4200);
  console.log('title:', await evalJs(page, 'document.title'));
  console.log('h1:', await evalJs(page, "document.querySelector('.page-title')?.innerText"));
  console.log('toasts:', await evalJs(page, "document.querySelectorAll('.toast').length"));
  await shot(page, '01-overview.png');

  await goto(page, `${BASE}#/face/QL-1301`, 2600);
  console.log('face:', await evalJs(page, "document.querySelector('.face-title h2')?.innerText || document.querySelector('.page-title')?.innerText"));
  await shot(page, '02-face.png');

  await goto(page, `${BASE}#/alarms`, 2200);
  console.log('alarms rows:', await evalJs(page, "document.querySelectorAll('#alarm-table-body tr').length"));
  await shot(page, '03-alarms.png');
  await evalJs(page, "document.querySelector('#alarm-table-body tr[data-alarm-open]')?.click()");
  await sleep(900);
  await shot(page, '04-alarm-detail.png');
  await evalJs(page, "document.querySelector('[data-close-drawer]')?.click()");
  await sleep(500);

  await goto(page, `${BASE}#/history`, 3200);
  console.log('history canvas:', await evalJs(page, "!!document.querySelector('#history-chart')"));
  await shot(page, '05-history.png');

  await goto(page, `${BASE}#/topology`, 2200);
  await shot(page, '06-topology.png');

  await goto(page, `${BASE}#/devices`, 2200);
  await shot(page, '07-devices.png');

  await goto(page, `${BASE}#/overview`, 1900);
  await evalJs(page, "document.querySelector('#drill-btn')?.click()");
  await sleep(700);
  await shot(page, '08-drill-modal.png');
  await evalJs(page, "document.querySelector('[data-close-modal]')?.click()");
  await sleep(400);

  await goto(page, `${BASE}#/face/QL-1301`, 1800);
  await fetch('http://127.0.0.1:4173/api/scenario', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: 'gas', faceId: 'QL-1301' })
  });
  await sleep(12500);
  await shot(page, '09-scenario-live.png');
  await fetch('http://127.0.0.1:4173/api/scenario', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: 'normal' })
  });
  await sleep(1200);

  const overflow = await evalJs(page, `(() => {
    const els = [...document.querySelectorAll('.page *')];
    return els.filter(el => el.scrollWidth > el.clientWidth + 2 && getComputedStyle(el).overflowX === 'visible').slice(0,10).map(el => el.className || el.tagName);
  })()`);
  console.log('overflow candidates:', overflow);
  console.log('console errors:', page.errors);
} catch (error) {
  console.error('SCREENSHOT FAILED', error);
  console.log('console errors:', page.errors);
  process.exitCode = 1;
} finally {
  page.ws.close();
}
