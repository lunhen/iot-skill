# 真实踩坑清单（来自一次 260 步完整交付会话）

调试前先读本文件。下列每一条都在真实会话中消耗过 1–15 分钟；本 skill 的脚本已把
能自动规避的全部规避，剩余部分标为「人工注意」。

## A. 编码与文件读写

1. **Windows PowerShell 5.1 静默破坏中文**：`Get-Content -Raw` 按 ANSI 读 UTF-8，
   再 `Set-Content -Encoding UTF8` 会把中文写成乱码，且当时不易察觉（后续才发现 index.html 乱码）。
   → **一律用 Python 显式 `encoding='utf-8'` 读写**（本 skill 的 `_common.py` 已统一）。
2. Python 向 PowerShell 控制台 `print` 中文会触发 GBK `UnicodeEncodeError`。
   → 脚本开头 `sys.stdout.reconfigure(encoding='utf-8', errors='replace')`；输出尽量 ASCII。
3. `.bat` 启动脚本需 `chcp 65001` 且文件本身为 UTF-8 无 BOM。
4. Word/PPT 中文需同时设置 `run.font.name` 与 `rPr/a:ea` 东亚字体，否则字体回退。

## B. 浏览器与截图

5. **`msedge --headless --screenshot --virtual-time-budget` 在 SSE 长连接页面会永久挂起**。
   → 改用 `--remote-debugging-port=9222` + CDP `Page.captureScreenshot`（`scripts/capture.mjs`）。
6. DSH/受限沙箱会阻止 Chromium 创建命名管道，导致 Edge 起不来。
   → 加 `--no-sandbox --disable-crashpad --user-data-dir=<临时目录>`；仍失败则
   `build_all.py --skip-screenshots`（PPT 自动用占位图，不阻塞交付）。
7. **不要把 Edge 的 user-data-dir 放在项目目录内**：会话中 `.tmp-edge` 因 ACL/子进程锁
   反复删不掉，浪费大量时间。→ 用系统临时目录，构建结束 best-effort 清理。
8. Edge 多个调试标签累积后 CDP 会无响应（连 `Runtime.evaluate` 都挂）。
   → 每次截图新建标签并 `Target.closeTarget`；每轮构建用独立端口与进程。
9. **浏览器缓存导致「改了代码截图没变」**：`app.js` / `app.css` 需要版本号或 `no-store`。
   → `capture.mjs` 用 `Network.setCacheDisabled` + URL 时间戳；服务端已设 no-store。
10. `BASE_URL` 带 query 时不要写成 `${BASE}/#/route`（会变成 `/?v=x/#/route`），
    应为 `${BASE}#/route`。
11. 渲染函数抛异常被事件回调吞掉时，页面看起来「只是缺一块」。
    → CDP 监听 `Runtime.exceptionThrown` 与 `Log.entryAdded`，写入 build-report.json。

## C. 数据与状态

12. **字段同名覆盖**：`{...mine, level: maxLevel}` 把中文分类 `level: '低瓦斯矿井'`
    覆盖成 `normal`，界面显示英文原始状态码。→ 分类字段固定叫 `gasLevel`，
    告警等级固定叫 `level`，两者不得复用。
13. 告警引擎里 `rank()` 等辅助函数未定义、CSS 类（`.teal` / `.selected-row`）缺失，
    都是「先写模板后补样式」造成的。→ 骨架已补齐，改动时同步检查类名。
14. 仿真基线数据算错：8 个预置告警全设为 open，闭环率显示 28.6%，与仪表盘矛盾。
    → 固定 2 个 open + 8 个 resolved，指标自洽。
15. **数量单位混算**：把 `18.6 km` 光缆与「台」相加，显示「部署总量 168.6 台/套」。
    → xlsx 数量校核表按单位分组统计，禁止跨单位求和。
16. 设备参数串缺少 `Ex` 防爆标识，Excel 自动分类列判成「矿用阻燃」。
    → 参数串必须完整；xlsx 不再靠字符串猜分类。
17. **文案写死瞬时值**：PPT 写「CH₄ 1.12%」而截图是 1.06%，验收时被质疑。
    → 用「超限（1.0% 以上）」这类区间表述，数值一律从配置派生。

## D. PPT / 文档 / 表格

18. 深色背景上用低对比色写文件名，几乎看不见；截图是深色 UI，直接贴进 PPT 更暗。
    → 文本统一用 `TEXT2/MUTED` 高对比色；`prepare_ppt_assets.py` 对截图提亮 1.06–1.10 倍。
19. 卡片留白过大、垂直文字被压缩、箭头文字误放在箭头外、参数位置传参错位
    （`add_text` 的 color 与 font 位置写反）→ 微调版式时用固定坐标网格，别凭感觉。
20. **逐页目检 14 页 × 多轮**是最大时间黑洞。→ 结构固定后只抽查首页、软件页、
    场景页、末页；其余交给脚本保证一致性。
21. Word 表格列宽过窄导致中文被拆成单字断行。→ 表格列数控制在 6 列内，
    长文本放进独立段落而非塞进窄单元格。
22. 生成 PPT 时截图还未产出（顺序反了）→ `build_all.py` 固定顺序：
    截图 → 素材 → PPT → 文档 → 冒烟 → 打包。
23. 改了数据忘记重生成文档/源码 zip，提交包里是旧版。
    → `build_all.py` 一键全量重跑；`check.py` 校验内容可解析与项目名一致。

## E. 服务与验收

24. 修改 `server/index.js` 后未重启服务，接口冒烟测的还是旧逻辑。
    → 每次构建由 build_all 启动全新 node 进程。
25. `POST /api/scenario` 缺参数校验，非法类型也能启动 → 已加 400 校验并在 smoke 中覆盖。
26. 静态目录穿越、CSV 导出编码、SSE 断线重连，都是现场易被问到的点 → 骨架已处理，
    答辩 Q&A 保留对应回答。
27. `npm test` 输出被 npm notice 淹没，误以为没跑 → 看 exit code 与 `✓` 行。

## 人工仍需注意

- 阈值、设备型号、合规依据必须与赛题/行业口径一致，脚本给的是通用默认。
- AI 提示词全过程记录必须补入**本次真实**提示词与缺陷，模板默认值不能直接当真实记录提交。
- 现场演示前手动走一遍注入 → 告警 → 闭环，确认倒计时与联动文案与新主题术语一致。
- 若 glossary 漏词，用 `grep -r "<旧术语>" <项目目录>` 扫描残留。
