# 30 分钟时间盒 SOP

参考基线：一次真实交付用了 260 个模型步骤、约 51 分钟主体时间，其中
架构与前后端约 30 分钟、视觉/缓存/编码反复调试约 25 分钟、文档 PPT 逐页目检约 25 分钟、
打包收尾约 10 分钟。本 skill 把后三段变成脚本，只剩内容判断与抽查。

## 时间盒

| 分钟 | 动作 | 禁止事项 |
| --- | --- | --- |
| 0–4 | 通读赛题，圈出：场景名词、交付物清单、硬性指标、演示要求 | 不要开始写代码 |
| 4–10 | 复制 `assets/brief.*.json` → `brief.json`，填 `project` + `glossary` + `background/pain/innovations` | 不要手写设备表或阈值 |
| 10–12 | `new_project.py --brief brief.json --out <OUT> --force` | 不要改 starter 里的源码 |
| 12–15 | `build_all.py --project <OUT>`（约 2 分钟：截图 → 素材 → xlsx/pptx/topology/docx → 冒烟 → 打包 → 核验） | 不要中断截图进程 |
| 15–23 | 抽查 `screenshots/01-overview.png`、`02-face.png`、`09-scenario-live.png`；查看 `config/check-report.json`；按赛题补 `qa` 与真实 `promptVersions` | 不要逐页精修 PPT |
| 23–27 | 若赛题给了具体阈值/设备型号，改 `config/domain.json` 后**全量**重跑 `build_all.py` | 不要只改文档 |
| 27–30 | `npm start` 走一遍 8 分钟演示路径的前 2 分钟，确认 `交付清单.md` 与提交包 | 不要现场装依赖 |

## 命令速查

```bash
SKILL="C:/Users/admin/.zcode/skills/iot-scenario-delivery"
OUT="./my-project"

python "$SKILL/scripts/new_project.py" --brief ./brief.json --out "$OUT" --force
python "$SKILL/scripts/build_all.py" --project "$OUT"

# 单步重跑（迭代时省时间）
PY="$HOME/.dsh/dsh-runtimes/dsh-primary-runtime/dependencies/python/python.exe"
"$PY" "$SKILL/scripts/make_ppt.py"   "$OUT"
"$PY" "$SKILL/scripts/make_xlsx.py"  "$OUT"
"$PY" "$SKILL/scripts/make_topology.py" "$OUT"
"$PY" "$SKILL/scripts/make_docx.py"  "$OUT"
"$PY" "$SKILL/scripts/package.py"    "$OUT"
"$PY" "$SKILL/scripts/check.py"      "$OUT"
```

## 现场演示路径（8 分钟）

1. **综合态势**（1 min）：站点/区域/测点规模、在线率、活动告警、24h 分布、链路健康。
2. **区域监控**（1.5 min）：下钻首个区域，点击主风险测点看实时值、阈值、趋势与联动。
3. **情景演练**（2 min）：右上角「情景演练」→ 选场景 → 注入；8–12 秒后数值越限、
   自动联动、生成告警；顶部倒计时与进度条同步。
4. **告警闭环**（1.5 min）：告警中心打开新告警，看研判原因与联动记录，
   执行确认并复核 → 确认闭环 → CSV 导出。
5. **历史与拓扑**（1 min）：回溯曲线与阈值线；查看五层拓扑、RTT/丢包、设备台账。
6. **价值与局限**（1 min）：PPT 收束创新、价值、演进路线；主动说明仿真边界。

## 提交前 10 秒检查

- `config/check-report.json` 中 `ok: true`，无 required FAIL。
- 控制台出现 `SMOKE OK`。
- `deliverables/<项目名>-参赛交付包.zip` 存在且 > 1 MB（含截图）。
- `README.md` 里的启动端口与 `config/domain.json` 一致。
- `docs/AI提示词全过程记录.md` 已补入本次真实提示词版本。
