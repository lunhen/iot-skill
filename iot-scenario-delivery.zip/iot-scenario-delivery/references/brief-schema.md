# brief.json 字段手册

`brief.json` 是模型唯一需要创作的文件。其余全部由脚本生成。
两个可直接复制的样例：`assets/brief.mine.json`（同主题）、`assets/brief.park.json`（换主题）。

## 顶层结构

| 字段 | 必填 | 说明 |
| --- | --- | --- |
| `project` | 是 | 品牌、赛题、术语、端口。写入 `config/domain.json` 的 `project` |
| `glossary` | 否 | 术语替换表；换主题时最省力、最有效的字段 |
| `domain` | 否 | 对默认主数据做深度覆盖（dict 递归合并 / list 整体替换） |
| `content` | 否 | 文档与 PPT 的文案；未提供的字段由脚本按实时配置生成合理默认值 |

## project

```json
{
  "key": "park-safety-iot",              // ASCII，用于 zip / docx 编号
  "name": "安芯智控",                     // 品牌短名，出现在封面、页脚、README
  "fullName": "化工园区安全物联网监测平台",  // 全名
  "module": "模块 C：场景创新与设计",
  "contestTopic": "化工园区危险气体与环境安全物联网监测系统",
  "tagline": "让每一次气体异常，都被看见、被研判、被闭环",
  "siteLabel": "园区",                    // 一级导航术语
  "areaLabel": "生产装置区",              // 二级导航术语
  "pointLabel": "监测点",
  "port": 4174
}
```

## glossary（换主题核心）

- 对复制后的**所有文本文件**（server / public / scripts / docs / bat / md）以及
  `config/domain.json` 的值做字符串替换；key 按长度降序执行，长词优先。
- 除了中文术语，**也要覆盖 UI 里的英文装饰标签**，例如
  `MINE SAFETY IOT`、`WORKFACE DIGITAL TWIN`、`RETURN AIRWAY`、`CH₄`；
  否则换主题后 logo 副标题、示意图标签会残留旧场景词。
  不要写小写英文标识符（会破坏 `ch4`、`gas`、`normal` 等 key）。
- 覆盖顺序：`starter` 原文 → glossary → `domain` 显式覆盖 → `project` 强制覆盖。
- 建议包含：品牌名、赛题名、站点专名、一级/二级区域词、风险因子词、设备前缀词、
  布点角色词。不少于 8 条，不多于 40 条。
- 替换后检查：`grep -r "矿井" <项目目录>` 应无残留（若主题确实不含该词）。

## domain（可选覆盖）

结构与 `config/domain.json` 完全一致，可只写要改的部分：

```json
{
  "sites": [
    { "id": "EAST", "name": "东区化工园", "shortName": "东区", "location": "江苏 · 南京",
      "capacity": "120 万 t/a", "color": "#35e0c0", "gasLevel": "低风险装置区",
      "manager": "张工", "phone": "8001", "riskBase": 6,
      "faces": [ { "id": "EAST-A1", "name": "A1 合成装置区", "type": "合成",
                   "depth": 0, "crew": 24, "advance": "+2.4 m/d",
                   "ventilation": "全面通风", "status": "normal" } ] }
  ],
  "sensorTypes": {
    "ch4": { "name": "可燃气", "short": "LEL", "unit": "%LEL", "warning": 20,
             "alarm": 40, "critical": 60, "normal": [4, 14], "model": "GTYQ-LEL",
             "description": "监测反应器下风侧可燃气体积聚。" }
  },
  "scenarios": { "gas": { "name": "可燃气泄漏", "description": "……", "duration": 100 } },
  "devices": [], "linkNodes": []
}
```

**不可改**：`sensorTypes` 的 8 个 key 与 `direction`；`scenarios` 的 5 个 key。
`sites` 若整体替换，必须给每个站点 `faces` 且 `faces[].id` 唯一、ASCII；
`capture.mjs` 会用 `sites[0].faces[0].id` 做首个区域截图。
`devices` 若整体替换，每项需含 `category / items[{name,model,qty,unit,key,params,reason}]`。

### simulation（改阈值时必读）

```json
"simulation": {
  "scenarioTargets": { "gas": { "ch4": 1.72, "ch4b": 1.48, "temp": 28.4, "co": 18 } },
  "clamps": { "ch4": [0.15, 3.2] },
  "historyClamps": { "ch4": [0.18, 1.18] }
}
```

- `scenarioTargets[场景key][槽位key]` = 演练注入的目标值；
- `clamps[槽位key]` = 实时值上下限；`historyClamps` = 历史基线上下限，`low` 用于
  `direction: 'low'` 的槽位。
- **改 `sensorTypes.*.warning/alarm/critical` 或 `unit` 时，必须同步改这三张表**，
  否则注入值越不过阈值（演练不产生告警）或被 clamp 截断。
- 未提供的部分沿用 `assets/starter/config/domain.json` 中的默认值。
- 每类场景至少有一个槽位的目标值要**超过其 `critical` 阈值**，现场演示才会出现严重告警。

## content

| 字段 | 类型 | 用途 | 缺省 |
| --- | --- | --- | --- |
| `background` | string | README 简介、PPT 封面、文档第 1 节 | 按配置自动生成 |
| `pain` | 4 × {title,desc,metric} | PPT 第 2 页、设备文档风险表 | 通用 4 条 |
| `goals` | 4 × {title,desc} | PPT 第 3 页 | 通用 4 条 |
| `architecture` | 5 × {layer,items[],note} | PPT 第 4 页 | 五层通用 |
| `innovations` | 4 × {title,desc,anchor} | PPT 第 10 页 | 通用 4 条 |
| `values` | 3 × {title,desc,kpi} | PPT 第 12 页 | 通用 3 条 |
| `limits` | 4 × {title,desc,plan} | PPT 第 13 页、README 边界 | 通用 4 条 |
| `roadmap` | 3 × {phase,items} | PPT 第 13 页 | 通用 3 期 |
| `qa` | N × {q,a} | 答辩文档 Q&A | 通用 10 条 |
| `demo` | 6 × {time,title,steps[]} | 演示脚本、README、交付清单 | 8 分钟通用路径 |
| `compliance` | string[] | 设备文档合规底线 | 通用 4 条 |
| `principles` | string[] | 设备文档选型原则 | 通用 4 条 |
| `promptVersions` | N × {id,goal,change,result} | AI 提示词记录第 2 节 | 11 条示例 |
| `defects` | N × {id,symptom,cause,fix} | AI 提示词记录第 4 节 | 10 条真实历史缺陷 |

**赛题明确要求「真实提示词全过程」时，必须把本次会话的真实提示词与调试缺陷写入
`promptVersions` / `defects` 后重建**，并在文档第 3 节补入提示词原文与截图编号。
模板默认值只是结构示例，直接提交会被判定为未真实记录。

## 修改流程

1. 大改主题 → 改 `brief.json` → 重跑 `new_project.py --force`（会重建整个目录，注意先备份手工改动）。
2. 小改文案 → 改 `config/brief.json` 中 `content` → 重跑 `new_project.py` 会覆盖源码，
   因此**小改建议只重跑 `build_all.py` 前手工更新 `config/deck.json` 与 docs**，
   或直接改 `docs/*.md` 后运行 `make_docx.py`。
3. 改数值/设备 → 只改 `config/domain.json` → 重跑 `build_all.py`（全链路同源更新）。
